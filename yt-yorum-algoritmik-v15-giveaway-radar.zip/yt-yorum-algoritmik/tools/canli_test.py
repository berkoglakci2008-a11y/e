"""Gerçek videolarla canlı deneme (kendi bilgisayarında çalıştır; API anahtarı gerekir).
Kullanım:  python tools/canli_test.py            → iki test videosunu çeker, analiz eder, raporları yazdırır
           python tools/canli_test.py VIDEO_ID    → tek video
           python tools/canli_test.py --dosya data/comments/ID.json   → ağsız, kayıtlı ham veriden
Çıktı: data/comments/<id>.json (ham veri), data/analysis/<id>.json, data/rapor_<id>_<biçim>.md
Hiçbir yorum uydurulmaz; veri alınamazsa nedeni yazılır."""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, ROOT)
from yca import ytapi
from yca.insight import pipeline, report

VIDEOS = ["C7cP1-f0x08", "oY0s7eadWbo"]
DATA = os.path.join(ROOT, "data")

def old_vs_new(res):
    """Eski sistemin sözlüğü (yca.lexicon: tek tek anahtar kelime sayımı) ile yeni motoru aynı yorumlarda karşılaştırır."""
    from yca.lexicon import KeywordDictionary
    kd = KeywordDictionary(); agree = diff = 0; ex = []
    for c in res["comments"]:
        if c["owner"]: continue
        pos = kd.count(c["text"], "support") + kd.count(c["text"], "humor"); neg = kd.count(c["text"], "critical") + kd.count(c["text"], "conflict")
        old = "pozitif" if pos > neg else "negatif" if neg > pos else "nötr"
        new = c["label"] if c["label"] in ("pozitif", "negatif", "nötr") else "nötr"
        if old == new: agree += 1
        else:
            diff += 1
            if len(ex) < 8: ex.append((old, c["label"], c["text"][:90]))
    n = agree + diff
    print(f"\nEski sözlük ↔ yeni motor: {agree}/{n} aynı etiket ({100 * agree / max(n, 1):.0f}%). Farklı çıkan örnekler (elle kontrol et, hangisi haklı):")
    for o, nw, t in ex: print(f"  eski={o:8} yeni={nw:9} | {t}")

def main(argv):
    client = ytapi.YouTubeClient(ROOT, DATA)
    if not (client.connected() or client.has_key()) and "--dosya" not in argv: print("API anahtarı yok: data/yt_api_key.txt ya da uygulamadaki ayar kutusu."); return 1
    targets = [("file", argv[argv.index("--dosya") + 1])] if "--dosya" in argv else [("vid", v) for v in (argv or VIDEOS)]
    for kind, t in targets:
        try:
            if kind == "file":
                d = json.load(open(t, encoding="utf-8")); vid = d["video"]["id"]; res = pipeline.run(vid, DATA, None, raw=(d["video"], d["threads"], d["collection"]))
            else:
                vid = t; res = pipeline.run(vid, DATA, client, progress=lambda s, p: print("  ", s))
        except ytapi.YtError as e: print(f"[{t}] ALINAMADI: {e}"); continue
        print(f"\n=== {res['video']['title']} ({vid}) | tür: {res['type']['type']} | N={res['stats']['n_total']} | tam mı: {res['collection'].get('complete')} {res['collection'].get('notes')}")
        for f in report.FORMATS:
            rep = pipeline.make_report(res, f); open(os.path.join(DATA, f"rapor_{vid}_{f}.md"), "w", encoding="utf-8").write(report.to_markdown(rep, res["video"]))
            if f in ("kisa", "tartisma"): print(f"\n--- {rep['title']} (denetim: {'geçti' if rep['quality']['passed'] else rep['quality']['issues']})\n" + report.to_markdown(rep))
        old_vs_new(res)
    return 0

if __name__ == "__main__": sys.exit(main(sys.argv[1:]))
