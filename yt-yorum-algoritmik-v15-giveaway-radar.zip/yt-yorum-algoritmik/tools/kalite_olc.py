"""Şablon yorumların 'yapay görünme' ölçüsü (yaklaşık göstergeler). Kullanım: python tools/kalite_olc.py"""
import os, re, sys, collections
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from yca.subtitles import parse_subtitles
from yca.scoring import ImportanceScoringEngine
from yca.detector import CommentPointDetector
from yca.generator import CommentGenerator
from yca.textutil import tokens

SLANG = {"ya","lan","valla","resmen","abi","yani","bence","ha","ee","off","kral","be","bi"}
GENERIC = ("eline sağlık","devamı gelsin","emek","helal olsun","kaliteli","herkes izlemeli","kaydet","içim","gözlerim","boğazım","duygulan","dokundu","samimi","kim haklı","siz ne düşünüyorsunuz","yorumlar","sizce","kaç kişi","bilen var mı","tam benim aradığım")
S = """bugün size inanılmaz bir kasa açılışı getirdim arkadaşlar
önce şu poseidon bıçağa bakalım gerçekten çok pahalı
ama ben hiç şansım yok biliyorsunuz hep çöp çıkıyor
hadi açıyoruz ilk kasa ve evet yine mavi çıktı
yok artık bu ne ya hahaha inanamıyorum
chat ne diyorsunuz bırakalım mı devam mı edelim
bakiye bitti resmen bütün parayı yaktım
neyse son kasa son şansım bakalım ne olacak
ciddi misin gerçekten mi bu bıçak mı çıktı
battle zaten dokuz ona kasa kala gitmişti bile
şimdi bu skin için ne kadar verirler bilmiyorum
awp dragon lore olsa tamam derdim ama değil
herkes bana bunun saçma olduğunu söylüyor ama bence değil
ben bunu üç yıldır takip ediyorum hiç böyle görmedim
çok üzücü bir durum gerçekten kendimi kötü hissettim
yalan söylüyor bu adam kesin biliyor
teşekkür ederim bu kadar destek için gerçekten
joker kasası denedim ama olmadı yine olmadı
haha bu çok komik oldu inanamıyorum
bu kadar rezalet olamaz çok kötü bir açılış
harika bir drop geldi vay canına nasıl çıktı bu
sonunda toparladı yoksa kafayı yiyecektim
drop sistemi bu ara çok bozuk bence
iki yüz dolar gitti elimde sadece bir eldiven var
vay be bu ne ya şaşırdım resmen
sence bu doğru mu yoksa yanlış mı olmuş
özledim eski günleri o zamanlar çok güzeldi
çok iyi oldu bu gerçekten helal olsun
neden böyle yapıyorlar anlamıyorum hiç mantıklı değil
bu sefer olacak diyorum ve yine olmadı""".splitlines()
_SYL = ["ka","be","no","li","mu","ra","do","sa","te","vo","ni","pa","zu","ke","fi","lo"]
ITEMS = [_SYL[i] + _SYL[(i * 5 + j) % 16] + _SYL[(i * 3 + j * 7) % 16] + "x" for j in range(1, 6) for i in range(16)]   # 80 benzersiz uydurma "eşya" adı
def synth():
    """Her cümleye iki uydurma eşya adı eklenir (rakamsız, sık tekrar etmez); gerçek altyazılar da tekrar etmez."""
    raw=[]; t=0.0; k=0
    for rep in range(5):
        for s in S:
            w = [ITEMS[(k * 2 + j) % len(ITEMS)] for j in range(2)]; k += 1
            raw.append({"t":t,"d":3.5,"text":s+" "+w[0]+" "+w[1]}); t+=5.0
    return raw
def run(seed=1):
    l=parse_subtitles(synth()); sc=ImportanceScoringEngine().analyze(l)
    ms=CommentPointDetector(min_gap=10).detect(l,sc,l[-1]["t"]+4)
    g=CommentGenerator(seed=seed); out=[]
    for m in ms: out.append((m, g.generate(m)))
    return out
if __name__=="__main__":
    res=run(); allc=[c for _,d in res for c in (d["kısa"],d["orta"],d["uzun"])]
    n=len(allc); first=collections.Counter(c.split()[0] for c in allc)
    big=collections.Counter(b for c in allc for b in zip(c.split(),c.split()[1:]))
    slang=sum(sum(w in SLANG for w in c.split()) for c in allc)/n
    gen=sum(any(g in c for g in GENERIC) for c in allc)/n
    spec=sum(any(w in tokens(m["subtitle"]) and len(w)>=5 for w in c.split()) for m,d in res for c in d.values())/n
    rep=sum(v for v in big.values() if v>=3)/max(1,sum(big.values()))
    print(f"yorum sayısı: {n}")
    print(f"ortalama argo/dolgu kelime (yorum başına): {slang:.2f}")
    print(f"kalıp (övgü/duygu/etkileşim tuzağı) içeren oranı: {gen:.0%}")
    print(f"videodan somut bir kelime içeren oranı: {spec:.0%}")
    print(f"en sık ilk kelime: {first.most_common(3)}  (toplamın %{100*first.most_common(1)[0][1]/n:.0f}'i)")
    print(f"3+ kez tekrar eden ikili kelime oranı: {rep:.0%}")
    print("\nÖrnekler (orta uzunluk):")
    for m,d in res[:14]: print(f"  {m['time']} [{m['category']}] {d['orta']}")
