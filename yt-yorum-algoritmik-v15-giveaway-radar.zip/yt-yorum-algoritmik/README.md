# YouTube Algoritmik Yorum Analizcisi (yapay zekâsız)

Windows: `baslat.bat` dosyasına çift tıkla (Python'u gerekirse kendisi kurar).
Elle: `pip install -r requirements.txt` → `python app.py` → http://localhost:5000
Testler: `python -m unittest discover -s tests -v`

Akış: URL → video bilgisi → altyazı (zaman damgalı) → ayrıştırma → kural tabanlı puanlama → yorum noktası seçimi → şablon havuzundan yorum.
Hiçbir AI/LLM/API kullanılmaz. Puan ağırlıkları ve eşikler `config.json` içinde ayarlanır.
Veriler `data/` altında: `history/` (geçmiş), `cache/` (altyazı önbelleği), `app.log`.

Sınırlar: Altyazısı olmayan videolar analiz edilmez. Görüntü/ses anlaşılmaz. Yorumlar Türkçe şablonlardır.
Yorumlar otomatik paylaşılmaz; kopyalayıp kendiniz yazarsınız.

## YouTube'a otomatik gönderim (isteğe bağlı)
Resmî YouTube Data API kullanılır; yorum senin hesabından, her pakette "Gönder"e basıp metni onaylayınca atılır (toplu/otomatik döngü yok).
Kurulum (bir kez):
1. https://console.cloud.google.com → yeni proje → "YouTube Data API v3"ü etkinleştir.
2. OAuth onay ekranı: Harici, "Test" durumunda bırak, **Test kullanıcıları** kısmına kendi Gmail adresini ekle.
3. Kimlik bilgileri → OAuth istemci kimliği → Uygulama türü **Masaüstü uygulaması**. Çıkan **Client ID** ve **Client Secret** değerlerini uygulamanın üstünde çıkan "YouTube'a bağlanma ayarı" kutusuna yapıştırıp Kaydet'e bas (program `client_secret.json` dosyasını kendisi oluşturur). İstersen indirdiğin JSON'u elle `client_secret.json` adıyla proje klasörüne de koyabilirsin.
4. Uygulamayı aç → "YouTube hesabına bağlan" → izin ver. (Test modunda oturum 7 günde bir yenilenir.)
Sınırlar: yorum başına 50 kota birimi (günlük 10.000 → ~200 yorum), iki gönderi arası en az 30 sn, aynı videoya ikinci yorumda ek onay istenir.

## Yorumları yerel modelin yazması (Ollama) — gerçekçi yorum için önerilen yol
Şablonlar videoyu "anlamaz"; en doğal yorumları yerel dil modeli yazar. Ollama açıksa analiz sırasında her an için model yorum yazar,
şablonlar yalnızca yedektir (satırın üzerine gelince kaynak görünür, şablon satırlar biraz soluk gösterilir). Veri bilgisayarından çıkmaz.
1. https://ollama.com'dan Ollama'yı kur, `ollama pull gemma3:12b` (Türkçesi daha iyi; 12 GB ekran kartına sığar) ya da `ollama pull qwen2.5:7b`.
2. `config.json` → `"llm": {"model": "gemma3:12b"}`. Ollama kapalıysa uygulama kendiliğinden şablona döner.
3. Denemek için: `python deneme_yaz.py "altyazıdan bir cümle"` → modelin ham çıktısını ve filtrenin kabul/ret kararını gösterir.
Model çıktısı sıkı süzülür: "emeğinize sağlık/açıkçası/bu kısım" gibi AI kalıpları, altyazıda olmayan şeyi uyduran uzun yorumlar,
videodaki gerçek yorumların kopyası ve tekrarlar atılır; geçemeyen yorum yerine yeniden denenir (3 kez), olmazsa şablon kullanılır.
YouTube'a bağlıysan videonun gerçek yorumları modele üslup örneği olarak verilir (kopyalaması engellenir).

## Yorum analizi (Comment Intelligence) — http://localhost:5000/analiz
Videonun gerçek yorumlarını (ana yorum + cevap + beğeni + tarih, sayfalamalı) YouTube Data API ile alır; duygu, kategori, ironi/belirsizlik, konu, yön, etki, spam ve tartışma analizi yapar; 7 biçimde doğal dilli rapor yazar.
API anahtarı gerekir (`data/yt_api_key.txt` ya da ana sayfadaki ayar kutusu). Kota: 100 yorum ≈ 1 birim; tam cevap listesi için ek çağrı.
Gerçek videolarla deneme (kendi bilgisayarında): `python tools/canli_test.py` (iki test videosu) — ham veri `data/comments/`, raporlar `data/rapor_*.md`.
Kural tabanlıdır (LLM yok); doğruluğu elle etiketli veriyle ölçülmemiştir. PDF: sayfadaki düğme tarayıcı yazdırmasını açar ("PDF olarak kaydet").

## Giveaway Assistant — http://localhost:5000/giveaway
Discord'daki CS2 skin çekiliş kanallarını 7/24 izler (uygulama çalıştığı sürece, tarayıcı kapalıyken de; yeniden başlatınca kaldığı mesajdan devam eder), yeni çekilişleri kaydeder (aynı mesaj iki kez kaydedilmez), ödül/bitiş/şartları çıkarır, katılım rehberi ve YouTube yorum taslağı hazırlar, sonuçları takip eder. Veriler `data/giveaway.db` (SQLite). Ek paket gerekmez.
Kurulum (panelde "Kurulum" sekmesi): 1) Discord Developer Portal'da bot oluştur, token'ı kaydet. 2) Bot ayarlarında **Message Content Intent**'i aç. 3) Botu, yönetici olduğun sunucuya **View Channels + Read Message History** izniyle ekle. 4) Çekiliş kanallarını seç. 5) (İsteğe bağlı) kendi Discord kullanıcı kimliğini gir; kazanan listesinde seni bulup sonucu otomatik yazar.
Güvenlik/sınırlar: yalnızca resmî bot, salt okunur; self-bot yok. Beğeni, abonelik, sunucuya katılma ve katılım butonuna basma **senin elinle** yapılır (sistem bağlantı verir, işaret kutularını sen işaretlersin). YouTube yorumu yalnızca seçip onayladığın metinle, bağlı hesabından gider (30 sn aralık). Bot yalnızca kendisinin eklendiği sunucuları okur. Şart analizi kural tabanlıdır; anlaşılmayan şartlar sarı uyarıyla gösterilir. Kazanan tespiti, çekiliş botunun mesajındaki/cevabındaki kullanıcı etiketlerine dayanır; okunamazsa "belirsiz" olur ve elle işaretlersin. Ayar: `config.json` → `"giveaway": {"enabled": true, "interval_seconds": 60}`.

## YouTube Channel Radar — http://localhost:5000/radar
`config.json` → `"radar"` bölümündeki kanallar (`@emirichcs`, `@BerkayIpekci`) otomatik izlenir; panelden de eklenir/kaldırılır. Veriler `data/radar.db` (SQLite).
Akış: kanal RSS yayını (kota harcamaz, 10 dk) → yeni video → yayından 45 dk sonra yorum + cevaplar YouTube Data API ile toplanır → mevcut Comment Intelligence motoru analiz eder → "kısa" ve "detaylı" Türkçe rapor üretilip saklanır → site içi bildirim (+ sayfa açıkken tarayıcı bildirimi).
Tekrar işleme: her video bir kez kaydedilir; her kontrol noktası (45. dk, 24. saat) bir kez çalışır; 24. saatte yorum sayısı belirgin artmadıysa atlanır; işlenen yorum kimlikleri `seen_comments` tablosunda tutulur (raporda "yeni yorum" sayısı). Radar eklenmeden önceki videolar "görüldü" sayılır, istenirse tek tıkla analiz edilir.
Kota: günlük bütçe (varsayılan 8000 birim) izlenir, dolunca ya da API kotası bitince beklenir; hatalarda artan beklemeyle 6 kez yeniden denenir. Yeniden başlatmada bekleyen işler kaldığı yerden sürer.
Sınırlar: Arka plan çalışması program çalışırken geçerlidir; bilgisayar açılınca otomatik başlasın diye `otomatik_baslat.bat` (Windows). WebSub uygulanmadı: internetten erişilebilir HTTPS adresi gerektirir, yerel çalışmada RSS yoklaması yeterlidir (gecikme en çok ~10 dk). Tarayıcı bildirimi sayfa kapalıyken gelmez (web push için sunucuya ayrı kurulum gerekir). Analiz kural tabanlıdır.
