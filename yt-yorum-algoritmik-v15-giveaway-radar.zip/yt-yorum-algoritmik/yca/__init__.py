"""Algoritmik YouTube yorum analizcisi. Hiçbir yapay zekâ/LLM kullanılmaz."""
