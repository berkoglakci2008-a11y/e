import math
from collections import Counter
from .textutil import tokens, jaccard, pick_keyword, mmss, doc_freq

def target_count(duration_s): return max(5, min(60, round(duration_s / 60 * 2)))

class CommentPointDetector:
    """Yorum noktası seçici: eşik, minimum aralık, benzer metin ayıklama ve zamana dengeli dağılım."""
    def __init__(self, min_gap=20, min_raw=3.0, bucket_s=300):
        self.min_gap, self.min_raw, self.bucket_s = min_gap, min_raw, bucket_s

    def detect(self, lines, scored, duration, boost=()):
        N = target_count(duration); df = doc_freq(l["text"] for l in lines)
        cands = sorted((i for i, s in enumerate(scored) if s["raw"] >= self.min_raw and s["strong"]), key=lambda i: (-scored[i]["raw"], i))
        nb = max(1, math.ceil(duration / self.bucket_s)); quota = math.ceil(N / nb)
        chosen, counts = [], Counter()
        def ok(i):
            ti = set(tokens(lines[i]["text"]))
            return all(abs(lines[i]["t"] - lines[j]["t"]) >= self.min_gap and
                       jaccard(ti, tokens(lines[j]["text"])) <= 0.6 for j in chosen)
        for strict in (True, False):             # önce kota (dengeli dağılım), sonra boşlukları doldur
            for i in cands:
                if len(chosen) >= N: break
                b = int(lines[i]["t"] // self.bucket_s)
                if i in chosen or (strict and counts[b] >= quota) or not ok(i): continue
                chosen.append(i); counts[b] += 1
        return [self._moment(i, lines, scored, df, boost) for i in sorted(chosen, key=lambda i: lines[i]["t"])]

    @staticmethod
    def _moment(i, lines, scored, df=None, boost=()):
        l, text = lines[i], lines[i]["text"]
        if len(text) < 30 and i + 1 < len(lines) and lines[i+1]["t"] - (l["t"] + l["d"]) < 2:
            text += " " + lines[i+1]["text"]
        text = text[:160]
        s = scored[i]
        ctx = " ".join(x["text"] for x in lines if l["t"] - 30 <= x["t"] <= l["t"] + 8)[:420]     # LLM için çevre altyazısı
        return {"context": ctx, "t": int(l["t"]), "time": mmss(l["t"]), "category": s["category"], "score": s["score"],
                "raw": round(s["raw"], 1), "subtitle": text, "keyword": pick_keyword(text, df, boost), "features": s["features"]}
