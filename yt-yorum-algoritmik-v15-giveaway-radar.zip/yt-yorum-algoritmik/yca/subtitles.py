import html, json, os, re
from .textutil import tr_lower

class SubtitleError(Exception): pass

_FRIENDLY = {
    "TranscriptsDisabled": "Bu videoda altyazı kapalı. Altyazısız videolarda analiz yapılmaz.",
    "NoTranscriptFound": "Bu video için uygun altyazı bulunamadı.",
    "VideoUnavailable": "Video bulunamadı veya erişilemiyor.",
    "VideoUnplayable": "Video oynatılamıyor, altyazı alınamadı.",
    "RequestBlocked": "YouTube bu bağlantıdan altyazı isteğini engelledi. Kendi bilgisayarınızdan deneyin.",
    "IpBlocked": "YouTube bu IP adresinden altyazı isteğini engelledi. Kendi bilgisayarınızdan deneyin.",
    "AgeRestricted": "Yaş kısıtlamalı videonun altyazısı alınamıyor.",
}

def fetch_subtitles(vid, cache_dir):
    """SubtitleFetcher: (ham satırlar, dil, otomatik_mi). Önce önbellek, sonra YouTube."""
    os.makedirs(cache_dir, exist_ok=True)
    path = os.path.join(cache_dir, vid + ".json")
    if os.path.exists(path):
        d = json.load(open(path, encoding="utf-8"))
        return d["lines"], d["lang"], d["generated"]
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
        api = YouTubeTranscriptApi()
        try:
            tr = api.fetch(vid, languages=["tr", "en"])
        except Exception:
            tr = next(iter(api.list(vid))).fetch()   # eldeki ilk altyazı
        raw = [{"t": float(s.start), "d": float(s.duration), "text": s.text} for s in tr]
        lang, gen = tr.language_code, bool(tr.is_generated)
    except Exception as e:
        raise SubtitleError(_FRIENDLY.get(type(e).__name__, f"Altyazı alınamadı ({type(e).__name__}).")) from e
    json.dump({"lines": raw, "lang": lang, "generated": gen}, open(path, "w", encoding="utf-8"), ensure_ascii=False)
    return raw, lang, gen

_TAG = re.compile(r"\[[^\]]{1,40}\]|♪")
_LAUGH = ("gül", "laugh", "kahkaha", "haha")
_APPL = ("alkış", "applause", "cheer", "clap")

def parse_subtitles(raw):
    """SubtitleParser: temizler, [Gülüşmeler]/[Alkış] etiketlerini önceki konuşmaya bağlar."""
    out = []
    for r in sorted(raw, key=lambda r: r["t"]):
        text = re.sub(r"<[^>]+>", "", html.unescape(r["text"]))
        tags = []
        for m in _TAG.findall(text):
            low = tr_lower(m)
            if any(k in low for k in _LAUGH): tags.append("laughter")
            elif any(k in low for k in _APPL): tags.append("applause")
        speaker = bool(re.match(r"\s*(>>|-\s)", text))
        text = _TAG.sub(" ", text)
        text = re.sub(r"^\s*(>>+|-)\s*", "", text.strip())
        text = re.sub(r"\s+", " ", text).strip()
        if not text:
            if tags and out and r["t"] - (out[-1]["t"] + out[-1]["d"]) < 4:
                out[-1]["tags"] += tags
            continue
        out.append({"t": float(r["t"]), "d": float(r["d"]), "text": text, "tags": tags, "speaker_change": speaker})
    return out
