import re
_TR = str.maketrans({"İ": "i", "I": "ı"})
_WORD = re.compile(r"[^\W\d_]+", re.UNICODE)

STOP = set("""ve bir bu şu o da de ki mi mı mu mü ile için ama fakat gibi çok daha en ben sen biz siz onlar var yok ne
şey evet hayır değil ya yani işte şimdi sonra önce kadar olarak olan olduğu bunu şunu onu bana sana ona bunun çünkü hem
her hiç bile sadece zaten tamam bence sizce falan filan böyle şöyle öyle burada orada şunlar bunlar olarak olsun oldu
olur olmuş etti ediyor yapıyor yaptı gelen giden diye kendi birlikte tekrar belki artık hala hâlâ bile
the a an and or but is are was were be to of in on at it this that you i we they he she for with as so not no yes do does
did have has had just like what when how why your from there their about would could should really very""".split())

def tr_lower(s): return s.translate(_TR).lower()

def tr_capitalize(s):
    if not s: return s
    return {"i": "İ", "ı": "I"}.get(s[0], s[0].upper()) + s[1:]

def tokens(s): return _WORD.findall(tr_lower(s))

def jaccard(a, b):
    a, b = set(a), set(b)
    return len(a & b) / len(a | b) if a and b else 0.0

GENERIC = set("""önemli konuşacağımız bugün konu video herkese merhaba arkadaşlar şimdi ilk önce sonra gerçekten aslında kesinlikle
vardı vardır lazım lazımdı ihtiyacım olmuş ediyor biraz tabii tabi neyse işte yapıyoruz yapacağız bakalım görüyoruz gördüğümüz diyoruz dedim dedi diyor""".split())

def doc_freq(texts):
    from collections import Counter
    df = Counter()
    for t in texts: df.update(set(tokens(t)))
    return df

def pick_keyword(text, df=None, boost=()):
    """Videoya özgü (altyazıda nadir) kelime: sık geçenler ve genel sözcükler elenir; yoksa boş döner."""
    hit = [t for t in tokens(text) if len(t) >= 3 and t in boost and t not in STOP]   # kısa terimler de olur (awp, gg)
    c = [t for t in tokens(text) if len(t) >= 4 and t not in STOP and t not in GENERIC]
    if not c and not hit: return ""          # izleyicilerin de kullandığı konu kelimesi önceliklidir
    if hit: return min(hit, key=boost.index)
    if df is None: return max(c, key=len)
    c = [t for t in c if df[t] <= 3] or []
    return min(c, key=lambda t: (df[t], -len(t))) if c else ""

def mmss(s):
    s = int(s); h, r = divmod(s, 3600); m, x = divmod(r, 60)
    return f"{h}:{m:02d}:{x:02d}" if h else f"{m:02d}:{x:02d}"
