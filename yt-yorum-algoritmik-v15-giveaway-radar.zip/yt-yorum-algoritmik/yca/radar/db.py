import os, sqlite3, threading, time, json
SCHEMA = """
CREATE TABLE IF NOT EXISTS channels(handle TEXT PRIMARY KEY, channel_id TEXT, title TEXT, uploads TEXT, added INTEGER, last_poll INTEGER, last_ok INTEGER, last_error TEXT, baseline INTEGER DEFAULT 0, enabled INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS videos(video_id TEXT PRIMARY KEY, channel_id TEXT, title TEXT, published_at INTEGER, detected_at INTEGER, source TEXT, status TEXT,
  comment_count INTEGER, view_count INTEGER, attempts INTEGER DEFAULT 0, next_try INTEGER DEFAULT 0, last_error TEXT);
CREATE TABLE IF NOT EXISTS analyses(id INTEGER PRIMARY KEY AUTOINCREMENT, video_id TEXT, checkpoint INTEGER, created INTEGER, n_comments INTEGER, new_comments INTEGER, reported_count INTEGER,
  summary TEXT, reports TEXT, quota_used INTEGER, UNIQUE(video_id, checkpoint));
CREATE TABLE IF NOT EXISTS seen_comments(video_id TEXT, comment_id TEXT, PRIMARY KEY(video_id, comment_id));
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, kind TEXT, text TEXT, video_id TEXT, is_read INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, level TEXT, text TEXT);
CREATE TABLE IF NOT EXISTS state(key TEXT PRIMARY KEY, value TEXT);
"""
JSON_COLS = ("summary", "reports")
class DB:
    def __init__(self, data_dir):
        self.lock = threading.RLock()
        self.c = sqlite3.connect(os.path.join(data_dir, "radar.db"), check_same_thread=False); self.c.row_factory = sqlite3.Row
        with self.lock: self.c.execute("PRAGMA journal_mode=WAL"); self.c.executescript(SCHEMA); self.c.commit()
    def q(self, sql, a=()):
        with self.lock: rows = [dict(r) for r in self.c.execute(sql, a).fetchall()]
        for d in rows:
            for k in JSON_COLS:
                if isinstance(d.get(k), str):
                    try: d[k] = json.loads(d[k])
                    except ValueError: pass
        return rows
    def one(self, sql, a=()): r = self.q(sql, a); return r[0] if r else None
    def x(self, sql, a=()):
        with self.lock: cur = self.c.execute(sql, a); self.c.commit(); return cur
    def get(self, k, d=""): r = self.one("SELECT value FROM state WHERE key=?", (k,)); return r["value"] if r else d
    def set(self, k, v): self.x("INSERT INTO state(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))
    def event(self, lvl, t): self.x("INSERT INTO events(ts,level,text) VALUES(?,?,?)", (int(time.time()), lvl, t[:500]))
    def notify(self, kind, t, vid=None): self.x("INSERT INTO notifications(ts,kind,text,video_id) VALUES(?,?,?,?)", (int(time.time()), kind, t[:300], vid))
