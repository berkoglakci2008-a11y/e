"""YouTube Channel Radar: kanal izleme + otomatik yorum analizi (bağımsız modül)."""
