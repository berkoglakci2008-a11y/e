"""Radar çalışanı (arka plan iş parçacığı). Durum SQLite'ta; yeniden başlatınca bekleyen işler kaldığı yerden sürer.
Akış: RSS ile yeni video → kuyruğa → (yayından X dk sonra) yorumlar+cevaplar API'yle toplanır → mevcut Comment Intelligence motoruyla analiz → rapor → bildirim."""
import datetime, json, logging, os, threading, time
from .. import ytapi
from ..insight import pipeline as ci
from . import feed

log = logging.getLogger("yca.radar")
DEFAULTS = {"enabled": True, "channels": ["@emirichcs", "@BerkayIpekci"], "poll_seconds": 600, "first_delay_minutes": 45, "followup_hours": 24,
            "daily_quota_budget": 8000, "max_threads": 1000, "include_replies": True, "followup_min_growth": 0.2}

def pacific_day():
    try:
        from zoneinfo import ZoneInfo
        return datetime.datetime.now(ZoneInfo("America/Los_Angeles")).strftime("%Y-%m-%d")
    except Exception: return (datetime.datetime.utcnow() - datetime.timedelta(hours=8)).strftime("%Y-%m-%d")

class Radar:
    def __init__(self, db, yt, data_dir, cfg=None, feed_fn=None, runner=None):
        self.db, self.yt, self.data_dir = db, yt, data_dir
        self.cfg = {**DEFAULTS, **(cfg or {})}
        self.feed_fn = feed_fn or feed.fetch_feed
        self.runner = runner or self._run_engine
        self.stop_ev, self.thread = threading.Event(), None
        self.status = {"running": False, "last_cycle": 0, "last_error": ""}
        self.wake = threading.Event()
        for h in self.cfg["channels"]:
            self.db.x("INSERT OR IGNORE INTO channels(handle,added) VALUES(?,?)", (h if h.startswith("@") else "@" + h, int(time.time())))

    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.stop_ev.clear(); self.thread = threading.Thread(target=self._loop, daemon=True, name="channel-radar"); self.thread.start()
    def stop(self): self.stop_ev.set(); self.wake.set()

    # ---- kota
    def quota_left(self):
        day = pacific_day()
        if self.db.get("quota_day") != day: self.db.set("quota_day", day); self.db.set("quota_used", 0)
        return self.cfg["daily_quota_budget"] - int(self.db.get("quota_used", "0") or 0)
    def spend(self, n): self.quota_left(); self.db.set("quota_used", int(self.db.get("quota_used", "0") or 0) + int(n))
    def paused(self): return int(self.db.get("paused_until", "0") or 0) > time.time()

    def _loop(self):
        self.status["running"] = True; self.db.event("info", "Radar çalışanı başladı.")
        last_poll = 0
        while not self.stop_ev.is_set():
            try:
                if time.time() - last_poll >= self.cfg["poll_seconds"] or self.wake.is_set():      # yeni video tespiti API anahtarı gerektirmez (RSS)
                    self.wake.clear(); self.poll_all(); last_poll = time.time()
                if self.yt.connected() or self.yt.has_key():
                    self.process_due(); self.status["last_error"] = ""
                else: self.status["last_error"] = "YouTube API anahtarı yok: yeni videolar tespit edilir ama yorumlar analiz edilemez."
            except Exception as e:
                log.exception("radar hatası"); self.status["last_error"] = str(e)[:200]; self.db.event("error", self.status["last_error"])
            self.status["last_cycle"] = int(time.time())
            self.wake.wait(30); 
        self.status["running"] = False

    # ---- kanal çözümleme + yoklama
    def resolve(self, ch):
        """@kullanıcıadı -> kanal kimliği. Önce API (1 kota birimi); API reddederse herkese açık kanal sayfasından (anahtarsız)."""
        h = ch["handle"]
        try:
            b = self.yt.get("/channels", {"part": "snippet,contentDetails", "forHandle": h}) if (self.yt.connected() or self.yt.has_key()) else {}
            it = (b.get("items") or [None])[0]
            if it:
                self.spend(1)
                cid, title, up = it["id"], it["snippet"]["title"], it["contentDetails"]["relatedPlaylists"]["uploads"]
            else: raise ytapi.YtError("API sonuç döndürmedi")
        except ytapi.QuotaExceeded: raise
        except ytapi.YtError as e:
            cid, title = self._scrape(h)
            up = "UU" + cid[2:]
            self.db.event("warn", f"{h}: API ile çözülemedi ({str(e)[:120]}); kanal sayfasından çözüldü.")
        self.db.x("UPDATE channels SET channel_id=?, title=?, uploads=? WHERE handle=?", (cid, title, up, h))
        self.db.event("info", f"Kanal çözüldü: {title} ({h})")

    @staticmethod
    def _scrape(handle):
        import re, urllib.request
        req = urllib.request.Request("https://www.youtube.com/" + handle, headers={"User-Agent": "Mozilla/5.0", "Accept-Language": "tr,en;q=0.8", "Cookie": "CONSENT=YES+1"})
        try:
            with urllib.request.urlopen(req, timeout=20) as r: html = r.read().decode("utf-8", "replace")
        except Exception as e: raise ytapi.YtError(f"{handle} kanal sayfasına ulaşılamadı: {e}") from e
        m = (re.search(r'<link rel="canonical" href="https://www\.youtube\.com/channel/(UC[\w-]{22})"', html) or re.search(r'"externalId":"(UC[\w-]{22})"', html)
             or re.search(r'"channelId":"(UC[\w-]{22})"', html) or re.search(r'youtube\.com/feeds/videos\.xml\?channel_id=(UC[\w-]{22})', html))
        if not m: raise ytapi.VideoNotFound(f"{handle} kanal kimliği sayfadan okunamadı.")
        t = re.search(r'<meta property="og:title" content="([^"]+)"', html)
        return m.group(1), (t.group(1) if t else handle)

    def poll_all(self):
        for ch in self.db.q("SELECT * FROM channels WHERE enabled=1"):
            try:
                if not ch["channel_id"]: self.resolve(ch); ch = self.db.one("SELECT * FROM channels WHERE handle=?", (ch["handle"],))
                self.poll_channel(ch)
            except ytapi.QuotaExceeded as e: self._pause(str(e)); return
            except Exception as e:
                self.db.x("UPDATE channels SET last_error=?, last_poll=? WHERE handle=?", (str(e)[:200], int(time.time()), ch["handle"])); self.db.event("warn", f"{ch['handle']}: {e}")

    def poll_channel(self, ch):
        try: items, src = self.feed_fn(ch["channel_id"]), "rss"
        except Exception as e:                      # RSS bazen 404/boş döner: kotalı yedek yol
            if not ch.get("uploads"): raise
            items, src = feed.api_uploads(self.yt, ch["uploads"]), "api"; self.spend(1)
            self.db.event("warn", f"{ch['handle']}: RSS alınamadı ({e}); uploads listesi kullanıldı.")
        now, new = int(time.time()), 0
        first = not ch["baseline"]
        for v in items:
            if self.db.one("SELECT 1 x FROM videos WHERE video_id=?", (v["video_id"],)): continue
            status = "baseline" if first else "pending"      # ilk taramada mevcut videolar yalnızca 'görüldü' sayılır
            self.db.x("INSERT OR IGNORE INTO videos(video_id,channel_id,title,published_at,detected_at,source,status) VALUES(?,?,?,?,?,?,?)",
                      (v["video_id"], ch["channel_id"], v["title"], v["published_at"], now, src, status))
            if status == "pending":
                new += 1; self.db.notify("new_video", f"{ch['title'] or ch['handle']}: yeni video — {v['title']}", v["video_id"])
                self.db.event("info", f"Yeni video: {v['title']} ({v['video_id']})")
        if first: self.db.x("UPDATE channels SET baseline=1 WHERE handle=?", (ch["handle"],)); self.db.event("info", f"{ch['handle']}: ilk tarama, {len(items)} mevcut video görüldü olarak işaretlendi.")
        self.db.x("UPDATE channels SET last_poll=?, last_ok=?, last_error=NULL WHERE handle=?", (now, now, ch["handle"]))
        return new

    def _pause(self, why):
        # Kota gece yarısı (Pasifik saati) yenilenir; güvenli tarafta 1 saat bekle ve gün değişince bütçeyi sıfırla
        self.db.set("paused_until", int(time.time()) + 3600); self.db.event("warn", "YouTube kotası doldu, 1 saat beklenecek: " + why[:100])

    # ---- analiz kuyruğu
    def due(self, now=None):
        """[(video, checkpoint)] — süresi gelmiş işler. cp0: yayından first_delay dk sonra; cp1: followup_hours sonra (yorum yeterince arttıysa)."""
        now = now or int(time.time()); out = []
        for v in self.db.q("SELECT * FROM videos WHERE status IN ('pending','analyzed','error') AND next_try<=? ORDER BY published_at", (now,)):
            pub = v["published_at"] or v["detected_at"]; done = {a["checkpoint"] for a in self.db.q("SELECT checkpoint FROM analyses WHERE video_id=?", (v["video_id"],))}
            if v["status"] == "error" and v["attempts"] >= 6: continue
            if 0 not in done and now >= pub + self.cfg["first_delay_minutes"] * 60: out.append((v, 0))
            elif 0 in done and 1 not in done and now >= pub + self.cfg["followup_hours"] * 3600 and now < pub + 10 * 86400: out.append((v, 1))
        return out

    def process_due(self):
        if self.paused(): return
        for v, cp in self.due():
            if self.stop_ev.is_set() or self.paused(): return
            if self.quota_left() < 350: self.db.event("warn", "Günlük kota bütçesi dolmak üzere; analizler yarına ertelendi."); return
            self.analyze(v, cp)

    def analyze(self, v, cp, manual=False):
        vid = v["video_id"]; q0 = self.yt.quota
        try:
            if cp == 1 and not manual:                      # takip analizi: yalnızca yorum sayısı anlamlı arttıysa (1 kota birimi)
                info = self.yt.video_info(vid); self.spend(1)
                prev = self.db.one("SELECT reported_count FROM analyses WHERE video_id=? AND checkpoint=0", (vid,)) or {}
                old, new = prev.get("reported_count") or 0, info.get("comment_count") or 0
                if new - old < 10 or new < old * (1 + self.cfg["followup_min_growth"]):
                    self.db.x("INSERT OR IGNORE INTO analyses(video_id,checkpoint,created,n_comments,new_comments,reported_count,summary,reports,quota_used) VALUES(?,?,?,?,?,?,?,?,?)",
                              (vid, 1, int(time.time()), 0, 0, new, json.dumps({"skipped": "Yorum sayısı anlamlı artmadığı için yeniden analiz edilmedi."}, ensure_ascii=False), "{}", 1))
                    self.db.event("info", f"Takip atlandı (yorum {old}→{new}): {v['title']}"); return
            res = self.runner(vid)
            used = max(0, self.yt.quota - q0); self.spend(used)
            comments = [c for c in res["comments"] if not c.get("owner")]
            fresh = 0
            for c in res["comments"]:
                if self.db.x("INSERT OR IGNORE INTO seen_comments(video_id,comment_id) VALUES(?,?)", (vid, c["id"])).rowcount: fresh += 1
            s = res["stats"]; rep = {}
            for fmt in ("kisa", "detay"): rep[fmt] = ci.make_report(res, fmt, seed=int(vid.encode().hex()[:6], 16) + cp)
            summary = {"n_total": s["n_total"], "n_top": s["n_top"], "n_replies": s["n_replies"], "sentiment": {k: x["n"] for k, x in s["sentiment"].items()},
                       "topics": [t["topic"] for t in (res.get("topics") or [])[:4]], "collection": {k: res["collection"].get(k) for k in ("status", "complete", "capped", "notes")}}
            rc = (res.get("video") or {}).get("comment_count")
            self.db.x("INSERT OR REPLACE INTO analyses(video_id,checkpoint,created,n_comments,new_comments,reported_count,summary,reports,quota_used) VALUES(?,?,?,?,?,?,?,?,?)",
                      (vid, cp, int(time.time()), s["n_total"], fresh, rc, json.dumps(summary, ensure_ascii=False), json.dumps(rep, ensure_ascii=False), used))
            self.db.x("UPDATE videos SET status='analyzed', comment_count=?, attempts=0, last_error=NULL WHERE video_id=?", (rc, vid))
            self.db.notify("analysis", f"{'Analiz tamam' if cp == 0 else 'Güncel analiz'}: {v['title']} — {s['n_total']} yorum", vid)
            self.db.event("info", f"Analiz tamam: {v['title']} ({s['n_total']} yorum, ~{used} kota)")
        except ytapi.QuotaExceeded as e: self._pause(str(e))
        except Exception as e:
            n = v["attempts"] + 1; wait = min(3600, 120 * 2 ** n)
            self.db.x("UPDATE videos SET status='error', attempts=?, next_try=?, last_error=? WHERE video_id=?", (n, int(time.time()) + wait, str(e)[:200], vid))
            self.db.event("error", f"Analiz hatası {vid} (deneme {n}): {e}")
            if n == 6: self.db.notify("error", f"Analiz 6 kez başarısız oldu: {v['title']}", vid)

    def _run_engine(self, vid):
        def tf(v): from .. import subtitles; return subtitles.fetch_subtitles(v, os.path.join(self.data_dir, "cache"))
        return ci.run(vid, self.data_dir, self.yt, max_threads=self.cfg["max_threads"], include_replies=self.cfg["include_replies"], transcript_fetcher=tf)
