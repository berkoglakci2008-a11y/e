import json, os, re, time
from flask import Blueprint, jsonify, request, send_from_directory
from .db import DB
from .service import Radar
bp = Blueprint("radar", __name__); _S = {}

def init(app, root, data_dir, yt, cfg=None):
    cfg = cfg or {}; db = DB(data_dir); r = Radar(db, yt, data_dir, cfg)
    _S.update(db=db, r=r, root=root, yt=yt); app.register_blueprint(bp)
    if cfg.get("enabled", True): r.start()
    return r
def _err(m, c=400): return jsonify(error=m), c

@bp.get("/radar")
def page(): return send_from_directory(os.path.join(_S["root"], "static"), "radar.html")

@bp.get("/api/radar/overview")
def overview():
    db, r = _S["db"], _S["r"]; n = lambda s, a=(): db.one(s, a)["c"]
    last = db.one("SELECT created FROM analyses WHERE n_comments>0 ORDER BY created DESC LIMIT 1")
    return jsonify(now=int(time.time()), status=r.status, has_key=_S["yt"].has_key() or _S["yt"].connected(), quota_left=r.quota_left(), quota_budget=r.cfg["daily_quota_budget"],
        paused_until=int(db.get("paused_until", "0") or 0), poll_seconds=r.cfg["poll_seconds"], first_delay=r.cfg["first_delay_minutes"],
        videos=n("SELECT COUNT(*) c FROM videos WHERE status!='baseline'"), analyzed=n("SELECT COUNT(DISTINCT video_id) c FROM analyses WHERE n_comments>0"),
        waiting=n("SELECT COUNT(*) c FROM videos WHERE status='pending'"), errors=n("SELECT COUNT(*) c FROM videos WHERE status='error'"),
        unread=n("SELECT COUNT(*) c FROM notifications WHERE is_read=0"), last_analysis=last["created"] if last else None, channels=db.q("SELECT * FROM channels ORDER BY handle"))

@bp.get("/api/radar/videos")
def videos():
    db = _S["db"]; rows = db.q("""SELECT v.*, c.title AS channel_title, c.handle FROM videos v LEFT JOIN channels c ON c.channel_id=v.channel_id ORDER BY COALESCE(v.published_at,v.detected_at) DESC LIMIT 200""")
    for v in rows:
        a = db.one("SELECT checkpoint,created,n_comments,new_comments,reported_count,summary FROM analyses WHERE video_id=? AND n_comments>0 ORDER BY checkpoint DESC LIMIT 1", (v["video_id"],))
        v["analysis"] = a; v["thumb"] = f"https://i.ytimg.com/vi/{v['video_id']}/mqdefault.jpg"
    return jsonify(rows)

@bp.get("/api/radar/video/<vid>")
def video(vid):
    if not re.fullmatch(r"[A-Za-z0-9_-]{11}", vid): return _err("Geçersiz video.")
    v = _S["db"].one("SELECT * FROM videos WHERE video_id=?", (vid,))
    if not v: return _err("Video yok.", 404)
    v["analyses"] = _S["db"].q("SELECT * FROM analyses WHERE video_id=? ORDER BY checkpoint DESC", (vid,)); return jsonify(v)

@bp.post("/api/radar/video/<vid>/analyze")
def analyze_now(vid):
    """Kullanıcı isteğiyle (ör. ilk taramada 'görüldü' sayılan eski videolar için) analizi kuyruğa alır."""
    v = _S["db"].one("SELECT * FROM videos WHERE video_id=?", (vid,)) if re.fullmatch(r"[A-Za-z0-9_-]{11}", vid) else None
    if not v: return _err("Video yok.", 404)
    if _S["db"].one("SELECT 1 x FROM analyses WHERE video_id=? AND checkpoint=0 AND n_comments>0", (vid,)): return _err("Bu video zaten analiz edildi.", 409)
    _S["db"].x("DELETE FROM analyses WHERE video_id=? AND checkpoint=0", (vid,))
    _S["db"].x("UPDATE videos SET status='pending', attempts=0, next_try=0, published_at=MIN(COALESCE(published_at, 0), ?) WHERE video_id=?", (int(time.time()) - _S["r"].cfg["first_delay_minutes"] * 60, vid))
    _S["r"].wake.set(); return jsonify(ok=True)

@bp.post("/api/radar/poll")
def poll():
    if not _S["r"].yt.has_key() and not _S["r"].yt.connected(): return _err("YouTube API anahtarı yok.")
    _S["r"].wake.set(); return jsonify(ok=True)

@bp.post("/api/radar/channels")
def add_channel():
    h = (request.get_json(silent=True) or {}).get("handle", "").strip(); m = re.search(r"(@[\w.\-]{3,40})", h)
    if not m: return _err("@kullaniciadi ya da kanal bağlantısı gir.")
    _S["db"].x("INSERT INTO channels(handle,added,enabled) VALUES(?,?,1) ON CONFLICT(handle) DO UPDATE SET enabled=1", (m.group(1), int(time.time()))); _S["r"].wake.set(); return jsonify(ok=True)

@bp.delete("/api/radar/channels/<handle>")
def del_channel(handle): _S["db"].x("UPDATE channels SET enabled=0 WHERE handle=?", (handle,)); return jsonify(ok=True)

@bp.get("/api/radar/notifications")
def notifs():
    since = request.args.get("since", type=int)
    if since is not None: return jsonify(_S["db"].q("SELECT * FROM notifications WHERE id>? ORDER BY id", (since,)))
    return jsonify(_S["db"].q("SELECT * FROM notifications ORDER BY id DESC LIMIT 100"))
@bp.post("/api/radar/notifications/read")
def read(): _S["db"].x("UPDATE notifications SET is_read=1"); return jsonify(ok=True)
@bp.get("/api/radar/events")
def events(): return jsonify(_S["db"].q("SELECT * FROM events ORDER BY id DESC LIMIT 150"))
