"""Yeni video tespiti: YouTube'un resmî kanal RSS yayını (kota harcamaz). Yedek: uploads listesi (playlistItems, 1 kota birimi)."""
import datetime, re, urllib.request, xml.etree.ElementTree as ET
NS = {"a": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015", "m": "http://search.yahoo.com/mrss/"}

def _ts(s):
    try: return int(datetime.datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp())
    except Exception: return 0

def parse_feed(xml_bytes):
    root = ET.fromstring(xml_bytes); out = []
    for e in root.findall("a:entry", NS):
        vid = e.findtext("yt:videoId", "", NS)
        if not re.fullmatch(r"[A-Za-z0-9_-]{11}", vid or ""): continue
        out.append({"video_id": vid, "title": e.findtext("a:title", "", NS), "published_at": _ts(e.findtext("a:published", "", NS))})
    return out

def fetch_feed(channel_id, timeout=20):
    req = urllib.request.Request("https://www.youtube.com/feeds/videos.xml?channel_id=" + channel_id, headers={"User-Agent": "Mozilla/5.0 ChannelRadar"})
    with urllib.request.urlopen(req, timeout=timeout) as r: return parse_feed(r.read())

def api_uploads(yt, uploads_playlist, n=10):
    b = yt.get("/playlistItems", {"part": "snippet", "playlistId": uploads_playlist, "maxResults": n})
    return [{"video_id": i["snippet"]["resourceId"]["videoId"], "title": i["snippet"].get("title", ""), "published_at": _ts(i["snippet"].get("publishedAt", ""))} for i in b.get("items", [])]
