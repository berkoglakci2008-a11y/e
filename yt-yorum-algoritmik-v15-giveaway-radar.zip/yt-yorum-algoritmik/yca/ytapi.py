"""YouTube Data API v3 istemcisi (yalnızca standart kütüphane): OAuth girişi + commentThreads.insert.
Yorum yalnızca kullanıcının kendi hesabından ve kullanıcı onayıyla atılır."""
import json, os, secrets, time, urllib.error, urllib.parse, urllib.request

SCOPE = "https://www.googleapis.com/auth/youtube.force-ssl"
AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
API = "https://www.googleapis.com/youtube/v3"
MAX_LEN = 10000

class YtError(Exception): pass
class CommentsDisabled(YtError): pass
class QuotaExceeded(YtError): pass
class VideoNotFound(YtError): pass
class KeyInvalid(YtError): pass
class Transient(YtError): pass          # 5xx / ağ hatası: tekrar denenebilir

def api_exception(st, body):
    """HTTP durumu + gövdeden ayrıştırılmış istisna."""
    err = (body or {}).get("error"); reasons = [e.get("reason", "") for e in err.get("errors", [])] if isinstance(err, dict) else []
    msg = _api_error(body)
    if "commentsDisabled" in reasons: return CommentsDisabled(msg)
    if "quotaExceeded" in reasons or "dailyLimitExceeded" in reasons or "rateLimitExceeded" in reasons: return QuotaExceeded(msg)
    if "videoNotFound" in reasons or "commentThreadNotFound" in reasons or st == 404: return VideoNotFound(msg or "Video bulunamadı.")
    if "keyInvalid" in reasons or (st == 400 and "API key" in str(msg)): return KeyInvalid("API anahtarı geçersiz.")
    if st >= 500: return Transient(msg)
    return YtError(msg)

def _http(url, data=None, headers=None, timeout=20):
    """(durum, json) döner; HTTP hatalarında da gövdeyi okur."""
    if isinstance(data, dict) and (headers or {}).get("Content-Type") != "application/json":
        data = urllib.parse.urlencode(data).encode()
    elif isinstance(data, dict): data = json.dumps(data).encode()
    req = urllib.request.Request(url, data=data, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r: return r.status, json.loads(r.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read().decode("utf-8"))
        except Exception: return e.code, {}
    except Exception as e:
        raise YtError("Google sunucularına ulaşılamadı. İnternet bağlantını kontrol et.") from e

def _api_error(body):
    err = (body or {}).get("error")
    if isinstance(err, dict):
        reasons = [e.get("reason", "") for e in err.get("errors", [])]
        if "commentsDisabled" in reasons: return "Bu videoda yorumlar kapalı."
        if "quotaExceeded" in reasons or "dailyLimitExceeded" in reasons: return "Günlük YouTube API kotası doldu. Yarın tekrar dene."
        if "forbidden" in reasons: return "YouTube bu yorumu reddetti (yetki veya kısıtlama)."
        if "videoNotFound" in reasons: return "Video bulunamadı."
        return err.get("message") or "YouTube isteği reddetti."
    return str(err or "YouTube isteği başarısız oldu.")

class YouTubeClient:
    def __init__(self, root, data_dir, redirect="http://127.0.0.1:5000/auth/callback"):
        self.secret_path = os.path.join(root, "client_secret.json")
        self.token_path = os.path.join(data_dir, "yt_token.json")
        self.key_path = os.path.join(data_dir, "yt_api_key.txt")
        self.redirect, self.state = redirect, None

    def _client(self):
        try:
            with open(self.secret_path, encoding="utf-8") as f: d = json.load(f)
            c = d.get("installed") or d.get("web")
            return c["client_id"], c["client_secret"]
        except Exception: return None

    def configured(self): return self._client() is not None

    def save_client(self, client_id, client_secret):
        """Kullanıcının yapıştırdığı Client ID / Client Secret'ı client_secret.json olarak kaydeder."""
        cid, sec = (client_id or "").strip(), (client_secret or "").strip()
        if not cid.endswith(".apps.googleusercontent.com") or any(ch.isspace() for ch in cid):
            raise YtError("Client ID hatalı. '...apps.googleusercontent.com' ile bitmeli, boşluk olmamalı.")
        if len(sec) < 10 or any(ch.isspace() for ch in sec):
            raise YtError("Client Secret hatalı. Boşluk olmadan, tam olarak yapıştır.")
        tmp = self.secret_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f: json.dump({"installed": {"client_id": cid, "client_secret": sec}}, f)
        os.replace(tmp, self.secret_path)
        self.logout()      # eski anahtarla alınmış oturum varsa sil

    def api_key(self):
        try:
            with open(self.key_path, encoding="utf-8") as f: return f.read().strip()
        except Exception: return ""

    def has_key(self): return bool(self.api_key())

    def save_key(self, key):
        """Yalnızca herkese açık verileri (yorum okuma) kapsayan API anahtarı; yorum atmaz."""
        key = (key or "").strip()
        if not key.startswith("AIza") or len(key) < 30 or any(ch.isspace() for ch in key):
            raise YtError("API anahtarı hatalı. 'AIza' ile başlamalı, boşluk olmamalı.")
        os.makedirs(os.path.dirname(self.key_path), exist_ok=True)
        with open(self.key_path, "w", encoding="utf-8") as f: f.write(key)

    def _load(self):
        try:
            with open(self.token_path, encoding="utf-8") as f: return json.load(f)
        except Exception: return None

    def _save(self, t):
        tmp = self.token_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f: json.dump(t, f)
        os.replace(tmp, self.token_path)

    def connected(self): return bool((self._load() or {}).get("refresh_token"))

    def logout(self):
        try: os.remove(self.token_path)
        except FileNotFoundError: pass

    def login_url(self):
        c = self._client()
        if not c: raise YtError("client_secret.json bulunamadı. README'deki kurulum adımlarını uygula.")
        self.state = secrets.token_urlsafe(16)
        q = {"client_id": c[0], "redirect_uri": self.redirect, "response_type": "code", "scope": SCOPE,
             "access_type": "offline", "prompt": "consent", "state": self.state}
        return AUTH_URL + "?" + urllib.parse.urlencode(q)

    def handle_callback(self, code, state):
        if not code or not self.state or not secrets.compare_digest(state or "", self.state):
            raise YtError("Giriş doğrulanamadı, tekrar dene.")
        self.state = None
        cid, sec = self._client()
        st, body = _http(TOKEN_URL, {"code": code, "client_id": cid, "client_secret": sec, "redirect_uri": self.redirect, "grant_type": "authorization_code"})
        if st != 200 or "refresh_token" not in body: raise YtError("Google girişi tamamlanamadı: " + str(body.get("error_description") or body.get("error") or st))
        self._save({"access_token": body["access_token"], "refresh_token": body["refresh_token"], "expires": time.time() + int(body.get("expires_in", 3600)) - 60})

    def _access(self):
        t = self._load()
        if not t: raise YtError("Önce YouTube hesabına bağlan.")
        if t.get("expires", 0) > time.time(): return t["access_token"]
        cid, sec = self._client()
        st, body = _http(TOKEN_URL, {"client_id": cid, "client_secret": sec, "refresh_token": t["refresh_token"], "grant_type": "refresh_token"})
        if st != 200:
            if body.get("error") == "invalid_grant": self.logout(); raise YtError("Oturum süresi dolmuş (test modunda 7 gün). Yeniden bağlan.")
            raise YtError("Oturum yenilenemedi.")
        t.update(access_token=body["access_token"], expires=time.time() + int(body.get("expires_in", 3600)) - 60); self._save(t)
        return t["access_token"]

    def channel_title(self):
        st, body = _http(API + "/channels?part=snippet&mine=true", headers={"Authorization": "Bearer " + self._access()})
        if st != 200: raise YtError(_api_error(body))
        items = body.get("items") or []
        return items[0]["snippet"]["title"] if items else "(kanal yok)"

    def top_comments(self, vid, n=100):
        """Videonun en çok öne çıkan yorumları (1 kota birimi). Hesap bağlıysa oturumla, değilse API anahtarıyla. Hiçbiri yoksa ya da yorum kapalıysa boş liste."""
        q = {"part": "snippet", "videoId": vid, "maxResults": min(n, 100), "order": "relevance", "textFormat": "plainText"}
        headers = {}
        try: headers["Authorization"] = "Bearer " + self._access()
        except YtError:
            if not self.has_key(): return []
            q["key"] = self.api_key()
        st, body = _http(API + "/commentThreads?" + urllib.parse.urlencode(q), headers=headers)
        if st != 200: return []
        return [i["snippet"]["topLevelComment"]["snippet"].get("textDisplay", "") for i in body.get("items", [])]

    quota = 0       # bu oturumda harcanan tahmini kota birimi (liste çağrıları 1 birim)

    def get(self, path, q, cost=1):
        """Yetkili GET (hesap bağlıysa oturum, değilse API anahtarı). Hataları türlü istisnaya çevirir."""
        q = dict(q); headers = {}
        try: headers["Authorization"] = "Bearer " + self._access()
        except YtError:
            if not self.has_key(): raise YtError("Yorumları okumak için API anahtarı ya da YouTube bağlantısı gerekli.")
            q["key"] = self.api_key()
        try: st, body = _http(API + path + "?" + urllib.parse.urlencode(q), headers=headers)
        except YtError as e: raise Transient(str(e)) from e
        self.quota += cost
        if st == 200: return body
        err = (body or {}).get("error")
        if st == 403 and isinstance(err, dict) and "forbidden" in [e.get("reason", "") for e in err.get("errors", [])]:
            raise YtError("YouTube okuma isteğini reddetti (403): " + (err.get("message") or "") + " — API anahtarının kısıtlamalarını kontrol et (HTTP referrer/IP kısıtı varsa kaldır ya da 'YouTube Data API v3'e izin ver).")
        raise api_exception(st, body)

    def video_info(self, vid):
        """Başlık, açıklama, kanal, tarih, sayılar. Bulunamazsa VideoNotFound; yorum sayısı kapalıysa None."""
        b = self.get("/videos", {"part": "snippet,statistics", "id": vid})
        if not b.get("items"): raise VideoNotFound("Video bulunamadı ya da gizli.")
        it = b["items"][0]; sn, st = it.get("snippet", {}), it.get("statistics", {})
        num = lambda k: int(st[k]) if k in st else None
        return {"id": vid, "title": sn.get("title", ""), "description": sn.get("description", ""), "channel_id": sn.get("channelId", ""), "channel_title": sn.get("channelTitle", ""),
                "published": sn.get("publishedAt", ""), "tags": sn.get("tags", []), "comment_count": num("commentCount"), "view_count": num("viewCount"), "like_count": num("likeCount")}

    def post_comment(self, vid, text):
        text = (text or "").strip()
        if not text: raise YtError("Yorum boş.")
        if len(text) > MAX_LEN: raise YtError("Yorum çok uzun.")
        st, body = _http(API + "/commentThreads?part=snippet",
                         {"snippet": {"videoId": vid, "topLevelComment": {"snippet": {"textOriginal": text}}}},
                         {"Authorization": "Bearer " + self._access(), "Content-Type": "application/json"})
        if st != 200: raise YtError(_api_error(body))
        return body.get("id", "")
