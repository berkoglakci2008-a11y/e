"""Ollama ile yerel yorum yazarı + 'insan gibi mi?' denetimi. Ollama yoksa/başarısızsa şablon üretici devreye girer.
Model yalnızca altyazıdaki olaya tepki yazar; çıktı AI kalıpları, uydurma ve kopya için sıkı filtreden geçer."""
import json, re, time, urllib.request
from .textutil import tokens, tr_lower, STOP, jaccard

KEYS = ("kısa", "orta", "uzun")
BOUNDS = {"kısa": (2, 7), "orta": (4, 12), "uzun": (7, 22)}      # kelime sayısı
_J = {"kısa": "kisa", "orta": "orta", "uzun": "uzun"}

# gerçek izleyicinin yazmayacağı / asistan üslubunu ele veren kalıplar
BANNED = ["emeğinize", "emeğine sağlık", "harika video", "devamını bekl", "açıkçası", "dürüst olay", "bu kısım", "bu bölüm", "bu sahne",
          "zaman damgası", "yorumlarda", "yapay zeka", "dil modeli", "teşekkür", "şimdiden", "umarım", "tavsiye ederim", "kesinlikle",
          "muhteşem", "mükemmel bir", "sabırsızlıkla", "paylaşım için", "paylaştığınız", "değerli", "harika bir", "çok güzel bir",
          "önemli bir", "izlemeye değer", "izleyenlere", "kanalınız", "videonuz", "içeriğiniz", "abone ol", "beğenmeyi", "yapıcı", "saygı duyuyorum",
          "kusura bakmayın", "elbette", "tabii ki", "sonuç olarak", "özetle", "unutmayın", "#", "@", "http", "```"]

STYLE_EXAMPLES = [("adamlara poseidon bıçak awp ne varsa geldi", "poseidon bıçak da geldi tamam bu kasa bitti"),
                  ("battle zaten dokuz ona kasa kala gitmişti bile", "dokuza kasa kala gitmiş zaten yazık"),
                  ("bu ara drop bu kasa jokerle denenir bence", "joker mi ya ben olsam hiç dokunmazdım"),
                  ("iki yüz dolar gitti elimde sadece bir eldiven var", "iki yüz dolara bi eldiven abi çok acı"),
                  ("sonunda toparladı yoksa kafayı yiyecektim", "toparlamasaydı ben kapatıyordum valla")]
HINTS = ["söylenen bir sözü ya da kelimeyi tekrar edip üstüne kısa bir tepki ver", "kendi kendine laf atar gibi kısa bir alay ya da espri yap",
         "küçük bir sitem ya da şikâyet yaz", "ne olacağına dair kısa bir tahmin ya da bahis yaz", "sakin, düz bir tespit yaz; duyguyu abartma",
         "söylenenin yanlış ya da abartılmış olduğunu belirt", "tek bir şeye takılıp onu yaz, hepsine tepki verme"]

SYSTEM = """Sen bir YouTube videosunu telefondan izlerken tek satırlık yorum yazan sıradan bir Türk izleyicisin. Yazdığın her yorum videodaki belirli bir söze ya da ana bağlı olmalı. Gerçek izleyiciler her anda duygulanmaz, her şeyi övmez; çoğu yorum küçük bir tespit, laf atma ya da alaydır.

KURALLAR
- Önce "Tam bu an" cümlesindeki somut bir şeyi seç (bir kişi, nesne, sayı ya da söylenen laf) ve yorumu ona bağla. Altyazıda olmayan hiçbir şeyi uydurma; görüntüyü görmediğini bil.
- Hepsi küçük harf, nokta yok, resmî dil yok. Virgül en fazla bir, ünlem en fazla bir. Emoji kullanma (aksi belirtilmedikçe).
- Her yorumda en fazla BİR günlük dolgu kelimesi kullan (ya, lan, valla, abi, resmen, yani, bi). Hepsini üst üste yığma.
- Övgü, teşekkür, nezaket cümlesi ve abartılı duygu YOK ("harika", "eline sağlık", "içim burkuldu", "devamını bekliyorum", "emeğinize sağlık" gibi).
- Soru sorma ihtimali düşük olsun; çoğu yorum soru olmasın.
- Üç yorum aynı kalıpla başlamasın; "kısa" yalnızca küçük bir tepki, "uzun" bir ayrıntı artı tepki olsun. "bu kısım", "bu sahne", "açıkçası" kullanma.

ÇIKTI: JSON {"kisa": 3-5 kelime, "orta": 6-9 kelime, "uzun": 10-16 kelime}. Üçü aynı anla ilgili ama farklı cümleler olsun.

ÖRNEKLER (altyazı → yorum; başka videolardan, kopyalama, sadece tonu ve altyazıya bağlanma biçimini anla):
""" + "\n".join(f"- \"{a}\" → {b}" for a, b in STYLE_EXAMPLES)

SCHEMA = {"type": "object", "properties": {k: {"type": "string"} for k in ("kisa", "orta", "uzun")}, "required": ["kisa", "orta", "uzun"]}
_EMOJI = re.compile("[\U0001F300-\U0001FAFF☀-➿️]")
_QUOTES = re.compile(r"[“”\"«»`]")
_PREFER = ("qwen", "llama", "gemma", "mistral", "phi")
_SLANGW = {"ya", "lan", "valla", "abi", "resmen", "yani", "be", "kral", "bi", "bence", "ulan", "moruk"}
_PRAISE = re.compile(r"eline sağlık|devamı gelsin|\bemek\b|kaliteli|herkes izlemeli|süper video|güzel video|içim burkul|gözlerim doldu|boğazım|çok güzel olmuş")

def _norm(t): return re.sub(r"\W+", " ", tr_lower(t)).strip()
def _stems(text): return {w[:5] for w in tokens(text) if len(w) >= 4 and w not in STOP}

def check(text, key, ctx_stems, topic=(), crowd=(), used=(), allow_emoji=False):
    """Yorumu normalleştirir; insan gibi değilse / uydurmaysa / kopyaysa None döner."""
    if not isinstance(text, str): return None
    t = text.strip().splitlines()[0] if text.strip() else ""
    t = _QUOTES.sub("", t)
    if not allow_emoji: t = _EMOJI.sub("", t)
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"[.…]+$", "", t).strip()
    t = re.sub(r"!{2,}", "!", t)
    t = t.lower() if t[:1].isupper() or any(c.isupper() for c in t) else t
    t = t.replace("i̇", "i")
    if not t or t.count("!") > 1 or re.search(r"[.!?] \S", t): return None     # tek cümle
    low = tr_lower(t)
    if any(b in low for b in BANNED): return None
    n = len(t.split()); lo, hi = BOUNDS[key]
    if not lo <= n <= hi: return None
    if n > 6 and not (_stems(t) & (ctx_stems | {w[:5] for w in topic})): return None   # uzun yorum videodan bir şey içermeli (uydurma koruması)
    if t.count(",") > 1 or sum(w in _SLANGW for w in tokens(t)) > 2 or _PRAISE.search(low): return None   # dolgu yığma / kalıp övgü
    tt = tokens(t); op = [tokens(u)[0] for u in list(used)[-6:] if tokens(u)]
    if tt and op.count(tt[0]) >= 2: return None                                  # hep aynı kelimeyle başlama
    if _norm(t) in {_norm(u) for u in used}: return None
    tk = set(tokens(t))
    if any(jaccard(tk, tokens(c)) > 0.7 for c in crowd): return None               # başkasının yorumunu kopyalama
    return t

class OllamaWriter:
    def __init__(self, url="http://127.0.0.1:11434", model="qwen2.5:7b", timeout=90, tries=3):
        self.url, self.model, self.timeout, self.tries = url.rstrip("/"), model, timeout, tries
        self._st, self._st_t = None, 0.0
        self.fail_streak = 0

    def _http(self, path, payload=None, timeout=None):
        req = urllib.request.Request(self.url + path, data=json.dumps(payload).encode() if payload is not None else None,
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout or self.timeout) as r: return json.loads(r.read().decode("utf-8"))

    def status(self, force=False):
        """(hazır_mı, model, açıklama). 20 sn önbellek."""
        if not force and self._st and time.time() - self._st_t < 20: return self._st
        try:
            names = [m["name"] for m in self._http("/api/tags", timeout=3).get("models", [])]
            if not names: st = (False, self.model, "Ollama açık ama hiç model yüklü değil.")
            else:
                pick = self.model if self.model in names else next((n for p in _PREFER for n in names if n.startswith(p)), names[0])
                st = (True, pick, "")
        except Exception: st = (False, self.model, "Ollama'ya ulaşılamadı (açık mı?).")
        self._st, self._st_t = st, time.time(); return st

    def prompt(self, m, title, crowd, used):
        ctx = (m.get("context") or m["subtitle"])[:420]
        samples = [c for c in (crowd or {}).get("samples", [])][:12]
        u = [f"Video: {title or '(başlık yok)'}", f"Videoda bu anın çevresinde söylenenler: {ctx}", f"Tam bu an: {m['subtitle']}",
             f"Tür ipucu (sadece ipucu): {m.get('category', 'Genel')}",
             f"Bu seferki yorum biçimi: {HINTS[(int(m.get('t', 0)) // 7 + len(used or [])) % len(HINTS)]}"]
        if samples: u.append("Bu videonun altındaki gerçek yorumlar (sadece tonu ve kelime seçimini anla, kopyalama):\n" + "\n".join("- " + s for s in samples))
        if used: u.append("Bu videoya daha önce yazdığın yorumlar (bunlara benzeme, aynı kalıpla başlama):\n" + "\n".join("- " + s for s in used[-6:]))
        if (crowd or {}).get("emoji", 0) >= 0.25: u.append("Bu videonun izleyicileri emoji kullanıyor; en fazla bir emoji kullanabilirsin.")
        return "\n\n".join(u)

    def write(self, m, title="", crowd=None, used=()):
        """{'kısa','orta','uzun'} döner; doğrulanamayan anahtar eksik kalır (çağıran şablonla doldurur). Hata → Exception."""
        ok, model, why = self.status()
        if not ok: raise RuntimeError(why)
        ctx = _stems((m.get("context") or "") + " " + m["subtitle"])
        topic = (crowd or {}).get("topic", []); samples = (crowd or {}).get("samples", [])
        emoji = (crowd or {}).get("emoji", 0) >= 0.25
        out = {}
        for attempt in range(self.tries):
            body = {"model": model, "stream": False, "format": SCHEMA, "keep_alive": "30m",
                    "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": self.prompt(m, title, crowd, list(used) + list(out.values()))}],
                    "options": {"temperature": min(1.1, 0.85 + 0.1 * attempt), "top_p": 0.92, "repeat_penalty": 1.15, "num_ctx": 4096, "num_predict": 220}}
            try:
                raw = self._http("/api/chat", body)["message"]["content"]
                data = json.loads(raw)
            except (ValueError, KeyError): continue                       # bozuk JSON: tekrar dene
            for k in KEYS:
                if k in out: continue
                t = check(data.get(_J[k]), k, ctx, topic, samples, list(used) + list(out.values()), emoji)
                if t: out[k] = t
            if len(out) == len(KEYS): break
        return out
