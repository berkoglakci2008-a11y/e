"""Tek yorum düzeyinde sınıflandırma: duygu, ironi/mizah, kategori. Her karar 'kanıt' listesiyle birlikte döner."""
import re
from collections import Counter
from ..textutil import tokens, STOP, GENERIC
from ..lexicon import QWORDS, QSTART
from . import lex

CATS = ["Eleştiri", "Övgü", "Soru", "Öneri", "Mizah", "Tartışma", "Şikâyet", "Bilgilendirme", "Alakasız", "Spam", "Reklam"]
_SPLIT = re.compile(r"[.!?\n]+|\b(?:ama|fakat|lakin|ancak)\b")

def stems(text, n=5):
    return {t[:n] for t in tokens(lex.norm(text)) if len(t) >= 4 and t not in STOP and t not in GENERIC}

def clause_score(text):
    """(olumlu, olumsuz) ağırlıkları; olumsuzlama ve pekiştirme dikkate alınır. Emoji katkısı dahil."""
    t = lex.norm(text); pos = neg = 0.0
    neg += 2.0 * len(lex.NEG_PHRASES.findall(t)); t = lex.NEG_PHRASES.sub(" ", t)
    pos += 1.5 * len(lex.POS_PHRASES.findall(t)); t = lex.POS_PHRASES.sub(" ", t)
    toks = tokens(t)
    for i, tk in enumerate(toks):
        if tk.startswith("beğeni") or tk.startswith("sevgi"): continue
        p, n = lex.pos_word(tk), lex.neg_word(tk)
        if not (p or n): continue
        m = 1.3 if i and toks[i - 1] in lex.INTENS else 1.0
        negated = any(x in lex.NEGATORS for x in toks[i + 1:i + 3])
        if p:
            if negated: neg += p * m * 1.2
            else: pos += p * m
        if n:
            if negated: pos += n * m * .6
            else: neg += n * m
    e = Counter(ch for ch in text if lex.EMOJI_RE.match(ch))
    pos += min(2.0, sum(v for k, v in e.items() if k in lex.POS_EMO))
    neg += min(2.4, 1.2 * sum(v for k, v in e.items() if k in lex.NEG_EMO))
    return pos, neg

def features(text):
    """Bağlamdan bağımsız ham özellikler."""
    raw = lex.clean(text); t = lex.norm(raw); toks = tokens(t)
    pos, neg = clause_score(raw)
    emo = Counter(ch for ch in raw if lex.EMOJI_RE.match(ch))
    laugh = sum(v for k, v in emo.items() if k in lex.LAUGH_EMO)
    humor = len(lex.HUMOR.findall(t)) + (1 if laugh else 0) + (.5 if emo.get("😭") else 0)
    if laugh and not neg and not pos: pos += .5
    ir, ev = 0.0, []
    if lex.IRONY_PUNCT.search(raw): ir += 2; ev.append("ironik noktalama")
    for k, w in lex.IRONY_EMO.items():
        if emo.get(k): ir += w; ev.append("alaycı emoji " + k)
    if lex.IRONY_PH.search(t): ir += 1; ev.append("alaycı kalıp")
    if lex.QUOTED_POS.search(raw): ir += 1.5; ev.append("tırnak içinde övgü")
    qm = "?" in raw
    qw = bool(toks) and (any(x in QWORDS for x in toks) or toks[0] in QSTART or bool(lex.QWORD_EXTRA.search(t + " ")))
    return {"raw": raw, "norm": t, "toks": toks, "pos": pos, "neg": neg, "humor": humor, "irony": ir, "irony_ev": ev, "emo_n": sum(emo.values()),
            "question": (qm or qw) and len(toks) >= 2, "suggest": bool(lex.SUGGEST.search(t)), "complaint": bool(lex.COMPLAINT.search(t)),
            "ad": bool(lex.URL.search(raw)) or bool(lex.AD.search(t)), "promo_topic": bool(lex.PROMO_TOPIC.search(t)), "offtopic_phrase": bool(lex.OFFTOPIC.search(t)),
            "info_cue": bool(lex.INFO.search(t)) or bool(lex.TIMESTAMP.search(raw)), "agree": bool(lex.AGREE.search(t)), "disagree": bool(lex.DISAGREE.search(t)),
            "mention": "@" in raw, "n_tok": len(toks), "has_ts": bool(lex.TIMESTAMP.search(raw))}

def sentiment(f, ctx=None):
    """(etiket, güven, kanıtlar). ctx: {'reply_neg_share','n_replies','parent'(parent özellikleri)}.
    Etiketler: pozitif, negatif, nötr, karışık, belirsiz. İroni yeterince kanıtlı değilse 'belirsiz'."""
    ctx = ctx or {}; pos, neg, ir, ev = f["pos"], f["neg"], f["irony"], list(f["irony_ev"])
    if ctx.get("n_replies", 0) >= 2 and pos > 0 and ctx.get("reply_neg_share", 0) >= .6:
        ir += 1.5; ev.append("cevapların çoğu olumsuz/alaycı")
    if ir >= 3 and (pos > 0 or neg == 0): return "negatif", .7, ["alaycı (olası ironi)"] + ev, True
    if ir >= 1.5 and pos > 0: return "belirsiz", .35, ["övgü gibi ama ironi işareti var"] + ev, True
    if ir >= 1.5 and not neg: return "belirsiz", .35, ev, True
    if pos >= .7 and neg >= .7 and min(pos, neg) / max(pos, neg) >= .4: return "karışık", .6, ["hem olumlu hem olumsuz ifade"], False
    if max(pos, neg) < .7:
        par = ctx.get("parent")
        if par and f["agree"] and par.get("label") in ("pozitif", "negatif"): return par["label"], .4, ["üst yoruma katılıyor, duygu oradan devralındı"], False
        if f["n_tok"] <= 2 and not f["emo_n"]: return "belirsiz", .3, ["çok kısa, bağlam yok"], False
        return "nötr", .6, [], False
    lab = "pozitif" if pos > neg else "negatif"
    return lab, min(.95, .55 + .1 * abs(pos - neg)), [], False

def categorize(f, label, flags):
    """(birincil kategori, tüm etiketler). Öncelik: Reklam > Spam > Soru > Öneri > Şikâyet > Eleştiri > Tartışma > Mizah > Övgü > Bilgilendirme > Alakasız."""
    tags = []
    if f["ad"]: tags.append("Reklam")
    if flags.get("dup"): tags.append("Spam")
    if f["question"] and not f["ad"]: tags.append("Soru")
    if f["suggest"] and not f["ad"]: tags.append("Öneri")
    if f["complaint"] and (label in ("negatif", "karışık") or f["n_tok"] <= 12): tags.append("Şikâyet")
    if (label in ("negatif", "karışık") and f["neg"] >= .7) or (label == "negatif" and flags.get("ironic")): tags.append("Eleştiri")
    if f["disagree"] or f["mention"] or flags.get("heated"): tags.append("Tartışma")
    if f["humor"] >= 1: tags.append("Mizah")
    if label == "pozitif" and f["pos"] >= .7: tags.append("Övgü")
    if (f["info_cue"] or f["n_tok"] >= 25) and label in ("nötr", "pozitif") and not f["question"]: tags.append("Bilgilendirme")
    if not tags and (f["offtopic_phrase"] or flags.get("offtopic")): tags.append("Alakasız")
    order = ["Reklam", "Spam", "Soru", "Öneri", "Şikâyet", "Eleştiri", "Tartışma", "Mizah", "Övgü", "Bilgilendirme", "Alakasız"]
    if "Mizah" in tags and f["humor"] >= 1 and label != "negatif" and "Soru" not in tags and "Öneri" not in tags and "Reklam" not in tags and "Spam" not in tags:
        primary = "Mizah" if f["pos"] < 1.5 or f["humor"] >= 2 else "Övgü"
    else:
        primary = next((c for c in order if c in tags), "Diğer")
    return primary, tags
