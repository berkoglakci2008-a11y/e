"""Türkçe yorum sözlükleri ve metin normalleştirme. Hepsi sezgiseldir; kesin hüküm değil, kanıt üretir.
"kelime*" = ön ek eşleşmesi (Türkçe ekler için)."""
import html, re
from ..textutil import tr_lower

URL = re.compile(r"(?:https?://|www\.)\S+|\b[\w-]+\.(?:com|net|org|me|tv|io|gg|xyz|link)\b\S*", re.I)
TAG = re.compile(r"<[^>]+>")
EMOJI_RE = re.compile("[\U0001F300-\U0001FAFF☀-➿⭐]")
TIMESTAMP = re.compile(r"(?<!\d)(\d{1,2}:\d{2}(?::\d{2})?)(?!\d)")

def clean(text):
    """Görüntülenecek metin: HTML etiketleri ve boşluklar temizlenir, içerik değişmez."""
    t = html.unescape(TAG.sub(" ", text or ""))
    return re.sub(r"\s+", " ", t).strip()

def norm(text):
    """Analiz için: küçük harf (TR), URL'siz, harf uzatmaları ('çoooook' → 'çook') kısaltılmış."""
    t = tr_lower(URL.sub(" ", clean(text)))
    return re.sub(r"(.)\1{2,}", r"\1\1", t)

def compile_words(words):
    parts = [re.escape(w[:-1]) + r"\w*" if w.endswith("*") else re.escape(w) + r"(?!\w)" for w in words]
    return re.compile(r"(?<!\w)(?:" + "|".join(parts) + ")")

def prefix_table(table):
    exact = {k: v for k, v in table.items() if not k.endswith("*")}
    pref = [(k[:-1], v) for k, v in table.items() if k.endswith("*")]
    def look(tok):
        if tok in exact: return exact[tok]
        for p, v in pref:
            if tok.startswith(p): return v
        return 0.0
    return look

POS = {"güzel*": 1, "harika*": 2, "muhteşem*": 2, "efsane*": 2, "süper*": 1.5, "mükemmel*": 2, "bayıl*": 2, "beğen*": 1, "sev*": .8,
       "helal": 2, "bravo": 1.5, "tebrik*": 1.5, "kaliteli*": 1.5, "başarılı*": 1.5, "eğlenceli*": 1.5, "keyif*": 1.5, "şahane": 2, "bomba": 1.5,
       "favori*": 1.5, "teşekkür*": 1, "sağol*": 1, "eyvallah": 1, "profesyonel*": 1, "kral*": 1, "iyi*": .7, "komik": .7, "haklı*": .8,
       "öğretici*": 1.5, "faydalı": 1.5, "yararlı": 1.5, "emeğ*": 1.5, "mutlu*": 1, "şahane": 2, "eğlendim": 1.5, "izlemesi": .3}
NEG = {"kötü*": 1.5, "berbat*": 2, "rezalet*": 2, "rezil*": 2, "çöp*": 2, "saçma*": 1.5, "boş*": 1, "sıkıcı*": 1.5, "sıkıl*": 1.5, "bık*": 1.5,
       "yeter": 1, "yetti": 1, "iğrenç*": 2, "zorlama*": 1.5, "kandır*": 2, "yalan*": 1.5, "sahte*": 1.5, "fake": 1.5, "scam": 2, "dolandır*": 2,
       "pişman*": 1.5, "abartı*": 1, "rahatsız*": 1.5, "saygısız*": 2, "ahlaksız*": 2, "utanmaz*": 2, "gereksiz*": 1.5,
       "anlamsız*": 1.5, "bozuk*": 1, "hata*": .8, "yanlış*": 1.2, "sorun*": .8, "bug": 1, "hırsız*": 2, "kopya*": 1, "sinir*": 1.2, "nefret*": 2,
       "çirkin*": 1.5, "yazık": 1, "üzücü*": 1.2, "korkunç": 1.5, "vasat*": 1.5, "zayıf": 1, "yetersiz*": 1.5, "eksik*": .8, "kazık*": 1.5, "üzül*": 1}
pos_word, neg_word = prefix_table(POS), prefix_table(NEG)

# Önce maskelenen deyimler: (regex, işaret) — olumsuzlanmış ya da çok kelimeli ifadeler tek tek kelimelerden önce değerlendirilir
NEG_PHRASES = compile_words(["beğenmedi*", "sevmedi*", "izlemeye değmez", "vakit kaybı", "zaman kaybı", "hiç komik değil", "komik değil",
                             "kalitesiz*", "çok uzun", "biraz uzun", "uzun olmuş", "fazla uzun", "hayal kırıklığ*", "iyi değil", "güzel değil", "kaliteli değil", "hiç iyi değil", "olmamış"])
POS_PHRASES = compile_words(["kötü değil", "çok iyi", "eline sağlık", "emeğine sağlık", "ağzına sağlık", "devam et", "devamını bekl*", "abone oldum",
                             "izlemesi zevk", "iyi ki", "tam olmuş", "bayıldım"])
INTENS = {"çok", "aşırı", "gerçekten", "resmen", "tam", "ciddi", "baya", "bayağı"}
NEGATORS = {"değil", "değildi", "yok", "olmamış"}

POS_EMO = set("😍🥰❤💙💜🧡💛💚🔥👏👍🙏😊😁😄🤩😘💪🏆✨🥳🎉💯👌")
NEG_EMO = set("😡🤬👎😠😤🤮💩😒😞😔🥱")
LAUGH_EMO = set("😂🤣😆😹😅💀")
IRONY_EMO = {"🤡": 3.0, "🙄": 2.0, "🙃": 2.0, "😏": 2.0, "🤥": 2.0}
CRY_EMO = set("😭")

HUMOR = compile_words(["haha*", "ahah*", "kopt*", "güldüm", "gülmek*", "gülüyor*", "kahkaha*", "ölüyorum", "yerlere yat*", "dalga", "komik", "xd", "lol", "lmao", "espri*"])
IRONY_PH = compile_words(["tabii tabii", "tabi tabi", "aynen aynen", "evet evet", "ne güzel", "bravo", "alkışlar", "sanki", "hadi canım", "pek de", "ağzına sağlık", "çok şanslı"])
IRONY_PUNCT = re.compile(r"\(\s*[!?]\s*\)|\.\s\.\s\.")
QUOTED_POS = re.compile(r"[\"“”']\s*(?:harika|muhteşem|efsane|süper|mükemmel|güzel|iyi|kaliteli|şahane|başarılı)\w*\s*[\"“”']")

AGREE = compile_words(["aynen", "katılıyorum", "doğru", "haklısın", "haklı*", "bence de", "bende", "ben de", "kesinlikle", "+1", "ya aynen"])
DISAGREE = compile_words(["katılmıyorum", "yanlış*", "öyle değil", "hayır", "alakası yok", "sen bilmiyorsun", "yok öyle", "hiç de", "saçma*", "yalan*", "değil ki"])

SUGGEST = compile_words(["keşke", "yapsan*", "yapar mısın*", "yapın", "öneri*", "önerim", "eklense", "olsa güzel", "olsa iyi", "isterdim", "isterim", "istiyoruz",
                         "bekliyoruz", "bekliyorum", "denesen*", "gelsin", "yapsana", "lütfen", "rica"])
COMPLAINT = compile_words(["sürekli", "hep aynı", "yine mi", "yeter artık", "bıktık", "bıktım", "her seferinde", "neden hep", "reklam çok", "çok reklam", "çok uzun",
                           "uzatma*", "donuyor", "kasıyor", "izleyemiyorum", "açılmıyor", "sesi kötü", "ses kötü", "ses seviyesi", "kalite düşük", "mikrofon*", "yok mu"])
# Reklam: yalnızca URL ya da açık çağrı kalıpları. 'kod', 'bonus', 'çekiliş' gibi sözler videonun konusu olabilir; bunlar reklam değil 'tanıtım konusu' sayılır.
AD = compile_words(["kanalıma", "kanalımı", "abone ol*", "aboneol", "takip et*", "takipleş*", "telegram", "whatsapp", "dm at*", "dm'den", "sub4sub", "karşılıklı abone",
                    "para kazan*", "yatırım", "casino", "bahis", "kumar sitesi", "ek gelir", "evden çalış*"])
PROMO_TOPIC = compile_words(["kod", "kodu", "bonus*", "çekiliş*", "promosyon*", "referans*", "casehug", "sponsor*", "reklam*", "indirim*"])
OFFTOPIC = compile_words(["kaçıncı", "kim izliyor", "izleyen var mı", "ilk yorum", "ilk beğeni", "beğeni atan", "beğenen", "yorum atan", "burada kim", "2026'da", "2025'te", "2027"])
INFO = compile_words(["aslında", "bilmeyenler için", "bilgi olarak", "not:", "belirtmek isterim", "hatırlatma", "güncelleme", "kaynak", "çünkü"])
QWORD_EXTRA = compile_words(["nasıl", "neden", "niye", "niçin", "kaç", "hangi", "nerede", "kim", "ne zaman", "var mı", "olur mu", "mu ", "mi ", "mı ", "mü "])

# Başlık/açıklama/yorum sözcüklerinden video türü: (anahtar kelime ön ekleri)
TYPES = {
 "Oyun": ["oyun*", "cs2", "csgo", "valorant", "minecraft", "gta", "fortnite", "kasa", "skin*", "karambit", "gameplay", "yayın*", "twitch", "rank*", "maç", "lig", "turnuva", "boss", "fps", "pubg", "lol", "apex"],
 "Teknoloji": ["telefon*", "iphone", "samsung", "işlemci*", "ekran kartı", "bilgisayar*", "yazılım*", "android", "ios", "yapay zeka", "laptop*", "donanım*", "pil", "batarya", "teknoloji*", "yazılım", "gb", "chatgpt"],
 "Eğitim": ["ders*", "eğitim*", "nasıl yapılır", "öğren*", "anlatım", "konu anlatımı", "kurs*", "tutorial", "rehber*", "adım adım", "sınav*", "yks", "kpss"],
 "Haber": ["haber*", "son dakika", "gündem*", "açıklama yaptı", "başkan*", "seçim*", "bakan*", "savaş*", "ekonomi", "dolar", "gazete*"],
 "Spor": ["maç*", "gol*", "transfer*", "futbol*", "basketbol*", "şampiyon*", "hakem*", "fenerbahçe", "galatasaray", "beşiktaş", "trabzonspor", "teknik direktör", "takım*"],
 "Podcast": ["podcast*", "bölüm", "konuk*", "sohbet", "röportaj*", "söyleşi*"],
 "Vlog": ["vlog*", "günlük", "bir gün", "seyahat*", "gezi*", "tatil*", "rutin*", "yaşam*"],
 "Müzik": ["şarkı*", "klip*", "müzik*", "albüm*", "söz*", "official", "remix", "cover", "konser*", "feat"],
 "İnceleme": ["inceleme*", "review", "test ettim", "kutu açılımı", "alınır mı", "fiyat performans", "kullanıcı deneyimi", "karşılaştırma*"],
 "Tepki": ["tepki*", "reaction", "react", "izliyoruz", "izledim ve"],
 "Eğlence": ["challenge", "şaka*", "komik", "eğlence*", "troll*", "eğlenceli", "kamera şakası", "meydan okuma"],
}

# Video türüne özel "bahsedilen yön" sözlükleri: yön adı → sözcükler. GENEL_YONLER her videoda geçerlidir.
GENEL_YONLER = {
 "anlatım / sunum": ["anlatım*", "anlatış*", "anlatma*", "sunum*", "konuşma*", "tarz*", "üslup*", "enerji*"],
 "kurgu / montaj": ["kurgu*", "montaj*", "edit*", "geçiş*", "efekt*"],
 "ses / müzik": ["ses", "sesi", "sesin*", "mikrofon*", "müzik*", "fon müziği"],
 "görüntü kalitesi": ["görüntü*", "kalite", "kalitesi", "çözünürlük*", "kamera*", "ışık*", "4k", "bulanık*"],
 "süre / tempo": ["süre", "süresi", "süreyi", "süresini", "uzun", "kısa", "uzatma*", "tempo*", "hızlı", "yavaş", "sıkıcı*"],
 "reklam / sponsor": ["reklam*", "sponsor*", "kod", "kodu", "bonus*", "indirim*", "tanıtım*"],
 "başlık / kapak": ["başlık*", "kapak*", "thumbnail*", "tık tuzağı", "clickbait", "tıklama*"],
 "güven / dürüstlük": ["kandır*", "yalan*", "sahte*", "güven*", "dürüst*", "ayar*", "senaryo*", "kurgu mu", "gerçek mi"],
}
TUR_YONLER = {
 "Oyun": {"şans / olasılık": ["şans*", "oran*", "olasılık*", "drop*", "çıkma*"], "ödül / eşya": ["skin*", "bıçak*", "karambit*", "eşya*", "ödül*", "kasa*", "item*"],
          "yayıncı davranışı": ["yayıncı*", "tepki*", "heyecan*", "hırs*", "para*"], "platform / site": ["site*", "platform*", "casehug", "kod*"]},
 "Teknoloji": {"fiyat": ["fiyat*", "pahalı*", "ucuz*", "tl", "dolar"], "performans": ["performans*", "hız*", "fps", "donma*", "kasma*"], "tasarım": ["tasarım*", "görünüm*", "renk*"], "batarya": ["pil", "batarya*", "şarj*"], "yazılım": ["yazılım*", "güncelleme*", "arayüz*"]},
 "Eğitim": {"anlaşılırlık": ["anlaşılır*", "anladım", "anlamadım", "açık", "net"], "örnekler": ["örnek*", "soru*", "çözüm*"], "hız": ["hızlı", "yavaş", "tempo*"], "kaynak": ["kaynak*", "pdf", "link*"]},
 "Haber": {"doğruluk": ["doğru*", "yanlış*", "kaynak*", "iddia*"], "tarafsızlık": ["taraf*", "yorum*", "propaganda*"]},
 "Spor": {"hakem": ["hakem*", "var", "penaltı*"], "oyuncular": ["oyuncu*", "kaleci*", "golcü*"], "taktik": ["taktik*", "hoca*", "teknik direktör*", "diziliş*"]},
 "Podcast": {"konuk": ["konuk*", "misafir*"], "konu seçimi": ["konu*", "tartışma*", "soru*"]},
 "Müzik": {"şarkı sözü": ["söz*", "nakarat*"], "vokal": ["vokal*", "sesin*", "ses"], "klip": ["klip*", "çekim*"]},
 "İnceleme": {"fiyat": ["fiyat*", "pahalı*", "ucuz*"], "tavsiye": ["alınır*", "tavsiye*", "önerir*"], "karşılaştırma": ["karşılaştır*", "rakip*"]},
 "Vlog": {"mekan": ["mekan*", "yer", "şehir*", "otel*"], "kişilik": ["samimi*", "doğal*", "sempatik*"]},
 "Tepki": {"tepki verilen içerik": ["orijinal*", "asıl", "kaynak*"], "tepki tarzı": ["tepki*", "yüz ifadesi", "heyecan*"]},
 "Eğlence": {"mizah": ["komik*", "espri*", "şaka*", "güldüm"], "format": ["challenge*", "bölüm*", "format*"]},
}

# Raporlarda yasaklı/sınırlı kalıplar (kullanıcı listesi + sık görülen yapay kalıplar). Her biri bir raporda en fazla 1 kez geçebilir.
STOCK_PHRASES = ["genel olarak değerlendirildiğinde", "bu durum oldukça dikkat çekicidir", "yapılan analizler göstermektedir", "öte yandan", "bununla birlikte",
                 "sonuç olarak", "kullanıcıların büyük çoğunluğu", "görülmektedir", "dikkat çekmektedir", "sergilediği görülmektedir", "önem arz", "göz önüne alındığında"]
