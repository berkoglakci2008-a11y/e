"""Yorum analiz motoru: düzleştirme → özellik → bağlam → kategori → yön/konu → etki → tartışma → istatistik.
Girdi gerçek API verisidir (collect.py). Burada hiçbir yorum/sayı uydurulmaz; çıkarılamayan değer None kalır."""
import math, re
from collections import Counter, defaultdict
from statistics import median
from ..textutil import tokens, STOP, GENERIC, tr_lower
from . import lex
from .classify import features, sentiment, categorize, stems, clause_score, _SPLIT

SLANG = {"ya", "lan", "be", "abi", "kral", "valla", "resmen", "yani", "ha", "ulan", "kanka", "moruk", "aga", "reis", "hocam", "bro", "knk", "dostum", "gg", "nt", "kardeş", "abim", "abla", "usta", "hoca"}
TOPIC_STOP = SLANG | {"video", "videoyu", "videonun", "kanal", "kanalı", "izledim", "izliyorum", "izle", "bence", "gerçekten", "çok", "daha", "sadece", "herkes", "adam", "insan",
                      "artık", "zaten", "tabi", "tabii", "olsun", "yok", "var", "gibi", "yine", "hala", "hâlâ", "bile", "hep", "ben", "sen", "biz", "iyi", "kadar", "olan", "oldu", "olmuş", "diye", "için", "aynen", "katılıyorum", "doğru", "kesinlikle", "evet", "hayır", "haklısın", "bende", "katılmıyorum", "keşke", "yapsan", "yapsanız", "isterdim", "isterim", "lütfen", "yapsana", "gelsin", "bekliyoruz", "bekliyorum"}
_CLEAN = re.compile(r"\W+")

def pct(a, b): return None if not b else round(100 * a / b, 1)

def detect_type(title, desc, transcript, comments_text):
    sc = Counter()
    for text, w in ((title, 3.0), (desc[:1500], 1.0), (transcript[:3000], 1.0), (comments_text[:6000], .5)):
        t = lex.norm(text)
        for ty, words in lex.TYPES.items():
            sc[ty] += w * len(lex.compile_words(words).findall(t))
    best = sc.most_common(2)
    if not best or best[0][1] < 3: return {"type": "Diğer", "confidence": 0.0, "scores": dict(sc)}
    margin = (best[0][1] - (best[1][1] if len(best) > 1 else 0)) / best[0][1]
    return {"type": best[0][0] if margin >= .15 else "Diğer", "confidence": round(margin, 2), "scores": {k: round(v, 1) for k, v in sc.items() if v}}

def flatten(threads, owner):
    items = []
    for t in threads:
        top = {**t, "parent": None, "is_owner": bool(owner) and t.get("author_channel") == owner}
        items.append(top)
        for r in t.get("replies", []): items.append({**r, "parent": t["id"], "is_owner": bool(owner) and r.get("author_channel") == owner, "reply_count": 0})
    return items

def _impact(it, mx_likes, mx_rep, n_authors):
    f = it["f"]; content = len([t for t in f["toks"] if len(t) >= 4 and t not in STOP])
    likes_part = 25 * min(1, math.log1p(it["likes"]) / math.log1p(mx_likes)) if mx_likes else 0
    rep_part = 25 * min(1, math.log1p(it["reply_count"]) / math.log1p(mx_rep)) if mx_rep else 0
    parts = {"beğeni": likes_part, "cevap": rep_part, "tartışma_çeşitliliği": 10 * min(1, n_authors / 5), "içerik": 15 * min(1, content / 15),
             "görüş": 15 if (it["label"] in ("pozitif", "negatif", "karışık") or set(it["cats"]) & {"Eleştiri", "Öneri", "Şikâyet", "Bilgilendirme", "Soru", "Tartışma"}) else 0,
             "özgünlük": 10 if not it["dup"] else 0}
    s = sum(parts.values())
    if set(it["cats"]) & {"Spam", "Reklam"}: s *= .1
    return round(s, 1), parts, content

def analyze(video, threads, transcript_lines=None, collection=None):
    owner = video.get("channel_id") or ""
    items = flatten(threads, owner); by_id = {i["id"]: i for i in items}
    tr_text = " ".join(l["text"] for l in (transcript_lines or []))
    aud = [i for i in items if not i["is_owner"]]
    vocab = stems((video.get("title") or "") + " " + (video.get("description") or "")[:1500] + " " + tr_text[:4000])
    vt = detect_type(video.get("title") or "", video.get("description") or "", tr_text, " ".join(i["text"] for i in aud[:300]))
    # 1) ham özellikler
    for i in items: i["f"] = features(i["text"])
    # 2) tekrar/spam: aynı metin birden çok yerde. Kısa tepkiler ('helal') spam değil, 'tekrarlanan ifade'dir.
    groups = defaultdict(list)
    for i in aud:
        key = _CLEAN.sub(" ", i["f"]["norm"]).strip()
        if len(key) >= 12 or lex.URL.search(i["f"]["raw"]): groups[key].append(i)
    for g in groups.values():
        authors = {x.get("author_channel") or x.get("author") for x in g}
        dup = len(g) >= 3 or (len(g) >= 2 and len(authors) >= 2) or (len(g) >= 2 and len(authors) == 1)
        for x in g: x["dup"] = dup; x["dup_n"] = len(g)
    for i in items: i.setdefault("dup", False); i.setdefault("dup_n", 1)
    # 3) bağlam: cevapların tonu üst yoruma, üst yorumun tonu cevaplara
    kids = defaultdict(list)
    for i in items:
        if i["parent"]: kids[i["parent"]].append(i)
    for i in items:
        i["label"], i["conf"], i["ev"], i["ironic"] = sentiment(i["f"])
    for top in [i for i in items if i["parent"] is None]:
        rep = [k for k in kids[top["id"]] if not k["is_owner"]]
        neg_share = sum(k["label"] == "negatif" or k["ironic"] for k in rep) / len(rep) if rep else 0
        dis = sum(k["f"]["disagree"] for k in rep)
        top["heated"] = len(rep) >= 3 and dis / len(rep) >= .3
        top["label"], top["conf"], top["ev"], top["ironic"] = sentiment(top["f"], {"n_replies": len(rep), "reply_neg_share": neg_share})
        for k in rep: k["label"], k["conf"], k["ev"], k["ironic"] = sentiment(k["f"], {"parent": {"label": top["label"]}})
    # 4) yönler (aspect) ve alaka
    asp = {**lex.GENEL_YONLER, **lex.TUR_YONLER.get(vt["type"], {})}; asp_rx = {k: lex.compile_words(v) for k, v in asp.items()}
    for i in items:
        i["aspects"] = []
        if i["is_owner"] or i["dup"] or i["f"]["ad"]: continue
        clauses = [c for c in _SPLIT.split(i["f"]["raw"]) if c and c.strip()] or [i["f"]["raw"]]
        hit_clauses = 0
        for c in clauses:
            cn = lex.norm(c); hits = [k for k, rx in asp_rx.items() if rx.search(cn)]
            if not hits: continue
            hit_clauses += 1; p, n = clause_score(c)
            pol = "pozitif" if p >= .7 and p > n else "negatif" if n >= .7 and n > p else None
            for k in hits: i["aspects"].append((k, pol, c.strip()))
        if hit_clauses == 1 and i["label"] in ("pozitif", "negatif") and not i["ironic"]:   # tek yön bahsedilmiş ve cümle nötr: yorumun tonunu al
            i["aspects"] = [(k, pol or i["label"], c) for k, pol, c in i["aspects"]]
        if i["ironic"] or i["label"] == "belirsiz": i["aspects"] = [(k, None, c) for k, _, c in i["aspects"]]   # ironi şüphesi: yönü say, tonu atfetme
    for i in items:
        f = i["f"]; relevant = bool(stems(f["raw"]) & vocab) or bool(i["aspects"]) or max(f["pos"], f["neg"]) >= .7
        i["offtopic"] = len(vocab) >= 5 and not relevant and f["n_tok"] >= 1 and not f["question"] and not f["has_ts"]
    # 5) kategori
    for i in items:
        i["cat"], i["cats"] = categorize(i["f"], i["label"], {"dup": i["dup"], "heated": i.get("heated", False) or (i["parent"] is not None and i["f"]["disagree"]), "offtopic": i["offtopic"], "ironic": i["ironic"]})
    aud = [i for i in items if not i["is_owner"]]
    new_cats = _emerge_categories(aud)
    # 6) etki
    mxl = max([i["likes"] for i in aud] or [0]); mxr = max([i["reply_count"] for i in aud] or [0])
    likes_sorted = sorted(i["likes"] for i in aud); p90 = likes_sorted[int(.9 * (len(likes_sorted) - 1))] if likes_sorted else 0
    for i in items:
        authors = len({k.get("author_channel") or k.get("author") for k in kids[i["id"]]})
        i["impact"], i["impact_parts"], content = _impact(i, mxl, mxr, authors)
        i["shallow_viral"] = i["likes"] >= max(5, p90) and content <= 3 and i["parent"] is None
    topics = _topics(aud, by_id)
    disc = _discussion(items, kids, owner, aud)
    stats = _stats(aud, items, video, collection, vt, new_cats, topics)
    out_items = [{"id": i["id"], "parent": i["parent"], "author": i.get("author", ""), "owner": i["is_owner"], "likes": i["likes"], "published": i.get("published", ""), "reply_count": i["reply_count"],
                  "text": i["f"]["raw"], "label": i["label"], "confidence": round(i["conf"], 2), "irony": i["ironic"], "evidence": i["ev"], "category": i["cat"], "tags": i["cats"],
                  "impact": i["impact"], "impact_parts": {k: round(v, 1) for k, v in i["impact_parts"].items()}, "dup": i["dup"], "shallow_viral": i["shallow_viral"],
                  "aspects": [(a, p) for a, p, _ in i["aspects"]]} for i in items]
    return {"vid": video["id"], "video": {k: video.get(k) for k in ("id", "title", "description", "channel_id", "channel_title", "published", "tags", "comment_count", "view_count", "like_count")},
            "type": vt, "collection": collection or {}, "stats": stats, "topics": topics, "aspects": stats["aspects"], "discussion": disc, "comments": out_items,
            "transcript": {"available": bool(transcript_lines), "lines": len(transcript_lines or [])}}

def _emerge_categories(aud):
    """Hiçbir kategoriye girmeyen yorumlardan sık geçen konu kümeleri → otomatik yeni kategori."""
    rest = [i for i in aud if i["cat"] == "Diğer"]
    if len(rest) < 6: return []
    df = Counter(); surf = defaultdict(Counter)
    for i in rest:
        for t in set(i["f"]["toks"]):
            if len(t) >= 4 and t not in STOP and t not in GENERIC and t not in TOPIC_STOP: df[t[:5]] += 1; surf[t[:5]][t] += 1
    thr = max(3, math.ceil(.05 * len(rest))); keys = [k for k, v in df.most_common(8) if v >= thr]; made = Counter()
    for i in rest:
        mine = [k for k in keys if k in {t[:5] for t in i["f"]["toks"]}]
        if mine:
            k = max(mine, key=lambda x: df[x]); name = "Yeni: " + surf[k].most_common(1)[0][0]
            i["cat"] = name; i["cats"] = i["cats"] + [name]; made[name] += 1
    for i in rest:                                   # 3'ten küçük kümeler yeni kategori sayılmaz, 'Diğer'e döner
        if i["cat"].startswith("Yeni:") and made[i["cat"]] < 3: i["cats"] = [c for c in i["cats"] if c != i["cat"]]; i["cat"] = "Diğer"
    return [{"name": k, "n": v} for k, v in made.items() if v >= 3]

def _topics(aud, by_id, top=10):
    pool = [i for i in aud if not (set(i["cats"]) & {"Spam", "Reklam"}) and not i["dup"]]
    if not pool: return []
    n = len(pool); min_df = 3 if n >= 40 else 2
    uni, bi, surf = Counter(), Counter(), defaultdict(Counter); mem = defaultdict(set)
    for idx, i in enumerate(pool):
        toks = [t for t in i["f"]["toks"] if len(t) >= 3 and t not in STOP and t not in GENERIC and t not in TOPIC_STOP and not lex.pos_word(t) and not lex.neg_word(t)]
        ks = [t[:5] for t in toks]
        for k, t in zip(ks, toks): surf[k][t] += 1
        for k in set(ks): uni[k] += 1; mem[k].add(idx)
        seq = [t[:5] for t in i["f"]["toks"] if len(t) >= 3 and t not in STOP and t not in GENERIC and t not in TOPIC_STOP]
        for a, b in set(zip(seq, seq[1:])):
            if a != b: bi[(a, b)] += 1; mem[(a, b)].add(idx)
    cands = [(v, (k,), k) for k, v in uni.items() if v >= min_df] + [(v, k, k) for k, v in bi.items() if v >= min_df]
    cands.sort(key=lambda c: (-c[0], -len(c[1])))
    chosen = []; used = []
    for v, ks, key in cands:
        if any(set(ks) <= set(u) and v <= 1.4 * uv for u, uv in used) or any(set(u) < set(ks) and uv <= 1.4 * v for u, uv in used): continue
        label = " ".join(surf[k].most_common(1)[0][0] if surf[k] else k for k in ks)
        mi = sorted(mem[key]); lab = Counter(pool[x]["label"] for x in mi)
        best = sorted(mi, key=lambda x: -pool[x]["impact"])[:3]
        chosen.append({"topic": label, "n": v, "share": pct(v, n), "sentiment": dict(lab), "example_ids": [pool[x]["id"] for x in best], "ids": [pool[x]["id"] for x in mi]})
        used.append((ks, v))
        if len(chosen) >= top: break
    return chosen

def _discussion(items, kids, owner, aud):
    tops = [i for i in items if i["parent"] is None and not i["is_owner"]]
    rep_aud = [i for i in aud if i["parent"]]
    stance = Counter("katılıyor" if r["f"]["agree"] and not r["f"]["disagree"] else "karşı çıkıyor" if r["f"]["disagree"] else "nötr" for r in rep_aud)
    hot = []
    for t in sorted(tops, key=lambda x: -x["reply_count"])[:8]:
        ks = [k for k in kids[t["id"]]]
        if not ks: continue
        au = [k for k in ks if not k["is_owner"]]
        hot.append({"id": t["id"], "text": t["f"]["raw"][:200], "likes": t["likes"], "reply_count": t["reply_count"], "fetched_replies": len(ks), "authors": len({k.get("author_channel") or k.get("author") for k in au}),
                    "agree": sum(k["f"]["agree"] and not k["f"]["disagree"] for k in au), "disagree": sum(k["f"]["disagree"] for k in au), "heated": t.get("heated", False),
                    "owner_replied": any(k["is_owner"] for k in ks), "label": t["label"]})
    owner_known = bool(owner)
    cq = [t for t in tops if "Soru" in t["cats"] and not t["dup"]]
    answered = [t for t in cq if any(k["is_owner"] for k in kids[t["id"]])]
    return {"stance_counts": dict(stance), "n_reply_audience": len(rep_aud), "hot_threads": hot, "heated_threads": sum(1 for t in tops if t.get("heated")),
            "creator": {"known": owner_known, "top_level": sum(1 for i in items if i["is_owner"] and i["parent"] is None), "replies": sum(1 for i in items if i["is_owner"] and i["parent"]),
                        "threads_answered": sum(1 for t in tops if any(k["is_owner"] for k in kids[t["id"]])), "questions": len(cq), "questions_answered": len(answered)} if owner_known else {"known": False},
            "starters": [h["id"] for h in hot if h["reply_count"] >= 3][:5]}

def _stats(aud, items, video, collection, vt, new_cats, topics):
    n = len(aud); labs = Counter(i["label"] for i in aud); cats = Counter(i["cat"] for i in aud); tags = Counter(t for i in aud for t in i["cats"])
    asp = defaultdict(lambda: {"pozitif": 0, "negatif": 0, "belirsiz": 0, "nötr": 0, "ids": defaultdict(list)})
    for i in aud:
        for a, p, _ in {(a, p, c) for a, p, c in i["aspects"]}:
            key = p or "nötr"; asp[a][key] += 1; asp[a]["ids"][key].append(i["id"])
    aspects = [{"aspect": a, "pozitif": v["pozitif"], "negatif": v["negatif"], "nötr": v["nötr"], "toplam": v["pozitif"] + v["negatif"] + v["nötr"],
                "ids": {k: x[:20] for k, x in v["ids"].items()}} for a, v in asp.items()]
    aspects.sort(key=lambda x: -x["toplam"])
    reps = Counter(); first = {}
    for i in aud:
        k = _CLEAN.sub(" ", i["f"]["norm"]).strip()
        if len(k) >= 4 and not lex.URL.search(i["f"]["raw"]): reps[k] += 1
    phrases = [{"text": k, "n": v} for k, v in reps.most_common(15) if v >= 2][:10]
    return {"n_total": n, "n_top": sum(1 for i in aud if i["parent"] is None), "n_replies": sum(1 for i in aud if i["parent"]), "creator_items": sum(1 for i in items if i["is_owner"]),
            "sentiment": {k: {"n": labs.get(k, 0), "pct": pct(labs.get(k, 0), n)} for k in ("pozitif", "negatif", "nötr", "karışık", "belirsiz")},
            "irony": {"n": sum(1 for i in aud if i["ironic"]), "pct": pct(sum(1 for i in aud if i["ironic"]), n)},
            "humor": {"n": tags.get("Mizah", 0), "pct": pct(tags.get("Mizah", 0), n)},
            "categories": {k: {"n": v, "pct": pct(v, n)} for k, v in cats.most_common()}, "tags": dict(tags), "new_categories": new_cats,
            "spam": {"n": sum(1 for i in aud if set(i["cats"]) & {"Spam", "Reklam"}), "pct": pct(sum(1 for i in aud if set(i["cats"]) & {"Spam", "Reklam"}), n)},
            "questions": {"n": tags.get("Soru", 0), "pct": pct(tags.get("Soru", 0), n)}, "aspects": aspects[:14], "repeated_phrases": phrases,
            "top_liked": [i["id"] for i in sorted(aud, key=lambda x: -x["likes"])[:10] if i["likes"] > 0],
            "top_impact": [i["id"] for i in sorted((i for i in aud if not (set(i["cats"]) & {"Spam", "Reklam"})), key=lambda x: -x["impact"])[:10]],
            "shallow_viral": [i["id"] for i in aud if i["shallow_viral"]][:10], "promo_mentions": sum(1 for i in aud if i["f"]["promo_topic"]),
            "denominator": "analiz edilen izleyici yorumları (ana yorum + cevap; içerik üreticisinin kendi yorumları hariç)"}
