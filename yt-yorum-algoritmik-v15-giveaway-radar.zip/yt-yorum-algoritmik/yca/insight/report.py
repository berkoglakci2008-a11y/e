"""Doğal dilli rapor üretici. Metin yalnızca analiz sonucundaki sayılardan ve gerçek yorumlardan kurulur:
her sayı kayıt altına alınır (kalite denetimi için), her alıntı kaynağı yorumla birebir eşleşir. Cümle kalıpları çeşitlenir;
aynı veriden her üretimde farklı (ama aynı gerçekleri söyleyen) bir metin çıkar."""
import random, re
from collections import Counter
from ..textutil import tokens, STOP, GENERIC
from . import lex

FORMATS = {"kisa": "Kısa ve doğal özet", "detay": "Detaylı yorum analizi", "tepkiler": "İzleyici tepkileri", "olumlu_olumsuz": "Olumlu ve olumsuz değerlendirmeler",
           "tartisma": "Tartışma ve etkileşim analizi", "oneriler": "İçerik üreticisi için öneriler", "profesyonel": "Profesyonel analiz raporu"}
ADDRESS = {"abi", "hocam", "kardeşim", "reis", "usta", "hoca", "kral", "abim", "kardeş"}
SUGG_STOP = {"keşke", "lütfen", "yapsan", "yapsanız", "isterdim", "isterim", "bekliyoruz", "bekliyorum", "gelsin", "video", "bir", "daha", "yapsana", "rica", "yapın", "olsa"}

class Writer:
    def __init__(self, res, seed=None):
        self.r = res; self.s = res["stats"]; self.rng = random.Random(seed); self.allowed = set(); self.quotes = []; self.used = {}; self.used_q = set()
        self.cm = {c["id"]: c for c in res["comments"]}
        self.aud = [c for c in res["comments"] if not c["owner"]]; self.n = self.s["n_total"]

    # -- yardımcılar -------------------------------------------------------------------
    def num(self, x):
        self.allowed.add(float(x)); return str(int(x)) if float(x) == int(x) else str(x).replace(".", ",")
    def pc(self, p):
        if p is None: return "?"
        v = round(p); self.allowed.add(float(v)); self.allowed.add(float(p)); return "%" + str(v)
    def pick(self, key, opts):
        """Aynı havuzdan aynı kalıbı tekrar seçmez (havuz bitene kadar)."""
        seen = self.used.setdefault(key, set()); fresh = [i for i in range(len(opts)) if i not in seen] or list(range(len(opts)))
        if len(fresh) == len(opts): seen.clear()
        i = self.rng.choice(fresh); seen.add(i); return opts[i]
    def quote(self, pred=None, k=1, avoid=()):
        out = []
        pool = sorted((c for c in self.aud if not c["dup"] and not set(c["tags"]) & {"Spam", "Reklam"} and 18 <= len(c["text"]) <= 220 and (pred is None or pred(c)) and c["id"] not in self.used_q), key=lambda c: -c["impact"])
        seen = set(avoid)
        for c in pool:
            key = frozenset(t[:5] for t in tokens(c["text"].lower()) if len(t) >= 4)
            if key in seen: continue
            seen.add(key); self.used_q.add(c["id"]); t = c["text"]
            if len(t) > 130: t = t[:130].rsplit(" ", 1)[0] + "…"
            self.quotes.append(t); out.append("“" + t + "”")
            if len(out) >= k: break
        return out
    def aspect_rank(self, pol, k=3):
        thr = 3 if self.n >= 60 else 2
        rows = [(a["aspect"], a[pol], a["negatif" if pol == "pozitif" else "pozitif"]) for a in self.s["aspects"] if a[pol] >= thr and a[pol] > a["negatif" if pol == "pozitif" else "pozitif"]]
        return sorted(rows, key=lambda x: -x[1])[:k]
    def sh(self, key): return self.s["sentiment"][key]
    def cat(self, key): return self.s["categories"].get(key, {"n": 0, "pct": 0.0})
    def tag(self, key): return self.s["tags"].get(key, 0)
    def nm(self, x): return self.num(x)
    def coverage(self):
        c = self.r["collection"]; parts = []
        if not c: return ""
        parts.append(f"{self.nm(c.get('threads', 0))} ana yorum ve {self.nm(c.get('replies_fetched', 0))} cevap alındı")
        if c.get("reported_comment_count") is not None: parts.append(f"YouTube videoda yaklaşık {self.nm(c['reported_comment_count'])} yorum bildiriyor")
        else: parts.append("videonun toplam yorum sayısı alınamadı")
        txt = "; ".join(parts) + "."
        if not c.get("complete"): txt += " Yorumların tamamı alınamadı: " + " ".join(c.get("notes", [])) if c.get("notes") else " Yorumların tamamı alınamadı."
        if not self.r["transcript"]["available"]: txt += " Altyazı alınamadığı için bağlam yalnızca başlık, açıklama ve yorumlardan çıkarıldı."
        return txt

    # -- bulgu cümleleri -----------------------------------------------------------------
    def s_overview(self):
        s = self.s; n, t, rp = self.nm(s["n_total"]), self.nm(s["n_top"]), self.nm(s["n_replies"])
        return self.pick("ov", [f"{n} izleyici yorumuna baktım: {t} ana yorum, {rp} cevap.", f"Analize giren yorum sayısı {n}. Bunların {t} tanesi ana yorum, {rp} tanesi cevap.",
                                f"Toplam {n} yorum incelendi ({t} ana yorum, {rp} cevap).", f"Elimizde {n} yorum var; {t} tanesi ana yorum, kalanı cevap ({rp})."])
    def tilt(self):
        p, g = self.sh("pozitif"), self.sh("negatif"); d = (p["pct"] or 0) - (g["pct"] or 0)
        pn, gn, pp, gp = self.nm(p["n"]), self.nm(g["n"]), self.pc(p["pct"]), self.pc(g["pct"])
        if d >= 15: return self.pick("tilt+", [f"Ton olumlu ağırlıklı: {pn} yorum ({pp}) olumlu, {gn} yorum ({gp}) olumsuz.", f"Beğeni ağır basıyor. Olumlu {pn} yorum ({pp}), olumsuz {gn} yorum ({gp}).", f"Yorumlar daha çok memnun yönde: olumlu {pn} ({pp}), olumsuz {gn} ({gp})."])
        if d <= -15: return self.pick("tilt-", [f"Ton olumsuz ağırlıklı: {gn} yorum ({gp}) olumsuz, {pn} yorum ({pp}) olumlu.", f"Eleştiri öne çıkıyor. Olumsuz {gn} yorum ({gp}), olumlu {pn} yorum ({pp}).", f"Memnuniyetsiz yorumlar fazla: olumsuz {gn} ({gp}), olumlu {pn} ({pp})."])
        return self.pick("tilt=", [f"Tablo dengeli: olumlu {pn} yorum ({pp}), olumsuz {gn} yorum ({gp}).", f"İki taraf birbirine yakın. Olumlu {pn} ({pp}), olumsuz {gn} ({gp}).", f"Net bir taraf yok: {pn} yorum olumlu ({pp}), {gn} yorum olumsuz ({gp})."])
    def rest(self):
        u, m, b = self.sh("nötr"), self.sh("karışık"), self.sh("belirsiz")
        return self.pick("rest", [f"Gerisinin çoğu duygu taşımıyor: {self.nm(u['n'])} nötr ({self.pc(u['pct'])}), {self.nm(m['n'])} karışık, {self.nm(b['n'])} belirsiz.",
                                  f"Nötr yorumlar {self.nm(u['n'])} ({self.pc(u['pct'])}); karışık {self.nm(m['n'])}, belirsiz {self.nm(b['n'])}.",
                                  f"Kalan yorumlardan {self.nm(u['n'])} tanesi nötr ({self.pc(u['pct'])}), {self.nm(m['n'])} tanesi hem iyi hem kötü diyor, {self.nm(b['n'])} tanesi için yeterli bağlam yok."])
    def liked(self):
        r = self.aspect_rank("pozitif", 3)
        if not r: return ""
        (a, k, _), rest = r[0], r[1:]
        s = self.pick("lk", [f"En çok beğenilen yön {a}: {self.nm(k)} yorum bu konuda olumlu.", f"İzleyici en çok {a} tarafını sevmiş ({self.nm(k)} yorum).", f"Olumlu yorumlar çoğunlukla {a} üzerinde toplanıyor, {self.nm(k)} yorum."])
        if rest: s += " " + self.pick("lk2", ["Arkasından " + ", ".join(f"{a2} ({self.nm(k2)})" for a2, k2, _ in rest) + " geliyor.", "Sonra " + " ve ".join(f"{a2} ({self.nm(k2)})" for a2, k2, _ in rest) + " var."])
        return s
    def criticized(self):
        r = self.aspect_rank("negatif", 3)
        if not r: return ""
        (a, k, _), rest = r[0], r[1:]
        s = self.pick("cr", [f"En çok eleştirilen yön {a}: {self.nm(k)} yorum olumsuz.", f"Şikâyetler {a} etrafında toplanıyor ({self.nm(k)} yorum).", f"{a} konusunda {self.nm(k)} yorum memnun değil."])
        if rest: s += " " + self.pick("cr2", ["Ayrıca " + ", ".join(f"{a2} ({self.nm(k2)})" for a2, k2, _ in rest) + " eleştiriliyor.", "Daha az sayıda yorumla " + " ve ".join(f"{a2} ({self.nm(k2)})" for a2, k2, _ in rest) + " de var."])
        return s
    def topics(self, k=3):
        t = self.r["topics"][:k]
        if not t: return ""
        lst = ", ".join(f"{x['topic']} ({self.nm(x['n'])})" for x in t)
        return self.pick("tp", [f"En çok konuşulan başlıklar: {lst}.", f"Yorumlarda en sık geçen konular {lst}.", f"Öne çıkan konular şunlar: {lst}."])
    def discussion(self):
        d = self.r["discussion"]; hot = [h for h in d["hot_threads"] if h["fetched_replies"] >= 2]
        if not hot: return "", None
        h = max(hot, key=lambda x: x["reply_count"]); q = self.quote(lambda c: c["id"] == h["id"])
        s = self.pick("ds", [f"En çok cevap alan yorum {self.nm(h['reply_count'])} cevap toplamış; cevaplardan {self.nm(h['disagree'])} tanesi karşı çıkıyor, {self.nm(h['agree'])} tanesi katılıyor.",
                             f"Tartışma en çok bir yorumun altında büyümüş: {self.nm(h['reply_count'])} cevap, {self.nm(h['disagree'])} itiraz, {self.nm(h['agree'])} onay.",
                             f"Bir yorum {self.nm(h['reply_count'])} cevap almış; {self.nm(h['authors'])} farklı kişi yazmış, {self.nm(h['disagree'])} cevap karşı çıkıyor."])
        return s, (q[0] if q else None)
    def creator(self):
        c = self.r["discussion"]["creator"]
        if not c["known"]: return "Üreticinin kanal kimliği alınamadığı için üretici cevapları ayrıştırılamadı."
        if c["replies"] + c["top_level"] == 0: return self.pick("cr0", ["Alınan yorumlar arasında üreticinin kendi yazdığı yorum ya da cevap yok.", "Üretici yorumlara karışmamış görünüyor; alınan veride cevabı yok."])
        return self.pick("cr1", [f"Üretici {self.nm(c['replies'])} cevap yazmış ({self.nm(c['threads_answered'])} yorum dizisinde).", f"Üreticiden {self.nm(c['replies'])} cevap var, {self.nm(c['threads_answered'])} diziye girmiş."])
    def questions(self):
        q = self.s["questions"]; c = self.r["discussion"]["creator"]
        if not q["n"]: return ""
        s = self.pick("qs", [f"{self.nm(q['n'])} yorum soru soruyor ({self.pc(q['pct'])}).", f"Soru içeren yorum sayısı {self.nm(q['n'])} ({self.pc(q['pct'])})."])
        if c.get("known") and c["questions"]: s += f" Üretici bunlardan {self.nm(c['questions_answered'])} tanesini yanıtlamış (ana yorum olarak sorulan {self.nm(c['questions'])} sorudan)."
        return s
    def suggestions(self, thr=3):
        k = self.tag("Öneri")
        if k < thr: return ""
        df = Counter(t for c in self.aud if "Öneri" in c["tags"] and not c["dup"] for t in set(tokens(c["text"].lower())) if len(t) >= 4 and t not in STOP and t not in GENERIC and t not in SUGG_STOP and not lex.pos_word(t))
        w = [t for t, v in df.most_common(3) if v >= 2]
        s = self.pick("sg", [f"{self.nm(k)} yorum bir istek ya da öneri içeriyor.", f"Öneri ya da beklenti yazan {self.nm(k)} yorum var."])
        if w: self.allowed.update(float(df[t]) for t in w); s += " En sık geçen kelimeler: " + ", ".join(w) + "."
        return s
    def complaints(self, thr=3):
        k = self.tag("Şikâyet")
        if k < thr: return ""
        asp = Counter(a for c in self.aud if "Şikâyet" in c["tags"] for a, _ in c["aspects"]); top = asp.most_common(1)
        s = self.pick("cp", [f"Şikâyet niteliğinde {self.nm(k)} yorum var.", f"{self.nm(k)} yorum doğrudan bir şikâyet dile getiriyor."])
        if top: s += f" En çok {top[0][0]} konusunda ({self.nm(top[0][1])})."
        return s
    def humor_irony(self):
        h, i = self.s["humor"], self.s["irony"]; out = []
        if h["n"] >= 2: out.append(self.pick("hm", [f"{self.nm(h['n'])} yorum espri ya da gülme içeriyor ({self.pc(h['pct'])}).", f"Mizahi yorum sayısı {self.nm(h['n'])} ({self.pc(h['pct'])})."]))
        if i["n"] >= 2: out.append(self.pick("ir", [f"{self.nm(i['n'])} yorumda alay işareti var; kanıtı zayıf olanları 'belirsiz' bıraktım.", f"Alaycı görünen {self.nm(i['n'])} yorum çıktı. Bağlamı yetmeyenleri olumlu ya da olumsuz saymadım."]))
        return " ".join(out)
    def spam(self):
        sp = self.s["spam"]
        if not sp["n"]: return "Belirgin spam ya da reklam yorumu bulunmadı."
        return self.pick("sp", [f"{self.nm(sp['n'])} yorum ({self.pc(sp['pct'])}) spam ya da reklam gibi duruyor; bunlar duygu istatistiklerini şişirmesin diye konu ve alıntılardan çıkarıldı.",
                                f"Spam/reklam benzeri yorum: {self.nm(sp['n'])} ({self.pc(sp['pct'])}). Konu ve alıntı seçiminde bunları saymadım."])
    def viral(self):
        v = self.s["shallow_viral"]
        if not v: return ""
        return self.pick("vi", [f"{self.nm(len(v))} yorum çok beğeni almış ama içeriği çok kısa (örneğin tek kelimelik tepki). Etki puanında beğeniye en fazla %25 ağırlık verdiğim için bunlar öne geçmedi.",
                                f"Yüksek beğenili ama içerik taşımayan {self.nm(len(v))} yorum var. Beğeni sayısı görüşün doğruluğunu göstermediği için etki sıralamasında geri kaldılar."])
    def promo(self):
        d = (self.r["video"].get("description") or ""); k = self.s["promo_mentions"]
        if k >= 3 and lex.PROMO_TOPIC.search(lex.norm(d)): return f"Açıklamada kod/tanıtım benzeri bir ifade var ve {self.nm(k)} yorum bu tür konulara değiniyor."
        return ""
    def influential(self):
        ids = self.s["top_impact"][:1]
        if not ids: return ""
        c = self.cm[ids[0]]; q = self.quote(lambda x: x["id"] == c["id"])
        if not q: return ""
        return self.pick("inf", [f"En etkili yorum {self.nm(c['likes'])} beğeni ve {self.nm(c['reply_count'])} cevap almış: {q[0]}", f"Etki puanı en yüksek yorum ({self.nm(c['likes'])} beğeni, {self.nm(c['reply_count'])} cevap): {q[0]}"])
    def lead_q(self, q):
        return self.pick("lq", ["Örneğin " + q + ".", "Biri şöyle yazmış: " + q + ".", q + " diyen de var.", "Bir yorumda şu geçiyor: " + q + "."]) if q else ""
    def addressed(self):
        a = [c for c in self.aud if set(tokens(c["text"].lower())) & ADDRESS]
        if len(a) < 3: return ""
        pos = sum(c["label"] == "pozitif" for c in a); neg = sum(c["label"] == "negatif" for c in a)
        return f"Üreticiye doğrudan seslenen {self.nm(len(a))} yorum var; {self.nm(pos)} tanesi olumlu, {self.nm(neg)} tanesi olumsuz."

def _join(*xs): return " ".join(x for x in xs if x)
def _p(t): return {"p": t} if t else None
def _clean(bl): return [b for b in bl if b]

def build(res, fmt="kisa", seed=None):
    w = Writer(res, seed); r = w.rng; s = w.s
    if not s["n_total"]:
        why = " ".join(res["collection"].get("notes", [])) or "Analiz edilecek yorum alınamadı."
        return {"format": fmt, "title": FORMATS.get(fmt, fmt), "blocks": [{"p": why}], "quotes": [], "allowed": []}
    H = lambda key, opts: {"h": w.pick("h" + key, opts)}
    cov = w.coverage(); blocks = []
    liked, crit = w.liked(), w.criticized(); both = [liked, crit]; r.shuffle(both)
    ql = w.lead_q(next(iter(w.quote(lambda c: c["label"] == "pozitif" and c["impact"] > 0)), None)) if (liked and r.random() < .6) else ""
    qc = w.lead_q(next(iter(w.quote(lambda c: c["label"] == "negatif" and not c["irony"])), None)) if (crit and r.random() < .6) else ""
    if fmt == "kisa":
        blocks += [_p(_join(w.s_overview(), w.tilt(), w.rest() if r.random() < .5 else ""))]
        blocks += [_p(_join(*(both if r.random() < .5 else both[::-1]), ql if liked else "", qc if crit else ""))]
        watch = [x for x in (w.discussion()[0], w.questions(), w.spam() if s["spam"]["n"] else "", w.humor_irony()) if x]
        blocks += [_p(_join(*r.sample(watch, min(2, len(watch)))))]
        if not res["collection"].get("complete", True): blocks += [_p(cov)]
    elif fmt == "detay":
        secs = {"genel": [H("g", ["Genel tablo", "Ana hatlarıyla", "Yorumlara toplu bakış"]), _p(_join(w.s_overview(), w.tilt(), w.rest(), w.humor_irony()))],
                "sev": [H("s", ["Beğenilenler", "Neyi sevmişler", "İzleyicinin sevdiği taraflar"]), _p(_join(liked, ql, w.influential()))] if liked else [],
                "elestiri": [H("e", ["Eleştirilenler", "Neye takılmışlar", "Şikâyet edilen yönler"]), _p(_join(crit, w.complaints(), qc))] if (crit or w.complaints()) else [],
                "konu": [H("k", ["Konuşulan başlıklar", "Konular", "Neler konuşuluyor"]), _p(_join(w.topics(5), w.promo()))] if w.topics() else [],
                "tart": [H("t", ["Tartışma ve cevaplar", "İnsanlar birbirine ne diyor", "Etkileşim"]), _p(_join(*[x for x in (w.discussion()[0], w.creator(), w.questions()) if x]))],
                "dikkat": [H("d", ["Dikkat edilecekler", "Veriyi okurken", "Temkinli okunması gerekenler"]), _p(_join(w.spam(), w.viral(), w.suggestions()))]}
        order = ["genel"] + r.sample(["sev", "elestiri", "konu", "tart"], 4) + ["dikkat"]
        for k in order: blocks += secs[k]
        blocks += [H("v", ["Veri notu", "Verinin sınırı"]), _p(cov)]
    elif fmt == "tepkiler":
        blocks += [_p(_join(w.s_overview(), w.tilt(), w.addressed()))]
        wants = _join(w.suggestions(thr=2), w.questions(), w.complaints(thr=2))
        blocks += [H("a", ["İzleyici ne bekliyor", "İstekler ve sorular"]), _p(wants or "İstek, soru ya da şikâyet olarak öne çıkan belirgin bir küme yok.")]
        blocks += [H("b", ["Ne konuşuyorlar", "Yorumların konusu"]), _p(_join(w.topics(5), w.lead_q(next(iter(w.quote(lambda c: c["label"] != "nötr")), None))))]
        st = w.r["discussion"]["stance_counts"]
        if w.r["discussion"]["n_reply_audience"]:
            a, d_, nt = st.get("katılıyor", 0), st.get("karşı çıkıyor", 0), st.get("nötr", 0)
            blocks += [H("c", ["Birbirlerine tepkileri", "Cevaplarda ne oluyor"]), _p(_join(f"{w.nm(w.r['discussion']['n_reply_audience'])} cevabın {w.nm(a)} tanesi önceki yorumu onaylıyor, {w.nm(d_)} tanesi karşı çıkıyor, {w.nm(nt)} tanesi ikisi de değil.", w.creator()))]
        blocks += [_p(w.humor_irony()), H("v", ["Veri notu"]), _p(cov)]
    elif fmt == "olumlu_olumsuz":
        p, g = w.sh("pozitif"), w.sh("negatif")
        qs_p = w.quote(lambda c: c["label"] == "pozitif", 2); qs_n = w.quote(lambda c: c["label"] == "negatif" and not c["irony"], 2)
        blocks += [{"h": "Olumlu"}, _p(_join(f"{w.nm(p['n'])} yorum ({w.pc(p['pct'])}) olumlu.", liked or "Belirli bir yön etrafında toplanan olumlu yorum kümesi çıkmadı.")), {"ul": qs_p} if qs_p else None]
        blocks += [{"h": "Olumsuz"}, _p(_join(f"{w.nm(g['n'])} yorum ({w.pc(g['pct'])}) olumsuz.", crit or "Belirli bir yön etrafında toplanan olumsuz yorum kümesi çıkmadı.", w.complaints())), {"ul": qs_n} if qs_n else None]
        m, b = w.sh("karışık"), w.sh("belirsiz")
        blocks += [{"h": "Ortada kalanlar"}, _p(f"{w.nm(m['n'])} yorum hem olumlu hem olumsuz şey söylüyor, {w.nm(b['n'])} yorumun tonu için yeterli kanıt yok. {w.humor_irony()}".strip()), _p(cov)]
    elif fmt == "tartisma":
        d = res["discussion"]; hot = d["hot_threads"]
        blocks += [_p(_join(w.s_overview(), w.creator()))]
        if not hot: blocks += [_p("Cevap alan yorum bulunmadığı ya da cevaplar alınamadığı için tartışma analizi yapılamadı.")]
        else:
            ln, q0 = [], []
            for h in hot[:5]:
                qq = w.quote(lambda c, h=h: c["id"] == h["id"]); t = f"{w.nm(h['reply_count'])} cevap, {w.nm(h['authors'])} farklı kişi, {w.nm(h['agree'])} onay / {w.nm(h['disagree'])} itiraz" + (", üretici cevap vermiş" if h["owner_replied"] else "")
                ln.append(t + (": " + qq[0] if qq else ""))
            blocks += [H("t", ["En çok cevap alan yorumlar", "Konuşmanın döndüğü yerler"]), {"ul": ln}]
            hc = d["heated_threads"]; blocks += [_p(f"Cevapların en az üçte biri itiraz içeren {w.nm(hc)} yorum dizisi var." if hc else "İtirazın baskın olduğu bir yorum dizisi görünmüyor.")]
        st = d["stance_counts"]
        if d["n_reply_audience"]: blocks += [_p(f"Cevap yazan izleyicilerin {w.nm(st.get('katılıyor', 0))} tanesi katılıyor, {w.nm(st.get('karşı çıkıyor', 0))} tanesi karşı çıkıyor ({w.nm(d['n_reply_audience'])} cevap içinde).")]
        blocks += [_p(w.questions()), _p(cov)]
    elif fmt == "oneriler":
        ul = []; thr = 3 if w.n >= 60 else 2
        HINT = {"ses / müzik": "Ses seviyesi ve mikrofon ayarını kontrol etmeye değer.", "süre / tempo": "Videonun temposu ya da uzunluğu bir sonraki kurguda gözden geçirilebilir.",
                "reklam / sponsor": "Reklam ve tanıtım bölümlerinin yerini ve açıklamasını açık tutmak yorumdaki tepkiyi azaltabilir.", "güven / dürüstlük": "İzleyici güveni konusu açık: işin nasıl yapıldığını açıkça anlatmak ya da sabitlenmiş bir yorumla yanıt vermek işe yarayabilir.",
                "başlık / kapak": "Başlık ve kapağın verdiği beklentiyle içeriğin uyumuna bakın.", "görüntü kalitesi": "Görüntü/ışık tarafındaki geri bildirimleri kontrol edin.", "kurgu / montaj": "Kurguyla ilgili yorumları tek tek okuyup tekrar eden noktayı çıkarın."}
        for a, k, _ in w.aspect_rank("negatif", 3): ul.append(f"{a}: {w.nm(k)} yorum olumsuz. " + HINT.get(a, "İlgili yorumları okuyup ortak noktayı belirleyin."))
        c = res["discussion"]["creator"]
        if c.get("known") and c["questions"] - c["questions_answered"] >= thr: ul.append(f"{w.nm(c['questions'] - c['questions_answered'])} soru yorumu üretici cevabı almamış. Sık sorulanlar için sabit bir yorum ya da kısa bir cevap yeterli olur.")
        sg = w.suggestions(thr=thr)
        if sg: ul.append(sg + " Bunlar bir sonraki içerik fikri için doğrudan geri bildirim.")
        if s["spam"]["pct"] and s["spam"]["pct"] >= 3 and s["spam"]["n"] >= thr: ul.append(f"{w.nm(s['spam']['n'])} yorum ({w.pc(s['spam']['pct'])}) spam/reklam benzeri. YouTube Studio'daki yorum filtreleri ve engellenen kelime listesi işi hafifletir.")
        if res["discussion"]["heated_threads"]: ul.append(f"{w.nm(res['discussion']['heated_threads'])} yorum dizisinde itiraz yoğun. Üreticinin tek bir açıklayıcı cevabı tartışmayı yönlendirebilir.")
        for a, k, _ in w.aspect_rank("pozitif", 2): ul.append(f"{a} beğenilen taraf ({w.nm(k)} yorum); bu yönü korumak mantıklı.")
        blocks += [_p("Önerileri yalnızca yorumlarda en az " + w.nm(thr) + " kez geçen kalıplardan çıkardım. Daha az görülen şeyler için öneri yazmadım."), {"ul": ul} if ul else _p("Veri belirgin bir öneri çıkaracak kadar güçlü değil."), _p(cov)]
    else:   # profesyonel
        rows = [[k, w.nm(v["n"]), w.pc(v["pct"])] for k, v in s["sentiment"].items()]
        cats = [[k, w.nm(v["n"]), w.pc(v["pct"])] for k, v in list(s["categories"].items())[:11]]
        top = [[t["topic"], w.nm(t["n"]), w.pc(t["share"]), ", ".join(f"{k} {w.nm(v)}" for k, v in t["sentiment"].items())] for t in res["topics"][:10]]
        asp = [[a["aspect"], w.nm(a["pozitif"]), w.nm(a["negatif"]), w.nm(a["nötr"])] for a in s["aspects"][:8]]
        blocks += [{"h": "Kapsam"}, _p(f"Video türü: {res['type']['type']} (güven {w.nm(res['type']['confidence'])}). Payda: {s['denominator']}; N = {w.nm(s['n_total'])}."), _p(cov)]
        blocks += [{"h": "Özet bulgular"}, _p(_join(w.tilt(), w.rest(), liked, crit)), {"h": "Duygu dağılımı"}, {"table": {"head": ["Etiket", "Yorum", "Oran"], "rows": rows}},
                   {"h": "Kategoriler"}, {"table": {"head": ["Kategori", "Yorum", "Oran"], "rows": cats}}]
        if top: blocks += [{"h": "Konular"}, {"table": {"head": ["Konu", "Yorum", "Oran", "Duygu"], "rows": top}}]
        if asp: blocks += [{"h": "Yönler (olumlu / olumsuz / nötr)"}, {"table": {"head": ["Yön", "Olumlu", "Olumsuz", "Nötr"], "rows": asp}}]
        blocks += [{"h": "Etkileşim"}, _p(_join(w.creator(), w.questions(), w.discussion()[0])), {"h": "Risk ve veri kalitesi"}, _p(_join(w.spam(), w.viral(), w.humor_irony()))]
        blocks += [{"h": "Yöntem ve sınırlar"}, _p("Sınıflandırma kural tabanlı: Türkçe/İngilizce sözlük, olumsuzlama, emoji, ironi işaretleri ve cevap/üst yorum bağlamı. Makine öğrenmesi ya da dil modeli kullanılmadı. "
                                                  "Elle etiketlenmiş bir veri setiyle doğruluk ölçülmedi; yüzdeler bu yüzden kesin değil, sözlüğün yakaladığı kadarını gösterir. Bağlamı yetmeyen yorumlar 'belirsiz' sayıldı.")]
    return {"format": fmt, "title": FORMATS.get(fmt, fmt), "blocks": _clean(blocks), "quotes": w.quotes, "allowed": sorted(w.allowed)}

def to_markdown(rep, video=None):
    out = []
    if video: out.append(f"# {video.get('title') or video.get('id')}\n")
    out.append(f"_{rep['title']}_\n")
    for b in rep["blocks"]:
        if "h" in b: out.append(f"\n## {b['h']}\n")
        elif "p" in b: out.append(b["p"] + "\n")
        elif "ul" in b: out.append("\n".join("- " + x for x in b["ul"]) + "\n")
        elif "table" in b:
            t = b["table"]; out.append("| " + " | ".join(t["head"]) + " |\n|" + "---|" * len(t["head"]) + "\n" + "\n".join("| " + " | ".join(r) + " |" for r in t["rows"]) + "\n")
    return "\n".join(out)

def blocks_text(rep):
    parts = []
    for b in rep["blocks"]:
        if "h" in b: parts.append(b["h"])
        elif "p" in b: parts.append(b["p"])
        elif "ul" in b: parts += b["ul"]
        elif "table" in b: parts += [" ".join(r) for r in b["table"]["rows"]]
    return "\n".join(parts)
