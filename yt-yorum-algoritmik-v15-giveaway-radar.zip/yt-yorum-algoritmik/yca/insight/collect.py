"""Yorum toplama: sayfalama, cevaplar, kota/hata yönetimi, tekrar kontrolü. Erişilemeyen veri uydurulmaz; rapora 'neden eksik' yazılır."""
import time
from .. import ytapi

def _norm_comment(c, parent=None):
    s = c.get("snippet", {})
    return {"id": c.get("id", ""), "text": s.get("textOriginal") or s.get("textDisplay", ""), "author": s.get("authorDisplayName", ""),
            "author_channel": (s.get("authorChannelId") or {}).get("value", ""), "likes": int(s.get("likeCount", 0) or 0),
            "published": s.get("publishedAt", ""), "updated": s.get("updatedAt", ""), "parent": parent}

def _retry(fn, sleep, tries=3):
    for k in range(tries):
        try: return fn()
        except ytapi.Transient:
            if k == tries - 1: raise
            sleep(2 ** k)

def fetch_all(client, vid, max_threads=2000, include_replies=True, max_reply_calls=300, order="relevance", progress=None, sleep=time.sleep):
    """(video, threads, collection). threads: [{id,text,author,author_channel,likes,published,reply_count,replies:[...]}]."""
    prog = progress or (lambda s, p: None)
    video = _retry(lambda: client.video_info(vid), sleep)
    col = {"status": "ok", "pages": 0, "reply_calls": 0, "quota_start": client.quota, "threads": 0, "replies_fetched": 0, "replies_reported": 0, "truncated_replies": 0,
           "duplicates_skipped": 0, "reported_comment_count": video.get("comment_count"), "capped": False, "complete": True, "notes": [], "max_threads": max_threads, "order": order}
    if video.get("comment_count") is None:
        col["notes"].append("Videonun yorum sayısı bildirilmemiş (yorumlar kapalı olabilir).")
    threads, seen, token = [], set(), None
    try:
        while len(threads) < max_threads:
            q = {"part": "snippet,replies", "videoId": vid, "maxResults": 100, "order": order, "textFormat": "plainText"}
            if token: q["pageToken"] = token
            body = _retry(lambda: client.get("/commentThreads", q), sleep); col["pages"] += 1
            for it in body.get("items", []):
                top = _norm_comment(it["snippet"]["topLevelComment"])
                if not top["id"] or top["id"] in seen: col["duplicates_skipped"] += 1; continue
                seen.add(top["id"]); total = int(it["snippet"].get("totalReplyCount", 0) or 0)
                reps = [_norm_comment(r, top["id"]) for r in (it.get("replies") or {}).get("comments", [])]
                top.update(reply_count=total, replies=reps); col["replies_reported"] += total
                if include_replies and total > len(reps) and col["reply_calls"] < max_reply_calls:
                    reps = _all_replies(client, top["id"], reps, col, sleep); top["replies"] = reps
                col["replies_fetched"] += len(top["replies"]); col["truncated_replies"] += max(0, total - len(top["replies"]))
                threads.append(top)
                if len(threads) >= max_threads: break
            token = body.get("nextPageToken")
            prog(f"Yorumlar alınıyor ({len(threads)})", .1 + .5 * min(1, len(threads) / max(1, min(max_threads, video.get("comment_count") or max_threads))))
            if not token: break
        else: col["capped"] = bool(token)
        if token and len(threads) >= max_threads: col["capped"] = True
    except ytapi.CommentsDisabled:
        col["status"] = "comments_disabled"; col["notes"].append("Bu videoda yorumlar kapalı; analiz edilecek yorum yok.")
    except ytapi.QuotaExceeded:
        col["status"] = "quota_partial"; col["notes"].append("Günlük API kotası doldu; yalnızca o ana kadar alınan yorumlar analiz edildi.")
    except ytapi.Transient as e:
        col["status"] = "network_partial"; col["notes"].append("Bağlantı hatası nedeniyle yorum alma yarıda kaldı: " + str(e))
    col["threads"] = len(threads); col["quota_used"] = client.quota - col.pop("quota_start")
    if col["capped"]: col["notes"].append(f"Üst sınır ({max_threads} ana yorum) nedeniyle yorumların tamamı alınmadı.")
    if col["truncated_replies"]: col["notes"].append(f"{col['truncated_replies']} cevap alınamadı (cevap çağrı sınırı ya da kota).")
    col["complete"] = col["status"] == "ok" and not col["capped"] and not col["truncated_replies"]
    return video, threads, col

def _all_replies(client, parent, have, col, sleep):
    out, ids, token = list(have), {r["id"] for r in have}, None
    while True:
        q = {"part": "snippet", "parentId": parent, "maxResults": 100, "textFormat": "plainText"}
        if token: q["pageToken"] = token
        try: body = _retry(lambda: client.get("/comments", q), sleep)
        except (ytapi.QuotaExceeded, ytapi.Transient): col["notes"].append("Bazı cevaplar kota/bağlantı nedeniyle eksik."); break
        col["reply_calls"] += 1
        for c in body.get("items", []):
            r = _norm_comment(c, parent)
            if r["id"] in ids: col["duplicates_skipped"] += 1; continue
            ids.add(r["id"]); out.append(r)
        token = body.get("nextPageToken")
        if not token: break
    return out
