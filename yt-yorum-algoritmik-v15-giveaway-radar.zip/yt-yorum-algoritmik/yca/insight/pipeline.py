"""Toplama → analiz → rapor → kalite denetimi. Ham veri data/comments/, sonuç data/analysis/ altında saklanır."""
import datetime, json, os, re, tempfile, time
from . import collect, engine, report, lex

def _save(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f: json.dump(obj, f, ensure_ascii=False)
    os.replace(tmp, path)

def _load(path):
    try:
        with open(path, encoding="utf-8") as f: return json.load(f)
    except FileNotFoundError: return None

def check_report(rep, res):
    """Kalite denetimi: (sorunlar listesi, yapılan kontroller). Boş liste = tüm kontroller geçti."""
    issues, text = [], report.blocks_text(rep)
    plain = re.sub(r"“[^”]*”", " ", text)
    comments = [c for c in res["comments"] if not c["owner"]]
    # 1) alıntılar gerçek yorumlarda birebir geçmeli
    for q in rep["quotes"]:
        if not any(q.rstrip("…") in c["text"] for c in comments): issues.append(f"uydurma alıntı: {q[:40]}")
    # 2) istatistikler ham yorumlardan yeniden sayılıp karşılaştırılır
    n = len(comments); s = res["stats"]
    if n != s["n_total"]: issues.append("yorum sayısı tutarsız")
    for k, v in s["sentiment"].items():
        if sum(1 for c in comments if c["label"] == k) != v["n"]: issues.append(f"duygu sayısı tutarsız: {k}")
    if sum(v["n"] for v in s["sentiment"].values()) != n: issues.append("duygu sayıları toplamı payda ile uyuşmuyor")
    # 3) metindeki her sayı rapor üretirken kaydedilmiş olmalı
    allowed = set(rep["allowed"]) | {0.0, 1.0, 2.0, 3.0, 25.0}
    for m in re.findall(r"\d+(?:,\d+)?", plain):
        if float(m.replace(",", ".")) not in allowed and not re.search(r"2026|2025", m): issues.append(f"kayıtsız sayı: {m}")
    # 4) kalıp ifadeler ve tekrar
    low = plain.lower()
    for ph in lex.STOCK_PHRASES:
        if low.count(ph) > 1: issues.append(f"kalıp tekrarı: {ph}")
    prose = re.sub(r"“[^”]*”", " ", "\n".join(b["p"] for b in rep["blocks"] if "p" in b))   # madde/tablo satırları kalıp olduğu için hariç
    sents = [set(re.findall(r"\w+", x.lower())) for x in re.split(r"(?<=[.!?])\s+|\n", prose) if len(x.split()) >= 5]
    for i in range(len(sents)):
        for j in range(i + 1, len(sents)):
            if len(sents[i] & sents[j]) / len(sents[i] | sents[j]) > .75: issues.append("neredeyse aynı iki cümle")
    openers = [x.split()[0].lower() for x in re.split(r"(?<=[.!?])\s+", plain) if x.split()]
    for i in range(len(openers) - 2):
        if openers[i] == openers[i + 1] == openers[i + 2]: issues.append(f"üç cümle art arda '{openers[i]}' ile başlıyor")
    return issues, ["alıntı doğruluğu", "istatistik yeniden sayımı", "sayıların kaynağı", "kalıp ifade", "tekrarlanan cümle", "art arda aynı başlangıç"]

def make_report(res, fmt="kisa", seed=None, tries=8):
    """Denetimden geçene kadar yeniden üretir; geçemezse en az sorunlu sürümü sorunlarıyla birlikte döner."""
    best = None
    for k in range(tries):
        rep = report.build(res, fmt, None if seed is None else seed + k)
        issues, checks = check_report(rep, res)
        if best is None or len(issues) < len(best[1]): best = (rep, issues, checks)
        if not issues: break
    rep, issues, checks = best
    rep["quality"] = {"passed": not issues, "issues": issues, "checks": checks, "attempts": k + 1}
    return rep

def run(vid, data_dir, client, max_threads=2000, include_replies=True, progress=None, raw=None, transcript_fetcher=None):
    """raw verilirse (video, threads, collection) ağ kullanılmaz (dosyadan çözümleme)."""
    prog = progress or (lambda s, p: None)
    prog("Video ve yorumlar alınıyor", .05)
    video, threads, col = raw if raw else collect.fetch_all(client, vid, max_threads=max_threads, include_replies=include_replies, progress=prog)
    if not raw: _save(os.path.join(data_dir, "comments", vid + ".json"), {"video": video, "threads": threads, "collection": col, "fetched": datetime.datetime.now().isoformat(timespec="seconds")})
    lines = None; note = None
    if transcript_fetcher:
        prog("Altyazı alınıyor", .65)
        try:
            from ..subtitles import parse_subtitles
            lines = parse_subtitles(transcript_fetcher(vid)[0])
        except Exception as e: note = f"Altyazı alınamadı ({type(e).__name__})."
    prog("Yorumlar analiz ediliyor", .75)
    res = engine.analyze(video, threads, lines, col)
    if note: res["collection"].setdefault("notes", []).append(note)
    res["created"] = datetime.datetime.now().isoformat(timespec="seconds")
    _save(os.path.join(data_dir, "analysis", vid + ".json"), res)
    prog("Bitti", 1)
    return res

def load(data_dir, vid): return _load(os.path.join(data_dir, "analysis", vid + ".json"))
