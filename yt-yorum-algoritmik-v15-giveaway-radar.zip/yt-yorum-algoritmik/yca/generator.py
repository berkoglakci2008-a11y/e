import random, re
from collections import deque
from .textutil import tr_lower, STOP, GENERIC, tokens
from .lexicon import RAW, WEAK_RAW
from .templates_db import CommentTemplateDatabase, TRIGGERS, EXT, FR

def _norm(s): return re.sub(r"\W+", " ", tr_lower(s)).strip()

class DuplicateCommentFilter:
    """Aynı yorumu ve art arda aynı çekirdeği engeller."""
    def __init__(self, preload=(), recent=8):
        self.seen = {_norm(t) for t in preload}; self.recent = deque(maxlen=recent); self.openers = deque(maxlen=3)
    def accept(self, text, core_id, strict=True):
        w = _norm(text).split(); first = w[0] if w else ""
        if _norm(text) in self.seen or (strict and (core_id in self.recent or first in self.openers)): return False   # art arda aynı kelimeyle başlama
        self.seen.add(_norm(text)); self.recent.append(core_id); self.openers.append(first); return True

EMOJI = {"Komik": ["😂", "🤣"], "Şaşkınlık": ["😮", "🤯"], "Destekleyici": ["👏", "❤️"], "Duygusal": ["❤️", "🥹"], "Genel": ["🔥", "👀"]}
_W = re.compile(r"[^\W_]+(?:['’][^\W_]+)?")

FILLERS = {"bence", "valla", "lan", "ya", "be", "abi", "resmen", "yani", "ha", "ee", "off", "kral", "bi"}

_REACT = tuple({w.rstrip("*") for src in (RAW, WEAK_RAW) for grp in src.get("tr", {}).values() for ph in grp for w in ph.split() if len(w.rstrip("*")) >= 4} | {"inanam", "inanıl", "beklem", "şaşır", "sinir", "üzücü", "rezalet", "kötü", "güzel"})

def content_kw(text):
    """Videoya özgü kelime bulunamazsa yedek: tepki/duygu kelimesi olmayan en uzun içerik kelimesi (örn. 'inanamıyorum' videodaki şey değildir)."""
    c = [t for t in tokens(text) if len(t) >= 4 and t not in STOP and t not in GENERIC and not t.startswith(_REACT)]
    return max(c, key=len) if c else ""

def fragment(text, kw, rng):
    """Videoya özgü kelime (kw) ve 0-2 komşu kelimesi. kw yoksa ya da altyazıda geçmiyorsa boş: rastgele parça alıntısı cümleyi bozar."""
    ws = [tr_lower(w) for w in _W.findall(text)]
    if not kw or kw not in ws: return ""
    idx, n = ws.index(kw), rng.choice([1, 2, 2, 3]); bad = STOP | GENERIC
    start = rng.randint(max(0, idx - n + 1), min(idx, len(ws) - n)) if len(ws) >= n else 0
    w = ws[start:start + n]
    while len(w) > 1 and w[0] in bad and w[0] != kw: w = w[1:]
    while len(w) > 1 and w[-1] in bad and w[-1] != kw: w = w[:-1]
    return " ".join(w)

def nfill(text): return sum(w in FILLERS for w in text.split())

def dedupe_fillers(text):
    """'bence ... bence', 'ya ... ya' gibi çift dolguyu temizler (ilk geçen kalır)."""
    seen, out = set(), []
    for w in text.split():
        if w in FILLERS and w in seen: continue
        if w in FILLERS: seen.add(w)
        out.append(w)
    return " ".join(out)

LENGTHS = ("kısa", "orta", "uzun")

def _finish(text, rng):
    """Gerçek yorum gibi: küçük harf, noktasız; soru işaretini çoğu zaman bırakmaz."""
    t = re.sub(r"\s+", " ", tr_lower(text)).strip().rstrip(".!")
    if t.endswith("?") and rng.random() < 0.6: t = t[:-1]
    return t

class CommentGenerator:
    """Kural tabanlı üretim; görüntüyü anlamaz, altyazıdaki nadir kelimeye ve kategoriye bakar.
    kısa = çekirdek, orta = önek + çekirdek, uzun = önek + çekirdek + devam cümlesi (EXT) (hepsi küçük harf, noktasız)."""
    def __init__(self, db=None, seed=None, dup=None, crowd=None):
        self.db = db or CommentTemplateDatabase(); self.rng = random.Random(seed); self.dup = dup or DuplicateCommentFilter()
        self.crowd = crowd or {}; self._bags = {}

    def _bag(self, key, items):
        """Havuzu karıştırıp tüketir (aynı cümle havuz bitmeden tekrar gelmez); bitince yeniden karıştırır."""
        q = self._bags.get(key)
        if not q: q = list(items); self.rng.shuffle(q); self._bags[key] = q
        return q.pop()

    def _w(self, word):
        n = max(self.crowd.get("n", 0), 1)
        return 1 + 6 * self.crowd.get("slang", {}).get(word, 0) / n    # o videonun izleyicisi çok kullanıyorsa daha sık seçilir

    def _pick(self, lst):
        return self.rng.choices(lst, weights=[self._w(x) for x in lst])[0]

    def _tails(self, spec):
        n = max(self.crowd.get("n", 0), 1)
        extra = [w for w, k in self.crowd.get("slang", {}).items() if k / n >= 0.08 and w not in spec["tails"]]
        return spec["tails"] + extra

    def generate(self, m):
        spec, kw, rng = self.db.get(m["category"]), m.get("keyword") or "", self.rng
        plain = [(i, c) for i, c in enumerate(spec["cores"]) if "{k}" not in c]
        kcores = [(i, c) for i, c in enumerate(spec["cores"]) if "{k}" in c]
        low = tr_lower(m["subtitle"]); trig = []
        frag = fragment(m["subtitle"], kw or content_kw(m["subtitle"]), rng); frs = FR.get(m["category"]) or FR["Genel"]
        for rx, cat, cm in TRIGGERS:
            if cat == m["category"] and re.search(rx, low): trig += cm
        out = {}
        for length in LENGTHS:
            text = ""
            for attempt in range(60):
                strict = attempt < 40
                if length == "orta" and trig and rng.random() < 0.5:
                    cid, text = ("t", rng.choice(trig)), None
                    text = cid[1]
                else:
                    use_f = bool(frag) and rng.random() < 0.75       # videoda geçen ifadeye bağlı yorum, genel kalıptan daha doğal
                    pool = kcores if (kw and kcores and rng.random() < 0.65) else plain
                    if use_f:
                        i, core = self._bag((m["category"], "f"), list(enumerate(frs))); cid = (m["category"], "f", i)
                        text = core.replace("{f}", frag)
                    else:
                        i, core = (self._bag((m["category"], "c"), plain) if pool is plain else self._bag((m["category"], "k"), kcores)); cid = (m["category"], i)
                        text = core.replace("{k}", kw)
                    if length != "kısa":
                        pf = self._pick(spec["prefixes"])
                        if nfill(text) >= 1: pf = ""            # dolgu kelimeleri üst üste yığılmaz
                        text = (pf + " " + text).strip()
                    if length == "uzun":
                        ext = EXT.get(m["category"]) or EXT["Genel"]
                        def fresh():   # havuz bitene kadar tekrar etmeyen, çekirdekle kelime çakışmayan devam cümlesi
                            for _ in range(len(ext)):
                                e = self._bag((m["category"], "e"), ext)
                                if len(set(text.split()) & set(e.split())) < 2: return e
                            return e
                        if rng.random() < 0.55 or len(text.split()) < 5: text += " " + fresh()    # bazı satırlar devamsız kalır: gerçek yorumlar da eşit uzunlukta değil
                        if rng.random() < 0.2 and nfill(text) < 2: text += " " + self._pick(self._tails(spec))
                        if len(text.split()) < 5: text += " " + fresh()
                text = _finish(dedupe_fillers(text), rng)
                if length != "kısa" and self.crowd.get("emoji", 0) >= 0.25 and rng.random() < self.crowd["emoji"] * 0.5 and EMOJI.get(m["category"]):
                    text += " " + rng.choice(EMOJI[m["category"]])
                if self.dup.accept(text, cid, strict): break
            out[length] = text
        return out
