import json, urllib.parse, urllib.request
def fetch_metadata(vid, timeout=10):
    """VideoMetadataService: başlık/kanal (oEmbed) + küçük resim. Başarısızsa boş bilgi döner."""
    meta = {"title": "", "author": "", "thumb": f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"}
    try:
        q = urllib.parse.urlencode({"url": f"https://www.youtube.com/watch?v={vid}", "format": "json"})
        with urllib.request.urlopen("https://www.youtube.com/oembed?" + q, timeout=timeout) as r:
            d = json.loads(r.read().decode("utf-8"))
        meta["title"], meta["author"] = d.get("title", ""), d.get("author_name", "")
    except Exception:
        pass
    return meta
