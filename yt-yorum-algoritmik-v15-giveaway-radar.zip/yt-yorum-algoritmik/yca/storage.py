import json, os, re, tempfile
_VID = re.compile(r"^[A-Za-z0-9_-]{11}$")

class HistoryManager:
    """Analiz geçmişi: data/history/<video_id>.json (atomik yazım)."""
    def __init__(self, data_dir):
        self.dir = os.path.join(data_dir, "history"); os.makedirs(self.dir, exist_ok=True)
    def _path(self, vid):
        if not _VID.match(vid or ""): raise ValueError("Geçersiz video kimliği")
        return os.path.join(self.dir, vid + ".json")
    def save(self, result):
        fd, tmp = tempfile.mkstemp(dir=self.dir, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f: json.dump(result, f, ensure_ascii=False)
        os.replace(tmp, self._path(result["vid"]))
    def load(self, vid):
        try:
            with open(self._path(vid), encoding="utf-8") as f: return json.load(f)
        except FileNotFoundError: return None
    def list(self):
        rows = []
        for fn in os.listdir(self.dir):
            if fn.endswith(".json"):
                try:
                    with open(os.path.join(self.dir, fn), encoding="utf-8") as f: d = json.load(f)
                    rows.append({"vid": d["vid"], "title": d["meta"].get("title") or d["vid"], "created": d["created"], "count": len(d["moments"])})
                except Exception: continue
        return sorted(rows, key=lambda r: r["created"], reverse=True)
