import re
_ID = r"([A-Za-z0-9_-]{11})(?![A-Za-z0-9_-])"
_PATTERNS = [
    r"(?:www\.|m\.|music\.)?youtube\.com/watch\?(?:[^#\s]*&)?v=" + _ID,
    r"youtu\.be/" + _ID,
    r"(?:www\.|m\.)?youtube\.com/(?:shorts|live|embed)/" + _ID,
]
def parse_video_id(url):
    """YouTubeUrlParser: desteklenen bağlantılardan 11 karakterlik video kimliğini çıkarır."""
    url = (url or "").strip()
    for p in _PATTERNS:
        m = re.search(p, url)
        if m: return m.group(1)
    return None
