"""YouTube yardımcısı: video bilgisi + doğal, birbirinden farklı yorum taslakları. Hiçbir şey otomatik paylaşılmaz."""
import json, random, re
from yca.metadata import fetch_metadata
from yca.textutil import tokens, jaccard
from yca import ytapi

# Videoyu izlemeden iddia içermeyen, kısa, gündelik taslaklar. Kullanıcı izleyip düzenlemeli.
POOL = ["{k} kanalının videoları hep kaliteli, devamını bekliyorum", "Bu videoyu şimdi buldum, güzel olmuş", "Eline sağlık {k}, izlemesi keyifliydi",
        "Güzel iş çıkarmışsın, bir sonraki videoyu merakla bekliyorum", "Tam zamanında gelen bir video oldu, teşekkürler", "Yeni videoyu görünce hemen izlemek istedim, beğendim",
        "Kanalı takipteyim, bu video da çıtayı yükseltmiş", "Anlatımı ve montajı güzel olmuş, emeğine sağlık", "Bunun gibi içerikler çoğalsın, çok iyi olmuş",
        "Videoyu sonuna kadar izledim, gerçekten güzeldi", "Sürekli takip ediyorum, bu video da çok iyiydi", "Videolar her geçen gün daha da iyi oluyor {k}"]

def video_info(yt, vid):
    """Önce Data API (anahtar/hesap varsa; başlık + açıklama), yoksa oEmbed (yalnızca başlık/kanal)."""
    if yt.connected() or yt.has_key():
        try:
            i = yt.video_info(vid); return {"title": i["title"], "channel": i["channel_title"], "description": i["description"][:1500], "source": "api"}
        except ytapi.YtError: pass
    m = fetch_metadata(vid)
    return {"title": m["title"], "channel": m["author"], "description": "", "source": "oembed"}

def _dedupe(items, n):
    out = []
    for t in items:
        t = re.sub(r"\s+", " ", t).strip()
        if 8 <= len(t) <= 220 and all(jaccard(tokens(t), tokens(o)) < 0.6 for o in out): out.append(t)
        if len(out) >= n: break
    return out

def make_drafts(info, writer=None, n=5, seed=None):
    """-> (taslaklar, kaynak). Ollama açıksa onunla (video başlığı/açıklamasına göre), değilse şablonla."""
    if writer is not None:
        try:
            ok, model, _ = writer.status()
            if ok:
                msg = (f"Video başlığı: {info['title']}\nKanal: {info['channel']}\nAçıklama: {info['description'][:600]}\n\n"
                       f"Bu videoya, izleyici gibi yazılmış {n} KISA (en fazla 15 kelime) ve birbirinden FARKLI Türkçe yorum yaz. Videoda ne olduğunu uydurma; "
                       "sadece başlık ve açıklamada geçen şeylere atıf yap. Kalıp 'emeğinize sağlık' ve yapay zekâ gibi yazma. JSON: {\"yorumlar\":[...]}")
                body = {"model": model, "stream": False, "format": {"type": "object", "properties": {"yorumlar": {"type": "array", "items": {"type": "string"}}}, "required": ["yorumlar"]},
                        "messages": [{"role": "user", "content": msg}], "options": {"temperature": 0.9, "num_predict": 400}}
                out = _dedupe(json.loads(writer._http("/api/chat", body)["message"]["content"]).get("yorumlar", []), n)
                if len(out) >= 3: return out, "yerel model (Ollama)"
        except Exception: pass
    r = random.Random(seed); pool = POOL[:]; r.shuffle(pool)
    k = (info.get("channel") or "").strip() or "hocam"
    return _dedupe([p.format(k=k) for p in pool], n), "şablon (videoyu bilmez, izleyip düzenle)"
