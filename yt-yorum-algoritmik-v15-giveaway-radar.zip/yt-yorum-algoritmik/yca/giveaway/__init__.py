"""Giveaway Assistant: Discord çekiliş takibi (bağımsız modül). Resmî bot token'ı + Discord REST API; self-bot yok."""
