"""Çekiliş mesajı tespiti ve şart analizi (kural tabanlı, TR + EN). Anlaşılmayan şartlar 'unclear' olarak ayrıca döner."""
import re, time, datetime
from yca.urlparser import parse_video_id

URL = re.compile(r"https?://[^\s<>()\[\]\"']+", re.I)
INVITE = re.compile(r"(?:discord\.gg|discord(?:app)?\.com/invite)/([A-Za-z0-9-]{2,32})", re.I)
YT_CHANNEL = re.compile(r"youtube\.com/((?:@|channel/|c/|user/)[\w.\-%]+)", re.I)
TS = re.compile(r"<t:(\d{9,11})(?::[tTdDfFR])?>")
MENTION = re.compile(r"<@!?(\d{15,25})>")

GW_WORDS = re.compile(r"giveaway|çekiliş|cekilis|hosted by|winners?\b|kazanan|ödül|odul|prize|🎉|🎁", re.I)
END_WORDS = re.compile(r"giveaway ended|ended|sona erdi|bitti|çekiliş bitti|cekilis bitti|winners?:|kazanan(?:lar)?\s*:", re.I)
GENERIC_TITLES = {"giveaway", "giveaways", "çekiliş", "cekilis", "new giveaway", "yeni çekiliş", "🎉 giveaway 🎉", "🎉 giveaway", "giveaway 🎉"}

# anahtar -> (etiket, regex)
REQS = [
    ("yt_subscribe", "YouTube kanalına abone ol", re.compile(r"(subscribe|abone)", re.I)),
    ("yt_like", "Videoyu beğen", re.compile(r"(\blike\b|\bliked\b|beğen|begen|👍)", re.I)),
    ("yt_comment", "Videoya yorum yaz", re.compile(r"(comment|yorum)", re.I)),
    ("discord_join", "Discord sunucusuna katıl", re.compile(r"(join (?:the |our |this )?(?:discord|server)|sunucuya katıl|sunucuya gir|discord\.gg|discord(?:app)?\.com/invite)", re.I)),
    ("button", "Çekiliş botunun katılım butonuna / tepkisine bas", re.compile(r"(click|press|tap|react|butona|butonuna|tıkla|tikla|basarak|tepki)", re.I)),
]
EXTRA = [
    ("Sunucuya boost bas", r"\bboost"), ("Davet (invite) şartı", r"\binvit(?:e|es|ed)\b.*\d|\d+\s*(?:invites?|davet)|davet et"),
    ("Seviye / rol şartı", r"\blevel\b|\bseviye\b|\brole\b|\brol\b"), ("Twitter/X takibi", r"twitter|x\.com|\bfollow\b.*\bx\b|tweet"),
    ("Instagram takibi", r"instagram"), ("Twitch takibi", r"twitch"), ("TikTok takibi", r"tiktok"), ("Steam şartı", r"steam"),
    ("Site kaydı / kod / yatırım şartı", r"promo|kupon|coupon|code\b|kod\b|deposit|yatırım|wager|register|kayıt ol|sign ?up"),
    ("Ticket / form şartı", r"ticket|form\b|dm\b"), ("Mesaj sayısı / aktiflik", r"messages?\b|mesaj|active|aktif"),
]
_LISTLINE = re.compile(r"^\s*(?:[-*•▪►➤✅☑✔️▶🔹🔸]|\d+[.)])\s*(.+)$")
_SECTION = re.compile(r"(requirements?|şartlar|sartlar|how to enter|nasıl katılırım|nasil katilirim|katılım|entry|to enter|şart)", re.I)

def _md(t): return re.sub(r"[*_`~>]+", "", t or "")

def message_text(msg):
    """Mesajın tüm metni: içerik + embed (başlık, açıklama, alanlar, alt bilgi) + buton etiketleri."""
    parts = [msg.get("content") or ""]
    for e in msg.get("embeds") or []:
        parts += [e.get("title") or "", e.get("description") or ""]
        for f in e.get("fields") or []: parts += [f.get("name") or "", f.get("value") or ""]
        parts.append((e.get("footer") or {}).get("text") or "")
    for lab, _ in _buttons(msg): parts.append(lab)
    return "\n".join(p for p in parts if p)

def _buttons(msg):
    out = []
    for row in msg.get("components") or []:
        for c in row.get("components") or []: 
            if c.get("type") == 2: out.append((c.get("label") or "", c.get("url") or ""))
    return out

def _all_urls(msg):
    urls = list(URL.findall(message_text(msg)))
    for e in msg.get("embeds") or []:
        if e.get("url"): urls.append(e["url"])
    for _, u in _buttons(msg):
        if u: urls.append(u)
    seen, res = set(), []
    for u in urls:
        u = u.rstrip(".,;:!?)")
        if u not in seen: seen.add(u); res.append(u)
    return res

def _iso(s):
    try: return int(datetime.datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp())
    except Exception: return None

_REL = re.compile(r"(?:ends?\s*in|bitiş|kalan|remaining)[^\d]{0,12}(\d+)\s*(day|gün|hour|saat|h\b|hr|min|dk|dakika|d\b)", re.I)
def find_end(msg, text):
    stamps = [int(x) for x in TS.findall(text)]
    now_msg = _iso(msg.get("timestamp") or "") or int(time.time())
    for m in re.finditer(r"(?:ends?|bitiş|bitis|sona erer|ending)[^\n<]{0,25}<t:(\d{9,11})", text, re.I): return int(m.group(1))
    if stamps: return max(stamps)
    m = _REL.search(text)
    if m:
        n, u = int(m.group(1)), m.group(2).lower()
        sec = 86400 if u.startswith(("d", "g")) and not u.startswith("dk") and not u.startswith("da") or u in ("day", "gün") else 3600 if u.startswith(("h", "s")) else 60
        return now_msg + n * sec
    for e in msg.get("embeds") or []:     # Giveaway Bot gibi botlar bitişi embed zaman damgasına yazar
        t = _iso(e.get("timestamp") or "")
        if t and re.search(r"ends?|bitiş|bitis", text, re.I) and t > now_msg - 60: return t
    return None

def find_prize(msg, text):
    for e in msg.get("embeds") or []:
        t = _md(e.get("title") or "").strip(" 🎉🎁")
        if t and t.lower() not in GENERIC_TITLES and len(t) < 200: return t
    m = re.search(r"(?:prize|ödül|odul|ödülü)\s*[:\-–]\s*(.+)", _md(text), re.I)
    if m: return m.group(1).strip()[:200]
    first = _md(msg.get("content") or "").strip().splitlines()
    for line in first:
        l = line.strip(" 🎉🎁:-")
        if l and l.lower() not in GENERIC_TITLES and not l.startswith("<"): return l[:200]
    return ""

def find_host(msg, text):
    m = re.search(r"(?:hosted by|host|düzenleyen|sahibi)\s*[:\-]?\s*(<@!?\d+>|[^\n]+)", text, re.I)
    return (m.group(1).strip()[:80] if m else "") or (msg.get("author") or {}).get("username", "")

def find_winner_count(text):
    m = re.search(r"winners?\s*[:\-]?\s*(\d+)|(\d+)\s*(?:winners?|kazanan)|kazanan(?:\s*sayısı)?\s*[:\-]?\s*(\d+)", text, re.I)
    return int(next(g for g in m.groups() if g)) if m else None

def analyze_requirements(msg, text):
    """-> (şartlar listesi, anlaşılmayan satırlar). Her şart: {key,label,detail}."""
    low = _md(text); found, covered = [], set()
    lines = [l.strip() for l in low.splitlines() if l.strip()]
    for key, label, rx in REQS:
        hits = [l for l in lines if rx.search(l)]
        if key == "yt_like" and not any(re.search(r"youtu", l, re.I) or re.search(r"video", l, re.I) for l in hits): hits = []
        if key == "yt_comment" and not any(re.search(r"youtu|video|kanal|channel", l, re.I) for l in hits): hits = []
        if key == "yt_subscribe" and not any(re.search(r"youtu|kanal|channel", l, re.I) for l in hits):
            hits = [l for l in hits if not re.search(r"discord|server|sunucu", l, re.I)]
        if key == "button" and (msg.get("components") or re.search(r"🎉", text)): hits = hits or ["🎉 / buton"]
        if key == "discord_join" and not hits and INVITE.search(text): hits = ["davet bağlantısı var"]
        if hits:
            found.append({"key": key, "label": label, "detail": hits[0][:160]}); covered.update(hits)
    if msg.get("components") and not any(r["key"] == "button" for r in found):
        found.append({"key": "button", "label": REQS[4][1], "detail": "mesajda buton var"})
    for label, rx in EXTRA:
        hits = [l for l in lines if re.search(rx, l, re.I)]
        if hits: found.append({"key": "custom", "label": label, "detail": hits[0][:160]}); covered.update(hits)
    # Şart bölümündeki, hiçbir kurala uymayan madde satırları -> anlaşılmayan
    unclear, in_sec = [], False
    for l in lines:
        if _SECTION.search(l) and len(l) < 60: in_sec = True; continue
        mm = _LISTLINE.match(l)
        if (in_sec or mm) and mm and l not in covered and not END_WORDS.search(l) and not re.search(r"hosted|ends?\b|winners?\b|bitiş|kazanan", l, re.I):
            unclear.append(mm.group(1)[:160])
    return found, unclear

def is_ended(msg, text):
    if not END_WORDS.search(text): return False
    return bool(re.search(r"giveaway ended|çekiliş (?:sona erdi|bitti)|cekilis (?:sona erdi|bitti)|\bended\b|winners?\s*:|kazanan(?:lar)?\s*:", text, re.I))

def parse_giveaway(msg, now=None):
    """Mesaj çekiliş değilse None. Aksi halde yapılandırılmış sözlük."""
    now = now or int(time.time()); text = message_text(msg)
    if not text.strip(): return None
    has_bot_ui = bool(msg.get("components")) or any(r.get("emoji", {}).get("name") == "🎉" for r in msg.get("reactions") or [])
    strong = re.search(r"giveaway|çekiliş|cekilis|hosted by|🎉", text, re.I)
    ends = find_end(msg, text)
    score = (2 if strong else 0) + (1 if has_bot_ui else 0) + (1 if ends else 0) + (1 if re.search(r"winners?|kazanan|prize|ödül|odul", text, re.I) else 0) + (1 if (msg.get("author") or {}).get("bot") else 0)
    if not strong or score < 3: return None
    reqs, unclear = analyze_requirements(msg, text)
    urls = _all_urls(msg)
    vids, seenv = [], set()
    for u in urls:
        v = parse_video_id(u)
        if v and v not in seenv: seenv.add(v); vids.append(v)
    ytch = sorted({m.group(1) for u in urls for m in [YT_CHANNEL.search(u)] if m})
    invites = sorted({m.group(1) for m in INVITE.finditer(text)})
    ended = is_ended(msg, text) or bool(ends and ends < now - 60)
    winners = [] if not ended else list(dict.fromkeys(MENTION.findall(text) + [m["id"] for m in msg.get("mentions") or [] if m.get("id")]))
    return {"prize": find_prize(msg, text), "host": find_host(msg, text), "ends_at": ends, "winners_count": find_winner_count(text),
            "requirements": reqs, "unclear": unclear, "videos": vids, "yt_channels": ytch, "invites": invites,
            "ended": ended, "winner_ids": winners, "text": text[:3000]}
