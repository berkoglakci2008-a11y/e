"""Arka plan izleyici: kanalları yoklar, çekilişleri kaydeder, süre/sonuç takibi yapar. Durum SQLite'ta kalıcıdır;
sunucu yeniden başlayınca last_message_id'den devam eder (aynı mesaj message_id UNIQUE ile iki kez kaydedilmez)."""
import json, logging, threading, time
from .discord_api import DiscordClient, DiscordError
from .parser import parse_giveaway, MENTION

log = logging.getLogger("yca.giveaway")
SOON = 2 * 3600   # "bitiş yaklaşıyor" eşiği

class Monitor:
    def __init__(self, db, dc, interval=60):
        self.db, self.dc, self.interval = db, dc, max(30, int(interval))
        self.stop_ev, self.thread = threading.Event(), None
        self.status = {"running": False, "last_cycle": 0, "last_error": "", "cycles": 0}

    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.stop_ev.clear(); self.thread = threading.Thread(target=self._loop, daemon=True, name="giveaway-monitor"); self.thread.start()
    def stop(self): self.stop_ev.set()

    def _loop(self):
        self.status["running"] = True; self.db.event("info", "İzleyici başladı.")
        backoff = 0
        while not self.stop_ev.is_set():
            wait = self.interval
            if not self.dc.has_token(): self.status["last_error"] = "Discord bot token'ı girilmemiş."
            else:
                try: self.cycle(); backoff = 0; self.status["last_error"] = ""
                except DiscordError as e:
                    self.status["last_error"] = str(e); self.db.event("error", str(e))
                    if e.fatal: wait = 600
                    else: backoff = min(backoff + 1, 5); wait = self.interval * (2 ** backoff)
                except Exception as e:
                    log.exception("izleyici hatası"); self.status["last_error"] = "Beklenmeyen hata: " + str(e)[:150]; self.db.event("error", self.status["last_error"])
                    wait = self.interval * 2
            self.status["last_cycle"] = int(time.time()); self.status["cycles"] += 1
            self.stop_ev.wait(wait)
        self.status["running"] = False

    # ------------------------------------------------------------------ tek tur
    def cycle(self):
        for ch in self.db.q("SELECT * FROM channels WHERE enabled=1"):
            try: self.poll_channel(ch)
            except DiscordError as e:
                if e.fatal: raise
                self.db.x("UPDATE channels SET last_error=? WHERE id=?", (str(e), ch["id"])); self.db.event("warn", f"#{ch['name']}: {e}")
        self.refresh_active(); self.deadlines()

    def poll_channel(self, ch):
        first = not ch["last_message_id"]
        msgs = self.dc.messages(ch["id"], after=ch["last_message_id"], limit=50 if not first else 50)
        msgs.sort(key=lambda m: int(m["id"]))
        if first and not msgs: msgs = []
        new = 0
        for m in msgs:
            if self.ingest(ch, m): new += 1
        if msgs: self.db.x("UPDATE channels SET last_message_id=? WHERE id=?", (msgs[-1]["id"], ch["id"]))
        self.db.x("UPDATE channels SET last_error=NULL, last_ok=? WHERE id=?", (int(time.time()), ch["id"]))
        if first:  # ilk tarama: son 50 mesaj; daha eskiye gidilmez
            self.db.event("info", f"#{ch['name']}: ilk tarama, {len(msgs)} mesaj, {new} çekiliş.")
        return new

    def ingest(self, ch, m):
        # çekiliş mesajına cevap olarak gelen "tebrikler" -> kazananlar
        ref = (m.get("message_reference") or {}).get("message_id")
        if ref:
            g = self.db.one("SELECT * FROM giveaways WHERE message_id=?", (ref,))
            if g and g["status"] != "ended" or g and not g["winner_ids"]:
                ids = list(dict.fromkeys(MENTION.findall(m.get("content") or "") + [u["id"] for u in m.get("mentions") or []]))
                if ids and g: self._finish(g, ids)
        p = parse_giveaway(m)
        if not p or self.db.one("SELECT 1 AS x FROM giveaways WHERE message_id=?", (m["id"],)): return False
        gid = ch.get("guild_id") or "@me"
        cur = self.db.x("""INSERT OR IGNORE INTO giveaways(channel_id,message_id,guild_id,url,prize,host,ends_at,status,winners_count,requirements,videos,yt_channels,invites,raw_text,found_at,winner_ids)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (ch["id"], m["id"], gid, f"https://discord.com/channels/{gid}/{ch['id']}/{m['id']}", p["prize"], p["host"], p["ends_at"], "ended" if p["ended"] else "active",
             p["winners_count"], json.dumps(p["requirements"], ensure_ascii=False), json.dumps(p["videos"]), json.dumps(p["yt_channels"]), json.dumps(p["invites"]),
             json.dumps({"text": p["text"], "unclear": p["unclear"]}, ensure_ascii=False), int(time.time()), json.dumps(p["winner_ids"])))
        if not cur.rowcount: return False
        if not p["ended"]:
            self.db.notify("new", f"Yeni çekiliş: {p['prize'] or '(ödül okunamadı)'} — #{ch['name']}", cur.lastrowid)
        self.db.event("info", f"Yeni çekiliş kaydedildi: {p['prize'] or m['id']} (#{ch['name']})")
        return True

    # ------------------------------------------------------------------ takip
    def refresh_active(self):
        now = int(time.time())
        for g in self.db.q("SELECT * FROM giveaways WHERE status='active' AND last_checked<? LIMIT 25", (now - self.interval * 2,)):
            if g["ends_at"] and g["ends_at"] > now + 300 and now - g["last_checked"] < 900: continue
            try: m = self.dc.message(g["channel_id"], g["message_id"])
            except DiscordError as e:
                if e.status == 404: self.db.x("UPDATE giveaways SET status='deleted', last_checked=? WHERE id=?", (now, g["id"])); continue
                if e.fatal: raise
                continue
            self.db.x("UPDATE giveaways SET last_checked=? WHERE id=?", (now, g["id"]))
            p = parse_giveaway(m)
            if p and p["ended"]: self._finish(g, p["winner_ids"])
            elif p and p["ends_at"] and p["ends_at"] != g["ends_at"]: self.db.x("UPDATE giveaways SET ends_at=? WHERE id=?", (p["ends_at"], g["id"]))

    def _finish(self, g, winners):
        """Çekilişi bitmiş say, kazananları yaz, kullanıcı katıldıysa sonucu belirle."""
        old = g["winner_ids"] if isinstance(g["winner_ids"], list) else []
        winners = list(dict.fromkeys(list(old) + list(winners)))
        result = g["result"]; me = self.db.get("discord_user_id").strip()
        if g["state"] == "joined" and result in ("pending", "unknown"):
            if winners and me: result = "won" if me in winners else "lost"
            else: result = "unknown"
        self.db.x("UPDATE giveaways SET status='ended', winner_ids=?, result=? WHERE id=?", (json.dumps(winners), result, g["id"]))
        if g["status"] != "ended" and g["state"] == "joined":
            txt = {"won": "🏆 KAZANDIN", "lost": "Kaybettin", "unknown": "Sonuç belirsiz (kazananlar okunamadı, elle işaretle)"}.get(result, "Bitti")
            self.db.notify("result", f"{txt}: {g['prize']}", g["id"])
        elif g["status"] != "ended": self.db.event("info", f"Çekiliş bitti: {g['prize']}")
        elif result != g["result"] and result in ("won", "lost"): self.db.notify("result", f"{'🏆 KAZANDIN' if result == 'won' else 'Kaybettin'}: {g['prize']}", g["id"])

    def deadlines(self):
        now = int(time.time())
        for g in self.db.q("SELECT * FROM giveaways WHERE status='active' AND ends_at IS NOT NULL"):
            if g["ends_at"] < now - 60:
                try: self.refresh_one(g)
                except DiscordError: pass
            elif g["ends_at"] - now < SOON and not g["warned"] and g["state"] not in ("joined", "skipped"):
                self.db.x("UPDATE giveaways SET warned=1 WHERE id=?", (g["id"],))
                self.db.notify("soon", f"Bitmek üzere ({(g['ends_at'] - now) // 60} dk): {g['prize']} — henüz katılmadın", g["id"])

    def refresh_one(self, g):
        m = self.dc.message(g["channel_id"], g["message_id"]); p = parse_giveaway(m)
        self._finish(g, (p or {}).get("winner_ids", []))
