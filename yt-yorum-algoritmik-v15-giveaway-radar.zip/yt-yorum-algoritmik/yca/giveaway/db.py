"""SQLite veritabanı (data/giveaway.db): kanallar, çekilişler, adımlar, taslaklar, bildirimler, işlem geçmişi."""
import json, os, sqlite3, threading, time

SCHEMA = """
CREATE TABLE IF NOT EXISTS channels(id TEXT PRIMARY KEY, guild_id TEXT, guild_name TEXT, name TEXT, last_message_id TEXT, enabled INTEGER DEFAULT 1, added INTEGER, last_error TEXT, last_ok INTEGER);
CREATE TABLE IF NOT EXISTS giveaways(id INTEGER PRIMARY KEY AUTOINCREMENT, channel_id TEXT, message_id TEXT UNIQUE, guild_id TEXT, url TEXT, prize TEXT, host TEXT,
  ends_at INTEGER, status TEXT DEFAULT 'active', winners_count INTEGER, requirements TEXT, videos TEXT, yt_channels TEXT, invites TEXT, raw_text TEXT,
  found_at INTEGER, state TEXT DEFAULT 'new', joined_at INTEGER, result TEXT DEFAULT 'pending', winner_ids TEXT DEFAULT '[]', warned INTEGER DEFAULT 0, last_checked INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS steps(giveaway_id INTEGER, key TEXT, done INTEGER DEFAULT 0, done_at INTEGER, PRIMARY KEY(giveaway_id, key));
CREATE TABLE IF NOT EXISTS drafts(giveaway_id INTEGER, video_id TEXT, title TEXT, channel TEXT, description TEXT, drafts TEXT, source TEXT, posted_text TEXT, posted_at INTEGER, PRIMARY KEY(giveaway_id, video_id));
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, kind TEXT, text TEXT, giveaway_id INTEGER, is_read INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, level TEXT, text TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE INDEX IF NOT EXISTS ix_g_state ON giveaways(status, state);
"""
JSON_COLS = ("requirements", "videos", "yt_channels", "invites", "winner_ids", "drafts")

class DB:
    def __init__(self, data_dir):
        self.path = os.path.join(data_dir, "giveaway.db")
        self.lock = threading.RLock()
        self.c = sqlite3.connect(self.path, check_same_thread=False)
        self.c.row_factory = sqlite3.Row
        with self.lock:
            self.c.execute("PRAGMA journal_mode=WAL"); self.c.executescript(SCHEMA); self.c.commit()

    def q(self, sql, args=()):
        with self.lock: return [self._row(r) for r in self.c.execute(sql, args).fetchall()]
    def one(self, sql, args=()):
        r = self.q(sql, args); return r[0] if r else None
    def x(self, sql, args=()):
        with self.lock:
            cur = self.c.execute(sql, args); self.c.commit(); return cur

    @staticmethod
    def _row(r):
        d = dict(r)
        for k in JSON_COLS:
            if k in d and isinstance(d[k], str):
                try: d[k] = json.loads(d[k])
                except ValueError: pass
        return d

    # ---- ayarlar / olaylar / bildirimler
    def get(self, k, default=""):
        r = self.one("SELECT value FROM settings WHERE key=?", (k,)); return r["value"] if r else default
    def set(self, k, v): self.x("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, v))
    def event(self, level, text): self.x("INSERT INTO events(ts,level,text) VALUES(?,?,?)", (int(time.time()), level, text[:500]))
    def notify(self, kind, text, gid=None): self.x("INSERT INTO notifications(ts,kind,text,giveaway_id) VALUES(?,?,?,?)", (int(time.time()), kind, text[:300], gid))
