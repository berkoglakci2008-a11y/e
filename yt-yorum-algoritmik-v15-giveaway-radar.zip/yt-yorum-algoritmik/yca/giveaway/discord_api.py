"""Discord REST istemcisi (yalnızca resmî Bot token'ı; self-bot/kullanıcı token'ı YOK). Sadece okuma yapar.
Rate limit (429 / Retry-After) ve hata durumları yönetilir."""
import json, os, re, time, urllib.error, urllib.request

API = "https://discord.com/api/v10"

class DiscordError(Exception):
    def __init__(self, msg, status=0, fatal=False): super().__init__(msg); self.status, self.fatal = status, fatal

class DiscordClient:
    def __init__(self, data_dir):
        self.path = os.path.join(data_dir, "discord_token.txt")
        self.blocked_until = 0.0     # global rate limit

    def token(self):
        t = os.environ.get("DISCORD_BOT_TOKEN", "").strip()
        if t: return t
        try:
            with open(self.path, encoding="utf-8") as f: return f.read().strip()
        except OSError: return ""
    def has_token(self): return bool(self.token())
    def save_token(self, t):
        t = (t or "").strip()
        if t.lower().startswith("bot "): t = t[4:].strip()
        if not re.match(r"^[\w.\-]{50,120}$", t): raise DiscordError("Bu bir Discord bot token'ına benzemiyor.")
        with open(self.path, "w", encoding="utf-8") as f: f.write(t)
        try: os.chmod(self.path, 0o600)
        except OSError: pass
    def clear_token(self):
        try: os.remove(self.path)
        except OSError: pass

    def _get(self, path, retries=3):
        tok = self.token()
        if not tok: raise DiscordError("Discord bot token'ı girilmemiş.", 401, fatal=True)
        for attempt in range(retries):
            wait = self.blocked_until - time.time()
            if wait > 0: time.sleep(min(wait, 30))
            req = urllib.request.Request(API + path, headers={"Authorization": "Bot " + tok, "User-Agent": "GiveawayAssistant (local, 1.0)"})
            try:
                with urllib.request.urlopen(req, timeout=20) as r:
                    left, reset = r.headers.get("X-RateLimit-Remaining"), r.headers.get("X-RateLimit-Reset-After")
                    if left == "0" and reset:
                        try: self.blocked_until = time.time() + float(reset)
                        except ValueError: pass
                    return json.loads(r.read().decode("utf-8") or "null")
            except urllib.error.HTTPError as e:
                try: body = json.loads(e.read().decode("utf-8"))
                except Exception: body = {}
                if e.code == 429:
                    ra = float(body.get("retry_after", e.headers.get("Retry-After", 2)) or 2)
                    self.blocked_until = time.time() + ra
                    if attempt == retries - 1: raise DiscordError("Discord istek sınırı (429). Bir süre sonra tekrar denenecek.", 429)
                    continue
                if e.code == 401: raise DiscordError("Bot token'ı geçersiz (401).", 401, fatal=True)
                if e.code == 403: raise DiscordError("Botun bu kanalı görme/mesaj geçmişini okuma izni yok (403).", 403)
                if e.code == 404: raise DiscordError("Kanal/mesaj bulunamadı ya da bot erişemiyor (404).", 404)
                if e.code >= 500:
                    if attempt == retries - 1: raise DiscordError(f"Discord sunucu hatası ({e.code}).", e.code)
                    time.sleep(2 ** attempt); continue
                raise DiscordError(body.get("message") or f"Discord hatası ({e.code}).", e.code)
            except (urllib.error.URLError, TimeoutError, OSError) as e:
                if attempt == retries - 1: raise DiscordError("Discord'a ulaşılamadı (ağ hatası).") from e
                time.sleep(2 ** attempt)

    def me(self): return self._get("/users/@me")
    def guilds(self): return self._get("/users/@me/guilds")
    def guild_channels(self, gid): return self._get(f"/guilds/{gid}/channels")
    def channel(self, cid): return self._get(f"/channels/{cid}")
    def message(self, cid, mid): return self._get(f"/channels/{cid}/messages/{mid}")
    def messages(self, cid, after=None, limit=50):
        q = f"?limit={limit}" + (f"&after={after}" if after else "")
        return self._get(f"/channels/{cid}/messages{q}") or []
