"""Giveaway Assistant HTTP uçları (/giveaway ve /api/giveaway/*). Mevcut uygulamaya tek satırla bağlanır."""
import json, os, re, time
from flask import Blueprint, jsonify, request, send_from_directory
from yca import ytapi
from .db import DB
from .discord_api import DiscordClient, DiscordError
from .service import Monitor
from . import drafts as dr

bp = Blueprint("giveaway", __name__)
_S = {}
MIN_GAP = 30

def init(app, root, data_dir, yt, writer, interval=60, autostart=True):
    db = DB(data_dir); dc = DiscordClient(data_dir); mon = Monitor(db, dc, interval)
    _S.update(db=db, dc=dc, mon=mon, yt=yt, writer=writer, root=root, last_post=0.0)
    app.register_blueprint(bp)
    if autostart: mon.start()
    return mon

def _err(msg, code=400): return jsonify(error=msg), code
def _g(gid):
    g = _S["db"].one("SELECT * FROM giveaways WHERE id=?", (gid,))
    if not g: return None
    raw = g.get("raw_text") or "{}"
    try: raw = json.loads(raw) if isinstance(raw, str) else raw
    except ValueError: raw = {}
    g["unclear"] = raw.get("unclear", []); g["text"] = raw.get("text", ""); g.pop("raw_text", None)
    g["steps"] = {s["key"]: bool(s["done"]) for s in _S["db"].q("SELECT * FROM steps WHERE giveaway_id=?", (gid,))}
    g["drafts"] = _S["db"].q("SELECT * FROM drafts WHERE giveaway_id=?", (gid,))
    for k in ("requirements", "videos", "yt_channels", "invites", "winner_ids"):
        if not isinstance(g.get(k), list): g[k] = []
    return g

def _plan(g):
    """Adım adım rehber: her şart için bir adım + son adım (katıl). Tamamlandı durumu kullanıcının işaretlediği."""
    steps = []
    for v in g["videos"]:
        base = f"https://www.youtube.com/watch?v={v}"
        for r in g["requirements"]:
            if r["key"] == "yt_like": steps.append({"key": f"like:{v}", "label": f"Videoyu beğen ({v})", "link": base, "kind": "yt_like"})
            if r["key"] == "yt_comment": steps.append({"key": f"comment:{v}", "label": f"Videoya yorum yaz ({v})", "link": base, "kind": "yt_comment", "video": v})
    for c in g["yt_channels"]:
        steps.append({"key": f"sub:{c}", "label": f"YouTube kanalına abone ol ({c})", "link": "https://www.youtube.com/" + c, "kind": "yt_subscribe"})
    if any(r["key"] == "yt_subscribe" for r in g["requirements"]) and not g["yt_channels"]:
        steps.append({"key": "sub:?", "label": "YouTube kanalına abone ol (kanal bağlantısı mesajda bulunamadı, mesajı kontrol et)", "link": g["url"], "kind": "yt_subscribe"})
    for i in g["invites"]: steps.append({"key": f"join:{i}", "label": f"Discord sunucusuna katıl (discord.gg/{i})", "link": "https://discord.gg/" + i, "kind": "discord_join"})
    for n, r in enumerate(x for x in g["requirements"] if x["key"] == "custom"): steps.append({"key": f"custom:{n}", "label": f"{r['label']}: {r['detail']}", "link": g["url"], "kind": "custom"})
    for n, u in enumerate(g["unclear"]): steps.append({"key": f"unclear:{n}", "label": f"Anlaşılamadı, kendin kontrol et: {u}", "link": g["url"], "kind": "unclear"})
    steps.append({"key": "button", "label": "Çekiliş mesajındaki katılım butonuna/tepkisine bas (Discord'da sen basmalısın)", "link": g["url"], "kind": "button"})
    for s in steps: s["done"] = g["steps"].get(s["key"], False)
    return steps

@bp.get("/giveaway")
def page(): return send_from_directory(os.path.join(_S["root"], "static"), "giveaway.html")

@bp.get("/api/giveaway/overview")
def overview():
    db, now = _S["db"], int(time.time())
    n = lambda sql, a=(): db.one(sql, a)["c"]
    return jsonify(
        active=n("SELECT COUNT(*) c FROM giveaways WHERE status='active'"), new=n("SELECT COUNT(*) c FROM giveaways WHERE state='new' AND status='active'"),
        soon=n("SELECT COUNT(*) c FROM giveaways WHERE status='active' AND ends_at BETWEEN ? AND ?", (now, now + 6 * 3600)),
        joined=n("SELECT COUNT(*) c FROM giveaways WHERE state='joined'"), pending=n("SELECT COUNT(*) c FROM giveaways WHERE status='active' AND state='in_progress'"),
        won=n("SELECT COUNT(*) c FROM giveaways WHERE result='won'"), lost=n("SELECT COUNT(*) c FROM giveaways WHERE result='lost'"),
        unread=n("SELECT COUNT(*) c FROM notifications WHERE is_read=0"), now=now,
        monitor=_S["mon"].status, has_token=_S["dc"].has_token(), channels=n("SELECT COUNT(*) c FROM channels WHERE enabled=1"),
        user_id=db.get("discord_user_id"), yt_connected=_S["yt"].connected())

@bp.get("/api/giveaway/list")
def lst():
    f, now = request.args.get("f", "active"), int(time.time())
    where = {"active": "status='active'", "new": "state='new' AND status='active'", "soon": f"status='active' AND ends_at BETWEEN {now} AND {now + 6 * 3600}",
             "joined": "state='joined'", "pending": "status='active' AND state='in_progress'", "won": "result='won'", "lost": "result='lost'",
             "ended": "status IN ('ended','deleted')", "all": "1=1"}.get(f, "1=1")
    rows = _S["db"].q(f"SELECT id,prize,host,ends_at,status,state,result,found_at,url,requirements,videos,channel_id FROM giveaways WHERE {where} ORDER BY CASE WHEN ends_at IS NULL THEN 1 ELSE 0 END, ends_at ASC, found_at DESC LIMIT 300")
    names = {c["id"]: c["name"] for c in _S["db"].q("SELECT id,name FROM channels")}
    for r in rows: r["channel"] = names.get(r["channel_id"], "")
    return jsonify(rows)

@bp.get("/api/giveaway/<int:gid>")
def detail(gid):
    g = _g(gid)
    if not g: return _err("Çekiliş bulunamadı.", 404)
    g["plan"] = _plan(g); return jsonify(g)

@bp.post("/api/giveaway/<int:gid>/step")
def step(gid):
    d = request.get_json(silent=True) or {}; g = _g(gid)
    if not g: return _err("Çekiliş bulunamadı.", 404)
    key = str(d.get("key", ""))[:80]
    if key not in {s["key"] for s in _plan(g)}: return _err("Geçersiz adım.")
    _S["db"].x("INSERT INTO steps(giveaway_id,key,done,done_at) VALUES(?,?,?,?) ON CONFLICT(giveaway_id,key) DO UPDATE SET done=excluded.done, done_at=excluded.done_at", (gid, key, 1 if d.get("done") else 0, int(time.time())))
    if g["state"] == "new": _S["db"].x("UPDATE giveaways SET state='in_progress' WHERE id=? AND state='new'", (gid,))
    return jsonify(ok=True)

@bp.post("/api/giveaway/<int:gid>/state")
def set_state(gid):
    """Kullanıcının onayladığı durum: joined (katıldım) / skipped / in_progress; sonuç: won/lost (elle)."""
    d = request.get_json(silent=True) or {}; g = _g(gid)
    if not g: return _err("Çekiliş bulunamadı.", 404)
    st, res, db = d.get("state"), d.get("result"), _S["db"]
    if st:
        if st not in ("new", "in_progress", "joined", "skipped"): return _err("Geçersiz durum.")
        if st == "joined":
            if not d.get("confirm"): return _err("Katılımı onaylaman gerekir.")
            pend = [s["label"] for s in _plan(g) if not s["done"] and s["kind"] != "button"]
            if pend and not d.get("force"): return jsonify(error="Tamamlanmamış adımlar var.", pending=pend), 409
        db.x("UPDATE giveaways SET state=?, joined_at=? WHERE id=?", (st, int(time.time()) if st == "joined" else None, gid))
        db.event("info", f"Durum: {g['prize']} → {st}")
        if st == "joined" and g["status"] == "ended": db.x("UPDATE giveaways SET result='unknown' WHERE id=?", (gid,))
    if res in ("won", "lost", "unknown", "pending"):
        db.x("UPDATE giveaways SET result=? WHERE id=?", (res, gid)); db.event("info", f"Sonuç elle işaretlendi: {g['prize']} → {res}")
    return jsonify(ok=True)

@bp.post("/api/giveaway/<int:gid>/drafts")
def make(gid):
    d = request.get_json(silent=True) or {}; g = _g(gid)
    if not g: return _err("Çekiliş bulunamadı.", 404)
    vid = d.get("video")
    if vid not in g["videos"]: return _err("Bu video çekilişte geçmiyor.")
    info = dr.video_info(_S["yt"], vid)
    if not info["title"]: return _err("Video bilgisi alınamadı (video gizli/silinmiş olabilir ya da internet yok).", 502)
    texts, src = dr.make_drafts(info, _S["writer"], seed=int(time.time() * 1000) & 0xFFFFFFF)
    _S["db"].x("INSERT INTO drafts(giveaway_id,video_id,title,channel,description,drafts,source) VALUES(?,?,?,?,?,?,?) ON CONFLICT(giveaway_id,video_id) DO UPDATE SET title=excluded.title,channel=excluded.channel,description=excluded.description,drafts=excluded.drafts,source=excluded.source",
               (gid, vid, info["title"], info["channel"], info["description"], json.dumps(texts, ensure_ascii=False), src))
    return jsonify(ok=True)

@bp.post("/api/giveaway/<int:gid>/comment")
def comment(gid):
    """Yalnızca kullanıcının seçip onayladığı metni, kendi YouTube hesabından, resmî API ile gönderir."""
    d = request.get_json(silent=True) or {}; g = _g(gid); yt = _S["yt"]
    if not g: return _err("Çekiliş bulunamadı.", 404)
    vid, text = d.get("video"), (d.get("text") or "").strip()
    if vid not in g["videos"]: return _err("Bu video çekilişte geçmiyor.")
    if not d.get("confirm"): return _err("Göndermeden önce onay gerekir.")
    if not text: return _err("Yorum boş.")
    if not yt.connected(): return _err("Önce ana sayfadan YouTube hesabına bağlan.", 401)
    row = _S["db"].one("SELECT posted_at FROM drafts WHERE giveaway_id=? AND video_id=?", (gid, vid))
    if row and row["posted_at"] and not d.get("force"): return jsonify(error="Bu videoya bu çekiliş için zaten yorum attın.", duplicate=True), 409
    wait = MIN_GAP - (time.time() - _S["last_post"])
    if wait > 0: return _err(f"Çok hızlısın, {int(wait) + 1} sn sonra tekrar dene.", 429)
    try: cid = yt.post_comment(vid, text)
    except ytapi.YtError as e:
        _S["db"].event("error", f"Yorum atılamadı {vid}: {e}"); return _err(str(e), 502)
    _S["last_post"] = time.time()
    _S["db"].x("INSERT INTO drafts(giveaway_id,video_id,posted_text,posted_at) VALUES(?,?,?,?) ON CONFLICT(giveaway_id,video_id) DO UPDATE SET posted_text=excluded.posted_text, posted_at=excluded.posted_at", (gid, vid, text, int(time.time())))
    key = f"comment:{vid}"
    _S["db"].x("INSERT INTO steps(giveaway_id,key,done,done_at) VALUES(?,?,1,?) ON CONFLICT(giveaway_id,key) DO UPDATE SET done=1", (gid, key, int(time.time())))
    _S["db"].event("info", f"Yorum atıldı (onaylı): {vid}")
    return jsonify(ok=True, url=f"https://www.youtube.com/watch?v={vid}&lc={cid}")

# ------------------------------------------------------------------ Discord kurulum
@bp.post("/api/giveaway/token")
def token():
    dc = _S["dc"]; d = request.get_json(silent=True) or {}
    if d.get("clear"): dc.clear_token(); return jsonify(ok=True)
    try: dc.save_token(d.get("token")); me = dc.me()
    except DiscordError as e:
        if e.status == 401: dc.clear_token()
        return _err(str(e), 400)
    _S["db"].event("info", f"Bot bağlandı: {me.get('username')}"); _S["mon"].start()
    return jsonify(ok=True, bot=me.get("username"))

@bp.get("/api/giveaway/discord/guilds")
def guilds():
    try: return jsonify(_S["dc"].guilds())
    except DiscordError as e: return _err(str(e), 502)

@bp.get("/api/giveaway/discord/channels")
def gchannels():
    gid = request.args.get("guild", "")
    if not re.fullmatch(r"\d{15,25}", gid): return _err("Geçersiz sunucu.")
    try: ch = _S["dc"].guild_channels(gid)
    except DiscordError as e: return _err(str(e), 502)
    return jsonify([{"id": c["id"], "name": c["name"]} for c in ch if c.get("type") in (0, 5)])

@bp.get("/api/giveaway/channels")
def channels(): return jsonify(_S["db"].q("SELECT * FROM channels ORDER BY guild_name, name"))

@bp.post("/api/giveaway/channels")
def add_channel():
    d = request.get_json(silent=True) or {}; raw = str(d.get("channel", "")).strip()
    m = re.search(r"channels/(?:\d+|@me)/(\d{15,25})", raw) or re.fullmatch(r"(\d{15,25})", raw)
    if not m: return _err("Kanal kimliği ya da kanal bağlantısı gir (discord.com/channels/…/…).")
    cid = m.group(1)
    try: c = _S["dc"].channel(cid); _S["dc"].messages(cid, limit=1)        # erişim denemesi (okuma izni)
    except DiscordError as e: return _err(str(e), 400)
    gname = ""
    try:
        if c.get("guild_id"): gname = next((g["name"] for g in _S["dc"].guilds() if g["id"] == c["guild_id"]), "")
    except DiscordError: pass
    _S["db"].x("INSERT INTO channels(id,guild_id,guild_name,name,enabled,added) VALUES(?,?,?,?,1,?) ON CONFLICT(id) DO UPDATE SET enabled=1,name=excluded.name,guild_name=excluded.guild_name",
               (cid, c.get("guild_id"), gname, c.get("name") or cid, int(time.time())))
    _S["db"].event("info", f"Kanal eklendi: #{c.get('name')} ({gname})"); _S["mon"].start()
    return jsonify(ok=True)

@bp.delete("/api/giveaway/channels/<cid>")
def del_channel(cid):
    _S["db"].x("UPDATE channels SET enabled=0 WHERE id=?", (cid,)); return jsonify(ok=True)

@bp.post("/api/giveaway/settings")
def settings():
    uid = str((request.get_json(silent=True) or {}).get("user_id", "")).strip()
    if uid and not re.fullmatch(r"\d{15,25}", uid): return _err("Discord kullanıcı kimliği 17-20 haneli bir sayıdır.")
    _S["db"].set("discord_user_id", uid); return jsonify(ok=True)

@bp.post("/api/giveaway/scan")
def scan():
    """Elle tara: arka plan döngüsünü beklemeden bir tur çalıştırır."""
    if not _S["dc"].has_token(): return _err("Önce Discord bot token'ı gir.")
    try: _S["mon"].cycle()
    except DiscordError as e: return _err(str(e), 502)
    return jsonify(ok=True)

@bp.get("/api/giveaway/notifications")
def notifs(): return jsonify(_S["db"].q("SELECT * FROM notifications ORDER BY id DESC LIMIT 100"))

@bp.post("/api/giveaway/notifications/read")
def notifs_read(): _S["db"].x("UPDATE notifications SET is_read=1"); return jsonify(ok=True)

@bp.get("/api/giveaway/events")
def events(): return jsonify(_S["db"].q("SELECT * FROM events ORDER BY id DESC LIMIT 150"))
