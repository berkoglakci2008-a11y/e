import csv, io
def _comment(m, length): return m["comments"].get(length) or next(iter(m["comments"].values()))

def to_txt(moments, length="orta"):
    return "\n\n".join(f"{m['time']}\nKategori: {m['category']}\nÖnem puanı: {m['score']}/10\nAltyazı: {m['subtitle']}\nYorum: \"{_comment(m, length)}\""
                       for m in moments) + "\n"

def to_csv(moments, length="orta"):
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["zaman", "saniye", "kategori", "puan", "altyazi", "yorum"])
    for m in moments: w.writerow([m["time"], m["t"], m["category"], m["score"], m["subtitle"], _comment(m, length)])
    return "\ufeff" + buf.getvalue()      # Excel için BOM
