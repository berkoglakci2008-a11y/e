from collections import Counter, defaultdict
from statistics import median
from .lexicon import KeywordDictionary, GROUPS, QWORDS, QSTART
from .textutil import tokens, STOP

CATEGORIES = ["Komik","Şaşkınlık","Eleştirel","Destekleyici","Tartışma başlatan","Soru soran","Genel","Duygusal"]
_PRIORITY = ["Komik","Şaşkınlık","Tartışma başlatan","Eleştirel","Duygusal","Destekleyici","Soru soran","Genel"]
WEAK = {"silence", "repeat", "density", "speaker"} | {g + "_weak" for g in GROUPS}   # tek başına yorum noktası yaptırmayan zayıf sinyaller
DEFAULT_WEIGHTS = dict(question=2, exclaim=2, surprise=3, humor=3, conflict=3, emotion=3, support=2, critical=3,
                       repeat=1, silence=1, density=2, speaker=1, laughter_tag=4, applause_tag=3)

def raw_to_10(raw): return max(1, min(10, round(1 + raw * 0.9)))

class ImportanceScoringEngine:
    """Kural tabanlı puanlama. Puanlar sezgiseldir; tek başına noktalama kanıt sayılmaz (üst sınır uygulanır)."""
    def __init__(self, weights=None, kd=None, silence_gap=3.0):
        self.w = {**DEFAULT_WEIGHTS, **(weights or {})}
        self.kd, self.silence_gap = kd or KeywordDictionary(), silence_gap

    def analyze(self, lines):
        n, w = len(lines), self.w
        toks = [set(t for t in tokens(l["text"]) if len(t) >= 5 and t not in STOP) for l in lines]
        dens = []
        for i, l in enumerate(lines):
            nxt = lines[i + 1]["t"] if i + 1 < n else l["t"] + l["d"]
            dens.append(len(l["text"]) / max(0.5, min(l["d"], max(nxt - l["t"], 0.5))))
        out = []
        for i, l in enumerate(lines):
            text = l["text"]; tk = tokens(text); nw = len(tk)
            c = {g: self.kd.count(text, g) for g in GROUPS}
            lex = {}
            for g in GROUPS:
                cw = self.kd.count(text, g, weak=True)
                if c[g]: lex[g] = w[g] * min(c[g] + cw, 2)
                elif cw >= 2: lex[g] = w[g]                 # iki zayıf kelime birlikte: güçlü sinyal
                elif cw: lex[g + "_weak"] = w[g] * 0.5      # tek zayıf kelime: puana katkı, tek başına an yaptırmaz
            qword = bool(tk) and (any(t in QWORDS for t in tk) or tk[0] in QSTART)
            if qword: lex["question"] = w["question"]
            if i and nw >= 3 and l["t"] - (lines[i-1]["t"] + lines[i-1]["d"]) >= self.silence_gap: lex["silence"] = w["silence"]
            cnt = Counter(t for j in range(max(0, i-6), min(n, i+7)) if j != i for t in toks[j])
            if any(cnt[t] >= 3 for t in toks[i]): lex["repeat"] = w["repeat"]
            med = median(dens[max(0, i-12):i+13])
            if nw >= 4 and med and dens[i] > 1.7 * med: lex["density"] = w["density"]
            if l.get("speaker_change"): lex["speaker"] = w["speaker"]
            if "laughter" in l.get("tags", []): lex["laughter_tag"] = w["laughter_tag"]
            if "applause" in l.get("tags", []): lex["applause_tag"] = w["applause_tag"]
            punct = {}
            if nw >= 3:
                if "?" in text and not qword: punct["question_mark"] = w["question"]
                if "!" in text: punct["exclaim"] = w["exclaim"]
            ppts = sum(punct.values())
            strong = any(k not in WEAK for k in lex)
            raw = sum(lex.values()) + ppts
            if not strong: raw = min(raw, 2)      # yalnızca noktalama/zayıf sinyal: eşiği (3) geçemez
            cs = defaultdict(float, {"Genel": 0.5})
            cs["Komik"] += lex.get("humor", 0) + lex.get("humor_weak", 0) + lex.get("laughter_tag", 0)
            cs["Şaşkınlık"] += lex.get("surprise", 0) + lex.get("surprise_weak", 0) + (0.5 if "exclaim" in punct else 0)
            cs["Tartışma başlatan"] += lex.get("conflict", 0) + lex.get("conflict_weak", 0)
            cs["Eleştirel"] += lex.get("critical", 0) + lex.get("critical_weak", 0)
            cs["Destekleyici"] += lex.get("support", 0) + lex.get("support_weak", 0) + lex.get("applause_tag", 0)
            cs["Duygusal"] += lex.get("emotion", 0) + lex.get("emotion_weak", 0)
            cs["Soru soran"] += lex.get("question", 0) + punct.get("question_mark", 0)
            cat = max(_PRIORITY, key=lambda k: (cs[k], -_PRIORITY.index(k)))
            out.append({"raw": raw, "score": raw_to_10(raw), "category": cat, "strong": strong, "features": {**lex, **punct}})
        return out
