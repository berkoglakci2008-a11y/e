import datetime, os, zlib
from .metadata import fetch_metadata
from .subtitles import fetch_subtitles, parse_subtitles, SubtitleError
from .scoring import ImportanceScoringEngine
from .detector import CommentPointDetector
from .generator import CommentGenerator, DuplicateCommentFilter
from .storage import HistoryManager
from .crowd import build_profile

class NoMomentsError(Exception): pass

def merge_comments(got, tpl):
    """Modelin geçerli yazdıkları önceliklidir; eksik uzunluk, modelin yazdığı en yakın uzunlukla doldurulur (şablon son çare)."""
    order = ("kısa", "orta", "uzun"); out, src = {}, {}
    for i, k in enumerate(order):
        near = sorted(got, key=lambda g: abs(order.index(g) - i))
        if near: out[k], src[k] = got[near[0]], "ollama"
        else: out[k], src[k] = tpl[k], "şablon"
    return out, src

def analyze_video(vid, data_dir, progress=lambda s, p: None, fetcher=None, meta_fetcher=None, weights=None, detector=None, seed=None, crowd_fetcher=None, writer=None):
    progress("Video bilgileri alınıyor", 0.05)
    meta = (meta_fetcher or fetch_metadata)(vid)
    progress("Altyazı alınıyor", 0.2)
    raw, lang, generated = (fetcher or fetch_subtitles)(vid, os.path.join(data_dir, "cache"))
    progress("Altyazı ayrıştırılıyor", 0.4)
    lines = parse_subtitles(raw)
    if not lines: raise SubtitleError("Altyazı boş geldi, analiz yapılamadı.")
    duration = lines[-1]["t"] + lines[-1]["d"]
    progress("Metin analiz ediliyor", 0.55)
    scored = ImportanceScoringEngine(weights).analyze(lines)
    progress("Önemli anlar seçiliyor", 0.75)
    crowd = None
    if crowd_fetcher:
        progress("İzleyici yorumları inceleniyor", 0.65)
        try: crowd = build_profile(crowd_fetcher(vid), lines)
        except Exception: crowd = None          # yorum çekilemezse genel üslupla devam
    moments = (detector or CommentPointDetector()).detect(lines, scored, duration, boost=(crowd or {}).get("topic", []))
    if not moments:
        raise NoMomentsError("Altyazıda yorum yazmaya değer belirgin bir an bulunamadı. Sayı uydurulmadı.")
    for i in range(2, len(moments)):         # kimse art arda 3 kez aynı tonda yorum yazmaz
        if moments[i]["category"] != "Genel" and moments[i]["category"] == moments[i - 1]["category"] == moments[i - 2]["category"]:
            moments[i]["category"] = "Genel"
    progress("Yorumlar hazırlanıyor", 0.8)
    dup = DuplicateCommentFilter(); gen = CommentGenerator(seed=zlib.crc32(vid.encode()) if seed is None else seed, dup=dup, crowd=crowd)
    engine, note, used_llm = "şablon", "", []
    use_llm = bool(writer) and writer.status()[0]
    if writer and not use_llm: note = writer.status()[2]
    for n, m in enumerate(moments):
        tpl = gen.generate(m); got = {}
        if use_llm:
            progress(f"Yorumlar yazılıyor ({n + 1}/{len(moments)})", 0.8 + 0.19 * n / len(moments))
            try: got = writer.write(m, meta.get("title", ""), crowd, used_llm)
            except Exception as e:
                writer.fail_streak += 1; got = {}
                if writer.fail_streak >= 3: use_llm, note = False, "Ollama yanıt vermedi, şablonlara dönüldü."
            else: writer.fail_streak = 0
        m["comments"], m["source"] = merge_comments(got, tpl)
        used_llm += [v for v in got.values()]
        m["used"] = list(m["comments"].values())
    if writer and any("ollama" in m["source"].values() for m in moments): engine = "ollama:" + writer.status()[1]
    result = {"vid": vid, "meta": meta, "language": lang, "auto_generated": generated, "duration": int(duration),
              "crowd": crowd, "engine": engine, "engine_note": note, "created": datetime.datetime.now().isoformat(timespec="seconds"), "moments": moments}
    HistoryManager(data_dir).save(result)
    return result
