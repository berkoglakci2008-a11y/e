"""Videonun mevcut izleyici yorumlarından üslup profili: argo sıklığı, emoji oranı, videoya özgü konu kelimeleri."""
import re
from collections import Counter
from .textutil import tokens, STOP

SLANG = ["ya", "lan", "be", "abi", "kral", "valla", "resmen", "yani", "ha", "ulan", "kanka", "moruk", "aga", "reis", "hocam", "bro", "knk", "dostum", "gg", "nt"]
_EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF]")
_NOISE = re.compile(r"https?://\S+|@\w+|\b\d{1,2}:\d{2}(?::\d{2})?\b")

def build_profile(comments, lines, min_n=5):
    """comments: ham yorum metinleri; lines: ayrıştırılmış altyazı. Yeterli yorum yoksa None."""
    cs = [c for c in (_NOISE.sub(" ", c or "") for c in comments) if c.strip()]
    if len(cs) < min_n: return None
    n = len(cs); df = Counter()
    for c in cs: df.update(set(tokens(c)))
    vocab = {t for l in lines for t in tokens(l["text"])}
    topic = [t for t, k in df.most_common(300) if k >= 2 and len(t) >= 3 and t not in STOP and t not in SLANG and t in vocab][:30]
    samples = [re.sub(r"\s+", " ", x).strip() for x in cs if 8 <= len(x.strip()) <= 140 and "\n" not in x.strip()][:12]   # LLM'e üslup örneği
    return {"samples": samples, "n": n, "slang": {w: df[w] for w in SLANG if df[w]}, "emoji": round(sum(bool(_EMOJI.search(c)) for c in cs) / n, 2), "topic": topic}
