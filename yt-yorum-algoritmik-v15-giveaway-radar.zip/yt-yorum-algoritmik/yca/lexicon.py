import re
from .textutil import tr_lower

# "kelime*" = ön ek eşleşmesi (Türkçe ekler için).
RAW = {   # güçlü sinyaller: tek başına yorum noktası yaptırır
 "tr": {
  "surprise": ["şaşır*","şaşk*","şok","vay","yok artık","ciddi misin","sen ciddi misin","gerçekten mi","hadi ya","olamaz",
               "nasıl yani","aman tanrım","aman allahım","inanılmaz","inanamıyorum","beklemiyordum","hayret","ne oluyor"],
  "humor": ["haha*","hah","ahah*","komik","güldü*","gülüyor*","gülmek*","kahkaha*","espri*","şaka*","dalga geç*"],
  "conflict": ["katılmıyorum","haksız","yalan*","kavga*","itiraz*","suçla*","öyle değil","hayır hayır","doğru değil"],
  "emotion": ["ağla*","gözyaşı","duygulan*","üzül*","üzgün","özledim","özlem*","seviyorum","kalbim","pişman*","mutluluk","hüzün*"],
  "support": ["bravo","helal","muhteşem","tebrik*","başarılar","efsane","aferin"],
  "critical": ["rezalet","berbat","rezil","yetersiz","utanç","skandal"],
 },
 "en": {
  "surprise": ["wow","no way","oh my god","omg","unbelievable","seriously","shocked","what the","can't believe","cannot believe","surprised"],
  "humor": ["haha*","lol","lmao","funny","joke*","hilarious","laugh*","kidding"],
  "conflict": ["disagree","liar","lies","argue*","arguing","fight*","nonsense","not true","blame*","stupid"],
  "emotion": ["cry*","tears","miss you","sad","emotional","love you","grief","hurt*"],
  "support": ["awesome","amazing","congrat*","well done","brilliant","bravo"],
  "critical": ["terrible","awful","disappointing","ridiculous","shame"],
 },
}
# zayıf sinyaller: günlük konuşmada çok geçer; tek başına yetmez, aynı grupta 2 tane birlikte olunca güçlü sayılır
WEAK_RAW = {
 "tr": {
  "surprise": ["bu ne"],
  "humor": [],
  "conflict": ["haklı","saçma","tartış*","yanlış"],
  "emotion": ["acı"],
  "support": ["teşekkür*","harika","süper","mükemmel","destek*"],
  "critical": ["kötü","hata*","eksik*","sorun*"],
 },
 "en": {
  "surprise": [],
  "humor": [],
  "conflict": ["wrong","lie"],
  "emotion": ["heart","sorry"],
  "support": ["thank*","great","perfect","support*"],
  "critical": ["bad","mistake*","problem*","fail*"],
 },
}
QWORDS = {"mi","mı","mu","mü","misin","mısın","musun","müsün","miyim","mıyım","miyiz","mıyız","mıydı","miydi"}
QSTART = {"neden","niçin","nasıl","kim","kime","nerede","hangi","kaç","why","how","what","who","where","when"}
GROUPS = ["surprise","humor","conflict","emotion","support","critical"]

def _compile(words):
    parts = [re.escape(w[:-1]) + r"\w*" if w.endswith("*") else re.escape(w) + r"(?!\w)" for w in words]
    return re.compile(r"(?<!\w)(?:" + "|".join(parts) + ")")

class KeywordDictionary:
    """Anahtar kelime sözlüğü: metindeki gruba ait eşleşme sayısını verir (TR ve EN birlikte)."""
    def __init__(self, extra=None):
        self._re = {}
        for weak, table in ((False, RAW), (True, WEAK_RAW)):
            for lang, groups in table.items():
                for g, words in groups.items():
                    ws = list(words) + ([] if weak else list((extra or {}).get(lang, {}).get(g, [])))
                    self._re[(lang, g, weak)] = _compile(ws) if ws else None
    def count(self, text, group, weak=False):
        tr, en = tr_lower(text), text.lower(); n = 0
        for lang, t in (("tr", tr), ("en", en)):
            rx = self._re[(lang, group, weak)]
            if rx: n += len(rx.findall(t))
        return n
