"""CommentTemplateDatabase: gerçek izleyici yorumu üslubunda (küçük harf, noktasız, argo) kısa tepkiler.
{k} = altyazıdan seçilen, videoya özgü nadir kelime (çekimsiz, tırnaksız). Üslup kaynağı: gerçek YouTube yorumları."""
_P = ["", "", "", "", "ya", "lan", "valla", "bence", "off", "ee"]          # çoğu zaman dolgu kelimesi YOK (gerçek yorumlar da her cümleye "ya/lan" eklemez)
_T = ["be", "ya", "valla", "resmen", "abi", "yani", "bence", "kral", "lan"]

DB = {
"Komik": dict(prefixes=_P, tails=_T, cores=[
 "koptum","güldüm resmen","bu adam beni bitirdi","kahkaha attım","yine mi ya hahaha","nasıl yani ya hahaha","bunu bekleyen yoktu",
 "gülmekten yerlere yattım","ağlıyorum ya","bi dakika ne oldu hahaha","adam resmen şaka gibi","tutamadım kendimi","bu ne ya hahaha",
 "{k} diyince koptum","{k} ya hahaha","yine {k} ya","{k} olayı beni bitirdi","{k} bile komik oldu","bi {k} eksikti zaten","{k} mi çıktı şimdi hahaha","{k} diyen adam efsane"]),
"Şaşkınlık": dict(prefixes=_P, tails=_T, cores=[
 "bu nasıl oldu ya","ne oluyor lan","inanamıyorum","yok artık","hadi be","bunu beklemiyordum","bi saniye ne gördüm","nasıl ya","ağzım açık kaldı",
 "olamaz ya","bu kadar da olmaz","ne alaka şimdi","geri sarıp tekrar baktım",
 "{k} mı çıktı şimdi","{k} nereden çıktı ya","yok artık {k}","{k} ne alaka","{k} bu kadar da olmaz","{k} diyince şok oldum"]),
"Eleştirel": dict(prefixes=_P, tails=_T, cores=[
 "bu pek olmamış","burada hata var gibi","bunu anlamadım ya","biraz abartılmış","yanlış karar olmuş","daha iyi olabilirdi","bu mantıksız ya",
 "sinir oluyorum böyle şeylere","ben olsam yapmazdım","bu böyle olmaz ya",
 "{k} olayı pek olmamış","{k} konusuna katılmıyorum","{k} fazla abartılmış","{k} yerine başka bir şey yapılsa","{k} hiç mantıklı değil"]),
"Destekleyici": dict(prefixes=_P, tails=_T, cores=[
 "helal olsun","tam yerinde","adam haklı","işte bu","çok iyi ya","doğru söylüyor","sonuna kadar katılıyorum","bunu bekliyordum","efsane ya","güzel anlatmış",
 "{k} olayı çok iyiydi","{k} tam yerinde","{k} için helal","{k} efsane ya","{k} konusunda haklı"]),
"Tartışma başlatan": dict(prefixes=_P, tails=_T, cores=[
 "buna katılmıyorum","tam tersi olmalı","bu tartışılır","ben olsam yapmazdım","bu yanlış","bu işin iki tarafı var","kafam karıştı ya","bunu savunan var mı",
 "bence tersi doğru","ben öyle düşünmüyorum",
 "{k} konusunda kafam karıştı","{k} için farklı düşünüyorum","{k} yanlış","{k} olayı tartışılır","{k} konusunda hemfikir değilim"]),
"Soru soran": dict(prefixes=_P, tails=["ya","acaba","anlamadım","merak ettim","bilen var mı"], cores=[
 "burada ne oldu","bunu anlayan var mı","bu nasıl oldu","bu ne demek","bilen var mı","sadece ben mi fark ettim","şimdi ne olacak","neden böyle yaptı",
 "bu nerede çekildi","ben mi kaçırdım","bunun sebebi ne",
 "{k} ne demek bilen var mı","{k} neydi ya","{k} nereden çıktı","{k} mi demişti","{k} olayı ne oldu"]),
"Genel": dict(prefixes=_P, tails=_T, cores=[
 "tam burada başladı","işte bu an","buna bayıldım","güzel gidiyor","burada durdum","aynen böyle","evet tam bunu diyordum","geri sardım burayı","nt",
 "tam bu an ya",
 "{k} olayı güzeldi","{k} geldi ya","{k} diyince aklıma geldi","yine {k}","{k} bence önemli","{k} kısmında durdum"]),
"Duygusal": dict(prefixes=_P, tails=_T, cores=[
 "sustum kaldım","içimi acıttı","duygulandım","çok içten ya","özledim ya","ağlayacağım ya","çok gerçekti","içim ısındı","bunu duyunca durdum","çok dokundu",
 "{k} diyince içim burkuldu","{k} çok dokundu","{k} yüzünden gözlerim doldu","{k} ya ağlatıyor","{k} deyince durdum"]),
}

# "uzun" yorumların ikinci yarısı: kısa, uydurma ayrıntı içermeyen devam cümleleri
EXT = {
 "Komik": ["gülmekten ağlıyorum","bi daha izledim","arkadaşa attım","kendimi tutamadım","daha ne olsun","bu kadarı da olmaz","sesli güldüm","yine izlerim bunu","yanımdakiler baktı","geri sarıp izledim"],
 "Şaşkınlık": ["hala aklım almıyor","bunu kim tahmin eder","ne diyeceğimi bilemedim","bi daha izledim yine şaşırdım","hiç beklemiyordum","olacak iş değil","geri sardım tekrar baktım","gözlerime inanamadım","yanlış duydum sandım","kulaklığı çıkarıp tekrar dinledim"],
 "Eleştirel": ["daha iyi yapılabilirdi","böyle olmaz tabi","bu kadar basit değil ki","biraz acele edilmiş bence","bunu savunmak zor","geri kalanı güzeldi ama","ben olsam başka yapardım","pek mantıklı gelmedi bana","burada biraz yanıldı bence","daha dikkatli olunabilirdi"],
 "Destekleyici": ["doğru söze ne denir","tam bunu diyordum","aynen katılıyorum","bunu bekliyordum zaten","çok rahat anlattı","konuyu bilen biri belli","arkadaşlara da gönderdim","bunu not aldım","tam yerine oturmuş","buna diyecek yok"],
 "Tartışma başlatan": ["tam tersini düşünen var mı","herkesin fikri farklı olur","bence işin aslı başka","ben bu konuda ikiye bölünüyorum","iki tarafı da anlıyorum","bi de şöyle bakın","ben katılmıyorum ama","bence değil","ben öyle düşünmüyorum","bunu tartışırız"],
 "Soru soran": ["anlayan varsa yazsın","iki kere izledim yine anlamadım","ben mi kaçırdım","bi bilen yok mu","biri açıklasın","ben mi anlamadım","kaçıncı videoda söylemişti bunu","yoksa şaka mıydı","neden böyle oldu anlamadım","ne zaman olmuştu bu"],
 "Genel": ["izlerken durup düşündüm","tam burada kilitlendim","güzel gidiyor devam","yine izlerim bunu","zaman akıp gitti","beklemiyordum ama güzel oldu","geri sarıp tekrar baktım","dinlerken zaman geçti","ben de aynısını düşünüyordum","burada bi durdum"],
 "Duygusal": ["içim ısındı bi an","bir an durdum","iyi ki denk gelmişim","çok gerçekti","bazen bi söz yeter","gözüm doldu bi an","bu bana eski günleri hatırlattı","kendimi tutamadım","çok samimiydi","bunu duyunca susup kaldım"],
}

# {f} = altyazıda söylenen 1-3 kelimelik ifade (aynen). Gerçek izleyiciler de videoda geçen şeyi tekrar edip üstüne kısa tepki yazar.
FR = {
 "Komik": ["{f} diyince koptum","{f} dedi ya ağlıyorum","{f} ne ya hahaha","adam {f} diyor ya kendimi tutamadım","{f} duyunca güldüm resmen","{f} da ne demek ya hahaha","{f} derken kendini tutamamış","{f} kısmı çok iyiydi hahaha"],
 "Şaşkınlık": ["{f} dedi ya şok oldum","{f} mı dedi şimdi","{f} diyince ne oldu ya","yok artık {f} dedi","{f} ne alaka ya","{f} derken ben dondum kaldım","{f} mi ya ciddi misin","{f} diyeni duyunca geri sardım"],
 "Eleştirel": ["{f} demesi pek olmamış","{f} diyen kişi bence yanılıyor","{f} olayına katılmıyorum","{f} deyip geçmiş ama öyle değil ki","{f} diyor ama bence işin aslı başka","{f} derken biraz abartmış"],
 "Destekleyici": ["{f} demesi çok iyiydi","{f} diyince helal dedim","{f} dedi ya haklı adam","{f} tam yerinde olmuş","{f} demiş ya işte bu","{f} konusunda sonuna kadar haklı"],
 "Tartışma başlatan": ["{f} diyene katılmıyorum","{f} diyor ama bence tam tersi","{f} olayı tartışılır bence","{f} derken kafam karıştı","{f} için ben farklı düşünüyorum"],
 "Soru soran": ["{f} ne demek bilen var mı","{f} dediği neydi anlamadım","{f} neydi ya","{f} diyor ama nasıl yani","{f} dedi de nasıl oldu","{f} derken ne kastetti"],
 "Genel": ["{f} dediği yerde durdum","{f} diyince aklıma geldi","yine {f} ya","{f} diyor ya tam bunu bekliyordum","{f} olayı güzeldi","{f} derken geri sardım"],
 "Duygusal": ["{f} diyince içim burkuldu","{f} dediği çok dokundu","{f} deyince gözlerim doldu","{f} dedi ya boğazım düğümlendi","{f} deyince durdum kaldım"],
}

# Altyazıdaki ifadeye doğrudan bağlanan kurallar: (regex, kategori, yorumlar)
TRIGGERS = [
 (r"ciddi misin|gerçekten mi|yok artık|hadi ya", "Şaşkınlık", ["ben de ciddi misin dedim","ciddi misin ya ben de aynısını dedim","ben de şaşırdım valla"]),
 (r"teşekkür", "Destekleyici", ["nazik adam ya","helal olsun bu nezaket"]),
 (r"haha|kahkaha|güldü", "Komik", ["ben de güldüm resmen","hahaha ben de"]),
 (r"yalan", "Tartışma başlatan", ["yalan mı doğru mu bilemedim","kim doğru söylüyor ya"]),
 (r"özledim|ağla|gözyaşı", "Duygusal", ["bu cümle içime işledi","bunu duyunca durdum"]),
]

def capacity(cat):
    s = DB[cat]; n, p, t = len(s["cores"]), len(s["prefixes"]), len(s["tails"])
    return n * p + n * p * t

class CommentTemplateDatabase:
    def __init__(self, db=None): self.db = db or DB
    def get(self, cat): return self.db.get(cat) or self.db["Genel"]
    def categories(self): return list(self.db)
