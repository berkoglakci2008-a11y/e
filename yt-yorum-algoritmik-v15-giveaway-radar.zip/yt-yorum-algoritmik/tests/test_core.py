import csv, io, os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from yca.urlparser import parse_video_id
from yca.subtitles import parse_subtitles, SubtitleError
from yca.scoring import ImportanceScoringEngine, CATEGORIES
from yca.detector import CommentPointDetector, target_count
from yca.templates_db import DB, capacity, EXT
from yca.generator import CommentGenerator, DuplicateCommentFilter
from yca.pipeline import analyze_video, NoMomentsError
from yca.storage import HistoryManager
from yca import export

def synth(minutes=10):
    """Sentetik altyazı: sade konuşma + belirli aralıklarla belirgin anlar."""
    raw, t = [], 0.0
    spikes = {20:"Haha ciddi misin yok artık!", 70:"Bence bu tamamen yanlış, katılmıyorum", 130:"Çok teşekkür ederim harika olmuş",
              200:"Neden böyle yaptın bunu anlayamadım?", 260:"Gözyaşlarımı tutamadım çok özledim seni",
              330:"[Gülüşmeler]", 400:"Bu kadar saçma bir şey duymadım, yalan söylüyorsun"}
    i = 0
    while t < minutes * 60:
        key = int(t) // 10 * 10
        text = spikes.get(key) if key in spikes and t % 10 == 0 else None
        raw.append({"t": t, "d": 3.0, "text": text or f"Bugün hava sakin ve yürüyüş yaptık konu {i}"}); t += 5; i += 1
    return raw

class T(unittest.TestCase):
    def test_url(self):
        for u in ["https://www.youtube.com/watch?v=dQw4w9WgXcQ", "https://youtu.be/dQw4w9WgXcQ?t=5",
                  "https://www.youtube.com/shorts/dQw4w9WgXcQ", "https://www.youtube.com/live/dQw4w9WgXcQ",
                  "https://www.youtube.com/watch?feature=share&v=dQw4w9WgXcQ"]:
            self.assertEqual(parse_video_id(u), "dQw4w9WgXcQ", u)
        for u in ["", None, "https://example.com/watch?v=dQw4w9WgXcQ", "https://youtu.be/kisa"]:
            self.assertIsNone(parse_video_id(u))

    def test_parser_tags(self):
        raw = [{"t": 0, "d": 2, "text": "Bu çok &amp; komik <i>değil mi</i>"}, {"t": 2, "d": 1, "text": "[Gülüşmeler]"},
               {"t": 4, "d": 2, "text": ">> Merhaba"}, {"t": 7, "d": 1, "text": "[Müzik]"}]
        out = parse_subtitles(raw)
        self.assertEqual(len(out), 2); self.assertEqual(out[0]["text"], "Bu çok & komik değil mi")
        self.assertIn("laughter", out[0]["tags"]); self.assertTrue(out[1]["speaker_change"]); self.assertEqual(out[1]["text"], "Merhaba")

    def test_scoring_and_caps(self):
        lines = parse_subtitles(synth(3))
        sc = ImportanceScoringEngine().analyze(lines)
        by = {int(l["t"]): s for l, s in zip(lines, sc)}
        self.assertEqual(by[20]["category"], "Şaşkınlık"); self.assertGreaterEqual(by[20]["score"], 8)
        self.assertEqual(by[70]["category"], "Tartışma başlatan"); self.assertEqual(by[130]["category"], "Destekleyici")
        self.assertLess(by[0]["raw"], 3)
        # yalnızca noktalama (sözlük/yapı sinyali yok): üst sınır 2
        p = parse_subtitles([{"t": 0, "d": 2, "text": "Bu çok sıradan bir cümle bile değil?!"}] +
                            [{"t": i * 2, "d": 2, "text": w} for i, w in enumerate(["ağaçlar yeşildi", "kuşlar uçuyordu", "yollar uzundu", "evler küçüktü", "bulutlar geçti"], 1)])
        self.assertLessEqual(ImportanceScoringEngine().analyze(p)[0]["raw"], 2)  # noktalama tek başına eşiği (3) geçemez
        self.assertTrue(all(s["category"] in CATEGORIES for s in sc))

    def test_laughter_tag_scores(self):
        lines = parse_subtitles([{"t": 0, "d": 2, "text": "ne dedi o öyle"}, {"t": 2, "d": 1, "text": "[Laughter]"}] +
                                [{"t": 10 + i * 3, "d": 3, "text": f"normal satır numara {i}"} for i in range(6)])
        s = ImportanceScoringEngine().analyze(lines)[0]
        self.assertEqual(s["category"], "Komik"); self.assertGreaterEqual(s["raw"], 4)

    def test_detector(self):
        lines = parse_subtitles(synth(10)); sc = ImportanceScoringEngine().analyze(lines)
        ms = CommentPointDetector().detect(lines, sc, 600)
        self.assertGreaterEqual(len(ms), 5); self.assertLessEqual(len(ms), target_count(600))
        ts = [m["t"] for m in ms]; self.assertEqual(ts, sorted(ts))
        self.assertTrue(all(b - a >= 20 for a, b in zip(ts, ts[1:])))
        # zayıf sinyaller (tekrar/sessizlik) tek başına an üretmemeli
        plain = [{"t": i * 5.0, "d": 4.0, "text": f"yürüyüş sakin hava konuşma {i}"} for i in range(120)]
        pl = parse_subtitles(plain); self.assertEqual(CommentPointDetector().detect(pl, ImportanceScoringEngine().analyze(pl), 600), [])

    def test_target_count(self):
        self.assertTrue(15 <= target_count(600) <= 25); self.assertEqual(target_count(10), 5); self.assertEqual(target_count(99999), 60)

    def test_templates_capacity(self):
        self.assertEqual(set(DB), set(CATEGORIES))
        for c in DB: self.assertGreaterEqual(capacity(c), 100); self.assertGreaterEqual(len(DB[c]["cores"]), 15)

    def test_generator(self):
        gen = CommentGenerator(seed=1); seen = set()
        for i in range(48):
            m = {"category": CATEGORIES[i % 8], "subtitle": "ciddi misin yok artık bu olamaz", "keyword": "jahrein"}
            r = gen.generate(m)
            self.assertEqual(set(r), {"kısa", "orta", "uzun"}); self.assertTrue(all(r.values()))
            for v in r.values():
                self.assertNotIn(v, seen); self.assertNotIn("{k}", v); seen.add(v)
                self.assertEqual(v, v.lower()); self.assertFalse(v.endswith(".")); self.assertNotIn("“", v)
        self.assertTrue(any("jahrein" in s for s in seen))

    def test_no_ai_tells(self):
        """Eski AI-kokulu kalıplar şablonlara geri girmesin."""
        banned = ["açıkçası", "dürüst olayım", "zaman damgası", "emeğinize", "yorumlarda", "yanılıyorumdur", "yapıcı", "şimdiden teşekkür",
                  "bu kısım", "bu bölüm", "bu sahne", "“", "sabırsızlıkla", "paylaştığınız"]
        for cat, d in DB.items():
            for x in d["cores"] + d["prefixes"] + d["tails"] + EXT[cat]:
                for b in banned: self.assertNotIn(b, x.lower(), (cat, x))

    def test_keyword_rare(self):
        from yca.textutil import pick_keyword, doc_freq
        lines = ["bugün önemli bir konu var", "önemli olan burada", "jahrein kasası çalıştı", "önemli önemli önemli"]
        df = doc_freq(lines)
        self.assertEqual(pick_keyword(lines[2], df), "jahrein")
        self.assertEqual(pick_keyword("bugün önemli bir konu var", df), "")

    def test_templates_mostly_specific_and_varied(self):
        """Şablon yorumlar çoğunlukla videodaki kelimeye bağlanmalı ve art arda aynı kelimeyle başlamamalı."""
        import sys; sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
        import kalite_olc as k
        from collections import Counter
        res = k.run(seed=3); cs = [d["orta"] for _, d in res]
        spec = sum(any(w in k.tokens(m["subtitle"]) and len(w) >= 5 for w in d["orta"].split()) for m, d in res) / len(res)
        self.assertGreater(spec, 0.4)
        self.assertLess(Counter(c.split()[0] for c in cs).most_common(1)[0][1], len(cs) * 0.2)
        for a, b, c in zip(cs, cs[1:], cs[2:]): self.assertGreater(len({a.split()[0], b.split()[0], c.split()[0]}), 1)

    def test_dup_filter(self):
        f = DuplicateCommentFilter(["Merhaba dünya"]); self.assertFalse(f.accept("merhaba dünya!", ("a", 1)))
        self.assertTrue(f.accept("Başka", ("a", 2))); self.assertFalse(f.accept("Üçüncü", ("a", 2)))

    def test_pipeline_history_export(self):
        with tempfile.TemporaryDirectory() as d:
            fetch = lambda vid, cache: (synth(10), "tr", True)
            meta = lambda vid: {"title": "Deneme", "author": "K", "thumb": ""}
            r1 = analyze_video("dQw4w9WgXcQ", d, fetcher=fetch, meta_fetcher=meta)
            r2 = analyze_video("dQw4w9WgXcQ", d, fetcher=fetch, meta_fetcher=meta)
            self.assertEqual([m["comments"] for m in r1["moments"]], [m["comments"] for m in r2["moments"]])  # deterministik
            h = HistoryManager(d); self.assertEqual(h.list()[0]["count"], len(r1["moments"])); self.assertEqual(h.load("dQw4w9WgXcQ")["meta"]["title"], "Deneme")
            with self.assertRaises(ValueError): h.load("../../etc/passwd")
            txt = export.to_txt(r1["moments"], "kısa"); self.assertIn("Önem puanı:", txt)
            rows = list(csv.reader(io.StringIO(export.to_csv(r1["moments"], "uzun").lstrip("\ufeff"))))
            self.assertEqual(len(rows), len(r1["moments"]) + 1); self.assertEqual(rows[0][0], "zaman")

    def test_no_moments_not_faked(self):
        dull = [{"t": i * 5.0, "d": 4.0, "text": f"sıradan kelimeler dizisi {i} ve devam"} for i in range(40)]
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(NoMomentsError):
                analyze_video("dQw4w9WgXcQ", d, fetcher=lambda v, c: (dull, "tr", False), meta_fetcher=lambda v: {})
            with self.assertRaises(SubtitleError):
                analyze_video("dQw4w9WgXcQ", d, fetcher=lambda v, c: ([], "tr", False), meta_fetcher=lambda v: {})

import http.server, json as _json, re as _re, threading
class FakeOllama:
    """Sahte Ollama: /api/tags ve /api/chat. mode: 'ok' (altyazıdan türetilmiş yorum), 'bad' (AI kalıbı), 'err' (500), 'empty' (model yok)."""
    def __init__(self, mode="ok"):
        self.mode, self.calls = mode, 0
        outer = self
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def _send(self, code, obj):
                b = _json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b)
            def do_GET(self):
                self._send(200, {"models": [] if outer.mode == "empty" else [{"name": "qwen2.5:7b"}]})
            def do_POST(self):
                body = _json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                outer.calls += 1; outer.last = body
                if outer.mode == "err": return self._send(500, {})
                user = body["messages"][-1]["content"]
                sub = _re.search(r"Tam bu an: (.*)", user).group(1)
                w = max(_re.findall(r"[^\W\d_]{4,}", sub.lower()) or ["konu"], key=len)     # en uzun (içerik) kelime
                n = outer.calls
                if outer.mode == "bad":
                    c = {"kisa": "emeğinize sağlık", "orta": "açıkçası bu kısım çok güzel olmuş", "uzun": "Harika video, devamını sabırsızlıkla bekliyorum."}
                else:
                    c = {"kisa": f"{w} ne ya {n}", "orta": f"{w} dedi ya şok oldum resmen {n}", "uzun": f"{['adam','herif','bu çocuk','şu abi'][n % 4]} {w} dedi ya inanamıyorum bunu kim tahmin eder ki valla {n}"}
                self._send(200, {"message": {"content": _json.dumps(c)}})
        self.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.srv.server_address[1]}"
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
    def close(self): self.srv.shutdown(); self.srv.server_close()

class LLM(unittest.TestCase):
    def test_check_rejects_ai_tells(self):
        from yca.llm import check, _stems
        ctx = _stems("adamlara poseidon bıçak awp ne varsa geldi")
        for bad in ["emeğinize sağlık", "açıkçası awp geldi be", "Harika video devamını bekliyorum", "bu kısım çok iyi awp", "awp geldi. çok iyi oldu"]:
            self.assertIsNone(check(bad, "orta", ctx), bad)
        self.assertIsNone(check("bu hiç alakasız uzun bir cümle olmuş valla", "uzun", ctx))        # videodan hiçbir şey içermiyor
        self.assertEqual(check("Poseidon bıçak da mı geldi ya sinir oldum.", "uzun", ctx), "poseidon bıçak da mı geldi ya sinir oldum")
        self.assertIsNone(check("poseidon bıçak da mı geldi ya sinir oldum", "uzun", ctx, crowd=["poseidon bıçak da mı geldi ya sinir oldum"]))   # kopya
        self.assertIsNone(check("poseidon bıçak da mı geldi ya sinir oldum", "uzun", ctx, used=["Poseidon bıçak da mı geldi ya sinir oldum"]))
        self.assertEqual(check("awp geldi 😂", "kısa", ctx), "awp geldi")
        for good in ["aslında fena ödemedi awp geldi", "bence dedi ya awp geldi sinir oldum", "beğendim awp geldi tam yerinde be"]:     # gerçek insanların yazdığı kelimeler elenmemeli
            self.assertIsNotNone(check(good, "uzun" if len(good.split()) >= 7 else "orta", ctx), good)

    def test_check_rejects_stuffing_and_repeats(self):
        from yca.llm import check, _stems
        ctx = _stems("adamlara poseidon bıçak awp ne varsa geldi")
        self.assertIsNone(check("ya lan valla poseidon geldi", "orta", ctx))                         # 3 dolgu kelimesi
        self.assertIsNone(check("poseidon geldi eline sağlık", "orta", ctx))                          # kalıp övgü
        self.assertIsNone(check("poseidon geldi, bıçak geldi, awp geldi", "orta", ctx))               # virgül yığma
        used = ["adam poseidon dedi", "adam awp dedi", "başka bir şey"]
        self.assertIsNone(check("adam bıçak geldi bak", "orta", ctx, used=used))                      # hep 'adam' ile başlıyor
        self.assertIsNotNone(check("bıçak da geldi bak", "orta", ctx, used=used))

    def test_prompt_has_variety_hint(self):
        from yca.llm import OllamaWriter, HINTS
        w = OllamaWriter(); m = {"category": "Komik", "subtitle": "poseidon geldi", "t": 0}
        seen = {w.prompt(dict(m, t=t), "", None, []).split("Bu seferki yorum biçimi: ")[1] for t in range(0, 70, 7)}
        self.assertGreaterEqual(len(seen), 5); self.assertTrue(seen <= set(HINTS))

    def test_status_and_write(self):
        from yca.llm import OllamaWriter
        f = FakeOllama("ok")
        try:
            w = OllamaWriter(f.url, "yok-model"); ok, model, _ = w.status(); self.assertTrue(ok); self.assertEqual(model, "qwen2.5:7b")  # kurulu olana düşer
            m = {"category": "Komik", "subtitle": "adamlara poseidon bıçak geldi", "context": "önce awp vardı", "t": 5}
            out = w.write(m, "Video", {"samples": ["ilk turdan sinir oldum"], "emoji": 0, "topic": []}, ["eski yorum"])
            self.assertEqual(set(out), {"kısa", "orta", "uzun"})
            u = f.last["messages"][-1]["content"]; self.assertIn("ilk turdan sinir oldum", u); self.assertIn("eski yorum", u); self.assertIn("poseidon", u)
            self.assertEqual(f.last["format"]["required"], ["kisa", "orta", "uzun"])
        finally: f.close()
        self.assertFalse(OllamaWriter("http://127.0.0.1:9", "x", timeout=1).status()[0])
        f = FakeOllama("empty")
        try: self.assertFalse(OllamaWriter(f.url).status()[0])
        finally: f.close()

    def test_bad_model_output_falls_back(self):
        from yca.llm import OllamaWriter
        f = FakeOllama("bad")
        try:
            out = OllamaWriter(f.url, tries=2).write({"category": "Komik", "subtitle": "poseidon bıçak geldi", "t": 1}); self.assertEqual(out, {})
            self.assertEqual(f.calls, 2)
        finally: f.close()

    def test_merge_comments(self):
        from yca.pipeline import merge_comments
        tpl = {"kısa": "t1", "orta": "t2", "uzun": "t3"}
        self.assertEqual(merge_comments({"orta": "m"}, tpl)[0], {"kısa": "m", "orta": "m", "uzun": "m"})
        self.assertEqual(merge_comments({}, tpl)[1], {"kısa": "şablon", "orta": "şablon", "uzun": "şablon"})

    def test_pipeline_with_llm_and_fallbacks(self):
        from yca.llm import OllamaWriter
        fetch = lambda v, c: (synth(10), "tr", True); meta = lambda v: {"title": "Deneme"}
        f = FakeOllama("ok")
        try:
            with tempfile.TemporaryDirectory() as d:
                stages = []
                r = analyze_video("dQw4w9WgXcQ", d, fetcher=fetch, meta_fetcher=meta, writer=OllamaWriter(f.url), progress=lambda s, p: stages.append(s))
                self.assertTrue(r["engine"].startswith("ollama")); self.assertTrue(any("yazılıyor" in s for s in stages))
                self.assertTrue(all(m["source"]["uzun"] == "ollama" and "dedi ya inanamıyorum" in m["comments"]["uzun"] for m in r["moments"]))
                self.assertIn("context", r["moments"][0])
        finally: f.close()
        with tempfile.TemporaryDirectory() as d:     # Ollama kapalı → şablon
            r = analyze_video("dQw4w9WgXcQ", d, fetcher=fetch, meta_fetcher=meta, writer=OllamaWriter("http://127.0.0.1:9", timeout=1))
            self.assertEqual(r["engine"], "şablon"); self.assertTrue(r["engine_note"]); self.assertTrue(all(m["comments"]["uzun"] for m in r["moments"]))
        f = FakeOllama("err")
        try:
            with tempfile.TemporaryDirectory() as d:  # model hata veriyor → 3 hatadan sonra şablona dön, analiz yine biter
                w = OllamaWriter(f.url); r = analyze_video("dQw4w9WgXcQ", d, fetcher=fetch, meta_fetcher=meta, writer=w)
                self.assertEqual(r["engine"], "şablon"); self.assertTrue(r["engine_note"]); self.assertLessEqual(f.calls, 3 * 3 + 3)
        finally: f.close()

class V6(unittest.TestCase):
    def _score(self, text):
        ls = parse_subtitles([{"t": 0, "d": 3, "text": text}] + [{"t": 10 + i * 4, "d": 3, "text": f"sıradan satır numara {i}"} for i in range(6)])
        return ImportanceScoringEngine().analyze(ls)[0]
    def test_weak_words(self):
        for txt in ["evet haklısın bence", "bu işte bir sorun var galiba", "ne kadar güzel bir gün", "çok teşekkür ederim izlediğiniz için"]:
            self.assertFalse(self._score(txt)["strong"], txt)
        s = self._score("hem harika hem mükemmel olmuş"); self.assertTrue(s["strong"]); self.assertEqual(s["category"], "Destekleyici")
        self.assertTrue(self._score("hata ve sorun çıktı yine")["strong"])
        self.assertTrue(self._score("yalan söylüyor ciddi misin")["strong"])

    def test_crowd_profile_and_keyword(self):
        from yca.crowd import build_profile
        from yca.textutil import pick_keyword
        lines = parse_subtitles([{"t": 0, "d": 3, "text": "jahrein kasası awp ile geldi bayonet"}])
        cm = ["2:52 jahrein kasası güzel ya", "awp gelseydi lan", "valla jahrein ya", "https://x.co ya awp", "@biri ya jahrein 😂", "- kansticht ya"]
        p = build_profile(cm, lines)
        self.assertEqual(p["n"], 6); self.assertGreaterEqual(p["slang"]["ya"], 5); self.assertIn("jahrein", p["topic"]); self.assertNotIn("kansticht", p["topic"])
        self.assertGreater(p["emoji"], 0); self.assertIsNone(build_profile(cm[:2], lines))
        self.assertEqual(pick_keyword("jahrein kasası awp ile geldi bayonet", {"bayonet": 1}, ["awp", "jahrein"]), "awp")

    def test_pipeline_with_crowd(self):
        with tempfile.TemporaryDirectory() as d:
            cm = ["bugün hava sakin ya", "yürüyüş güzeldi ya", "ya hava sakin", "ya konu güzel", "yürüyüş ya ya", "hava ya"]
            r = analyze_video("dQw4w9WgXcQ", d, fetcher=lambda v, c: (synth(10), "tr", True), meta_fetcher=lambda v: {}, crowd_fetcher=lambda v: cm)
            self.assertEqual(r["crowd"]["n"], 6)
            r = analyze_video("dQw4w9WgXcQ", d, fetcher=lambda v, c: (synth(10), "tr", True), meta_fetcher=lambda v: {}, crowd_fetcher=lambda v: 1 / 0)
            self.assertIsNone(r["crowd"]); self.assertTrue(r["moments"])

    def test_generator_uses_crowd(self):
        crowd = {"n": 10, "slang": {"moruk": 6}, "emoji": 0.0, "topic": []}
        g = CommentGenerator(seed=2, crowd=crowd); n = 0
        for i in range(60):
            n += "moruk" in g.generate({"category": ["Genel", "Komik", "Duygusal"][i % 3], "subtitle": "x", "keyword": ""})["uzun"]
        self.assertGreater(n, 0)
        g = CommentGenerator(seed=2, crowd={"n": 10, "slang": {}, "emoji": 0.9, "topic": []})
        outs = [g.generate({"category": "Komik", "subtitle": "x", "keyword": ""})["uzun"] for _ in range(30)]
        self.assertTrue(any(ch in v for v in outs for ch in "😂🤣"))

class Web(unittest.TestCase):
    def setUp(self):
        try:
            import app as a; self.a = a; self.c = a.app.test_client()
        except ImportError: self.skipTest("flask kurulu değil")
    def test_routes(self):
        self.assertEqual(self.c.get("/").status_code, 200)
        self.assertEqual(self.c.post("/api/analyze", json={"url": "x"}).status_code, 400)
        self.assertEqual(self.c.get("/api/history/..%2f..%2fx").status_code, 404)
        self.assertEqual(self.c.get("/api/export/dQw4w9WgXcQ/exe").status_code, 404)
    def test_alternative_and_export(self):
        import app as a
        with tempfile.TemporaryDirectory() as d:
            a.history = HistoryManager(d); a.WRITER = None
            r = analyze_video("dQw4w9WgXcQ", d, fetcher=lambda v, c: (synth(10), "tr", True), meta_fetcher=lambda v: {"title": "T", "author": "", "thumb": ""})
            old = r["moments"][0]["comments"]["orta"]
            res = self.c.post("/api/alternative", json={"vid": "dQw4w9WgXcQ", "index": 0}); self.assertEqual(res.status_code, 200)
            self.assertNotEqual(res.get_json()["comments"]["orta"], old)
            e = self.c.get("/api/export/dQw4w9WgXcQ/csv?len=kısa"); self.assertEqual(e.status_code, 200); self.assertIn("attachment", e.headers["Content-Disposition"])
            self.assertEqual(self.c.post("/api/alternative", json={"vid": "dQw4w9WgXcQ", "index": 999}).status_code, 404)

class Yt(unittest.TestCase):
    def setUp(self):
        try:
            import app as a; self.a = a; self.c = a.app.test_client()
        except ImportError: self.skipTest("flask kurulu değil")
    def test_post_flow(self):
        import time
        from yca import ytapi
        a = self.a
        with tempfile.TemporaryDirectory() as d:
            a.history = HistoryManager(d); a.POSTED = os.path.join(d, "posted.json"); a._last_post[0] = 0
            analyze_video("dQw4w9WgXcQ", d, fetcher=lambda v, c: (synth(10), "tr", True), meta_fetcher=lambda v: {"title": "T", "author": "", "thumb": ""})
            calls = []
            class Fake:
                def connected(self): return True
                def post_comment(self, vid, text): calls.append((vid, text)); return "Ugx123"
            a.yt = Fake()
            ok = self.c.post("/api/post", json={"vid": "dQw4w9WgXcQ", "text": "2:52 güzel ödedi\n4:24 bari 2 katını öde be"})
            self.assertEqual(ok.status_code, 200); self.assertEqual(calls[0][1].splitlines()[0], "2:52 güzel ödedi")
            a._last_post[0] = 0   # hız sınırı dışında: aynı videoya ikinci yorum onay ister
            dup = self.c.post("/api/post", json={"vid": "dQw4w9WgXcQ", "text": "x"}); self.assertEqual(dup.status_code, 409)
            a._last_post[0] = time.time()
            self.assertEqual(self.c.post("/api/post", json={"vid": "dQw4w9WgXcQ", "text": "x", "force": True}).status_code, 429)
            self.assertEqual(self.c.post("/api/post", json={"vid": "../x", "text": "x"}).status_code, 400)
            self.assertEqual(self.c.post("/api/post", json={"vid": "dQw4w9WgXcQ", "text": " "}).status_code, 400)
            class Off(Fake):
                def connected(self): return False
            a.yt = Off(); self.assertEqual(self.c.post("/api/post", json={"vid": "dQw4w9WgXcQ", "text": "x"}).status_code, 401)

    def test_setup_saves_client(self):
        from yca import ytapi
        a = self.a
        with tempfile.TemporaryDirectory() as d:
            old = a.yt; a.yt = ytapi.YouTubeClient(d, d)
            try:
                self.assertFalse(a.yt.configured())
                bad = self.c.post("/api/setup", json={"client_id": "abc", "client_secret": "x"}); self.assertEqual(bad.status_code, 400)
                bad2 = self.c.post("/api/setup", json={"client_id": "1-a.apps.googleusercontent.com", "client_secret": "kisa"}); self.assertEqual(bad2.status_code, 400)
                self.assertFalse(a.yt.configured())
                ok = self.c.post("/api/setup", json={"client_id": " 1-a.apps.googleusercontent.com ", "client_secret": "GOCSPX-abcdef123456 "})
                self.assertEqual(ok.status_code, 200); self.assertTrue(a.yt.configured())
                self.assertIn("client_id=1-a.apps.googleusercontent.com", a.yt.login_url())
                self.assertEqual(self.c.get("/api/auth").get_json()["configured"], True)
            finally: a.yt = old

    def test_api_key_reads_comments(self):
        from yca import ytapi
        a = self.a
        with tempfile.TemporaryDirectory() as d:
            old = a.yt; a.yt = c = ytapi.YouTubeClient(d, d)
            try:
                self.assertEqual(c.top_comments("dQw4w9WgXcQ"), [])          # ne hesap ne anahtar
                self.assertEqual(self.c.post("/api/setup", json={"api_key": "abc"}).status_code, 400)
                self.assertEqual(self.c.post("/api/setup", json={}).status_code, 400)
                k = "AIza" + "x" * 35
                self.assertEqual(self.c.post("/api/setup", json={"api_key": k}).status_code, 200)
                self.assertTrue(self.c.get("/api/auth").get_json()["has_key"]); self.assertFalse(c.configured())
                sent = []
                def fake(url, data=None, headers=None, timeout=20):
                    sent.append((url, headers)); return 200, {"items": [{"snippet": {"topLevelComment": {"snippet": {"textDisplay": "süper"}}}}]}
                oh = ytapi._http; ytapi._http = fake
                try: self.assertEqual(c.top_comments("dQw4w9WgXcQ"), ["süper"])
                finally: ytapi._http = oh
                self.assertIn("key=" + k, sent[0][0]); self.assertNotIn("Authorization", sent[0][1])
            finally: a.yt = old

    def test_client_request_shape(self):
        from yca import ytapi
        with tempfile.TemporaryDirectory() as d:
            json_ = __import__("json")
            open(os.path.join(d, "client_secret.json"), "w").write(json_.dumps({"installed": {"client_id": "cid", "client_secret": "sec"}}))
            c = ytapi.YouTubeClient(d, d); self.assertTrue(c.configured()); self.assertFalse(c.connected())
            url = c.login_url(); self.assertIn("youtube.force-ssl", url); self.assertIn("access_type=offline", url)
            with self.assertRaises(ytapi.YtError): c.handle_callback("code", "yanlis-state")
            sent = []
            def fake(url, data=None, headers=None, timeout=20):
                sent.append((url, data, headers))
                return (200, {"access_token": "AT", "refresh_token": "RT", "expires_in": 3600}) if "token" in url else (200, {"id": "Ugx9"})
            old = ytapi._http; ytapi._http = fake
            try:
                c.handle_callback("code", c.state); self.assertTrue(c.connected())
                self.assertEqual(c.post_comment("dQw4w9WgXcQ", " 1:00 merhaba "), "Ugx9")
                url, data, hdr = sent[-1]
                self.assertIn("commentThreads", url); self.assertEqual(hdr["Authorization"], "Bearer AT")
                self.assertEqual(data["snippet"]["videoId"], "dQw4w9WgXcQ"); self.assertEqual(data["snippet"]["topLevelComment"]["snippet"]["textOriginal"], "1:00 merhaba")
                ytapi._http = lambda *a, **k: (403, {"error": {"errors": [{"reason": "commentsDisabled"}], "message": "m"}})
                with self.assertRaises(ytapi.YtError) as cm: c.post_comment("dQw4w9WgXcQ", "x")
                self.assertIn("kapalı", str(cm.exception))
            finally: ytapi._http = old

if __name__ == "__main__": unittest.main()
