import json, os, sys, tempfile, time, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from yca.giveaway.parser import parse_giveaway
from yca.giveaway.db import DB
from yca.giveaway.service import Monitor

def gw(mid="100", ends=None, extra="", ended=False):
    ends = ends or int(time.time()) + 3 * 86400
    desc = f"Click the button to enter!\nEnds: <t:{ends}:R>\nHosted by: <@111111111111111111>\n\nRequirements:\n- Subscribe to https://youtube.com/@kanal\n- Like and comment https://youtu.be/dQw4w9WgXcQ\n- Join https://discord.gg/abc123\n- Do something weird{extra}"
    if ended: desc = "Winners: <@222222222222222222>\nEnded: <t:1700000000:R>"
    return {"id": mid, "author": {"bot": True, "username": "GiveawayBot"}, "content": "🎉 **GIVEAWAY** 🎉", "timestamp": "2026-11-10T10:00:00+00:00",
            "embeds": [{"title": "Karambit | Doppler", "description": desc}], "components": [{"type": 1, "components": [{"type": 2, "label": "Enter"}]}]}

class Fake:
    def __init__(s): s.msgs = {"1": []}; s.tok = True
    def has_token(s): return s.tok
    def messages(s, cid, after=None, limit=50): return [m for m in s.msgs[cid] if after is None or int(m["id"]) > int(after)]
    def message(s, cid, mid): return next(m for m in s.msgs[cid] if m["id"] == mid)

class T(unittest.TestCase):
    def test_parse(self):
        p = parse_giveaway(gw())
        self.assertEqual(p["prize"], "Karambit | Doppler"); self.assertEqual(p["videos"], ["dQw4w9WgXcQ"]); self.assertEqual(p["invites"], ["abc123"])
        keys = {r["key"] for r in p["requirements"]}
        self.assertTrue({"yt_subscribe", "yt_like", "yt_comment", "discord_join", "button"} <= keys)
        self.assertIn("Do something weird", p["unclear"]); self.assertFalse(p["ended"]); self.assertTrue(p["ends_at"])
    def test_not_giveaway(self):
        self.assertIsNone(parse_giveaway({"id": "5", "content": "selam nasılsınız", "author": {"bot": False}}))
    def test_turkish(self):
        m = {"id": "7", "author": {"bot": False}, "content": "🎉 ÇEKİLİŞ 🎉\nÖdül: AWP | Asiimov\nŞartlar:\n- YouTube kanalına abone ol\n- Videoyu beğen ve yorum yap https://youtu.be/dQw4w9WgXcQ\n- Sunucuya katıl"}
        p = parse_giveaway(m); self.assertEqual(p["prize"], "AWP | Asiimov"); self.assertIn("yt_subscribe", {r["key"] for r in p["requirements"]})
    def test_monitor(self):
        d = tempfile.mkdtemp(); db = DB(d); f = Fake(); mon = Monitor(db, f, 60)
        db.x("INSERT INTO channels(id,guild_id,guild_name,name,enabled,added) VALUES('1','9','S','cekilis',1,0)")
        f.msgs["1"] = [gw("100"), {"id": "101", "content": "hi", "author": {"bot": False}}]
        mon.cycle(); mon.cycle()
        self.assertEqual(len(db.q("SELECT * FROM giveaways")), 1)                      # çift kayıt yok
        # yeniden başlatma: yeni DB/Monitor nesnesi aynı noktadan devam eder
        mon2 = Monitor(DB(d), f, 60); f.msgs["1"].append(gw("102")); mon2.cycle()
        self.assertEqual(len(db.q("SELECT * FROM giveaways")), 2)
        # katıldım + bitiş + kazanan
        g = db.one("SELECT * FROM giveaways WHERE message_id='100'")
        db.set("discord_user_id", "222222222222222222"); db.x("UPDATE giveaways SET state='joined' WHERE id=?", (g["id"],))
        f.msgs["1"][0] = gw("100", ended=True); mon.refresh_one(db.one("SELECT * FROM giveaways WHERE id=?", (g["id"],)))
        g = db.one("SELECT * FROM giveaways WHERE id=?", (g["id"],)); self.assertEqual((g["status"], g["result"]), ("ended", "won"))
        self.assertTrue(any(n["kind"] == "result" for n in db.q("SELECT * FROM notifications")))
if __name__ == "__main__": unittest.main()
