"""Yorum analizi testleri. DİKKAT: buradaki yorumlar ve API cevapları YAPAY test verisidir; gerçek YouTube verisiyle test sayılmaz."""
import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from yca import ytapi
from yca.insight import collect, engine, pipeline, report

def raw(i, text, likes=0, author=None, ch=None):
    return {"id": i, "snippet": {"textOriginal": text, "authorDisplayName": author or "u" + i, "authorChannelId": {"value": ch or "UC" + i}, "likeCount": likes, "publishedAt": "2026-10-28T10:00:00Z"}}
def thread(i, text, reps=(), total=None, likes=0):
    return {"snippet": {"topLevelComment": raw(i, text, likes), "totalReplyCount": len(reps) if total is None else total}, "replies": {"comments": [raw(*r) for r in reps]} if reps else None}

class FakeClient(ytapi.YouTubeClient):
    def __init__(self, pages, comments=None, fail=None):
        self.pages, self.comments, self.fail, self.quota, self.calls = pages, comments or {}, fail, 0, []
    def video_info(self, vid): return {"id": vid, "title": "Test videosu", "description": "", "channel_id": "UCowner", "channel_title": "k", "published": "", "tags": [], "comment_count": 5, "view_count": 1, "like_count": 1}
    def get(self, path, q, cost=1):
        self.quota += cost; self.calls.append((path, q.get("pageToken"), q.get("parentId")))
        if self.fail and self.fail(path, q, len(self.calls)): raise self.fail(path, q, len(self.calls))
        if path == "/comments": return self.comments[q["parentId"]]
        return self.pages[q.get("pageToken") or 0]

class Collect(unittest.TestCase):
    def test_pagination_dedupe_and_full_replies(self):
        pages = {0: {"items": [thread("a", "bir"), thread("b", "iki", [("r1", "x")], total=3)], "nextPageToken": "p2"}, "p2": {"items": [thread("b", "iki"), thread("c", "üç")]}}
        cm = {"b": {"items": [raw("r1", "x"), raw("r2", "y"), raw("r3", "z")]}}
        v, th, col = collect.fetch_all(FakeClient(pages, cm), "V" * 11, sleep=lambda s: None)
        self.assertEqual([t["id"] for t in th], ["a", "b", "c"]); self.assertEqual(len(th[1]["replies"]), 3)
        self.assertEqual(col["duplicates_skipped"], 2); self.assertEqual(col["pages"], 2); self.assertTrue(col["complete"]); self.assertEqual(col["quota_used"], 3)
    def test_cap_marks_incomplete(self):
        pages = {0: {"items": [thread(str(k), "t") for k in range(5)], "nextPageToken": "p2"}, "p2": {"items": []}}
        _, th, col = collect.fetch_all(FakeClient(pages), "V" * 11, max_threads=3, sleep=lambda s: None)
        self.assertEqual(len(th), 3); self.assertTrue(col["capped"]); self.assertFalse(col["complete"])
    def test_comments_disabled_and_quota_partial(self):
        _, th, col = collect.fetch_all(FakeClient({}, fail=lambda p, q, n: ytapi.CommentsDisabled("kapalı")), "V" * 11, sleep=lambda s: None)
        self.assertEqual((th, col["status"]), ([], "comments_disabled"))
        pages = {0: {"items": [thread("a", "x")], "nextPageToken": "p2"}}
        _, th, col = collect.fetch_all(FakeClient(pages, fail=lambda p, q, n: ytapi.QuotaExceeded("kota") if n == 2 else None), "V" * 11, sleep=lambda s: None)
        self.assertEqual(len(th), 1); self.assertEqual(col["status"], "quota_partial"); self.assertFalse(col["complete"])
    def test_transient_retry(self):
        pages = {0: {"items": [thread("a", "x")]}}
        c = FakeClient(pages, fail=lambda p, q, n: ytapi.Transient("503") if p == "/commentThreads" and n <= 2 else None)
        _, th, col = collect.fetch_all(c, "V" * 11, sleep=lambda s: None); self.assertEqual(len(th), 1); self.assertEqual(col["status"], "ok")
    def test_error_mapping(self):
        e = ytapi.api_exception(403, {"error": {"errors": [{"reason": "commentsDisabled"}], "message": "m"}}); self.assertIsInstance(e, ytapi.CommentsDisabled)
        self.assertIsInstance(ytapi.api_exception(403, {"error": {"errors": [{"reason": "quotaExceeded"}]}}), ytapi.QuotaExceeded)
        self.assertIsInstance(ytapi.api_exception(503, {}), ytapi.Transient)

def T(i, text, likes=0, replies=(), ch=None):
    return {"id": i, "text": text, "author": "u" + i, "author_channel": ch or "UC" + i, "likes": likes, "published": "", "reply_count": len(replies), "replies": list(replies)}
def R(i, p, text, ch=None): return {"id": i, "text": text, "author": "r" + i, "author_channel": ch or "UR" + i, "likes": 0, "published": "", "parent": p}
VID = {"id": "A" * 11, "title": "Kasa açılımı CS2", "description": "oyun videosu", "channel_id": "UCowner", "channel_title": "k"}

class Engine(unittest.TestCase):
    def one(self, text, replies=()):
        r = engine.analyze(VID, [T("c1", text, replies=replies)]); return r["comments"][0]
    def test_basic_sentiment(self):
        self.assertEqual(self.one("Video çok güzel olmuş")["label"], "pozitif")
        self.assertEqual(self.one("Berbat bir video saçma")["label"], "negatif")
        self.assertEqual(self.one("kurgu harika ama video çok uzun")["label"], "karışık")
        self.assertEqual(self.one("güzel değil")["label"], "negatif"); self.assertEqual(self.one("kötü değil")["label"], "pozitif")
    def test_irony_needs_evidence(self):
        a = self.one("Yine muhteşem bir iş çıkarmışsın (!)"); self.assertEqual(a["label"], "belirsiz")        # bağlam yok → belirsiz
        b = self.one("Yine muhteşem bir iş çıkarmışsın (!)", [R("r1", "c1", "aynen aynen 🤡"), R("r2", "c1", "çok kötü"), R("r3", "c1", "rezalet")]); self.assertEqual(b["label"], "negatif")
        self.assertEqual(self.one("muhteşem 🤡")["label"], "negatif")
    def test_categories(self):
        self.assertIn("Soru", self.one("bu kod gerçekten çalışıyor mu?")["tags"]); self.assertIn("Öneri", self.one("keşke valorant da yapsan")["tags"])
        self.assertEqual(self.one("kanalıma abone olun https://x.com/a")["category"], "Reklam")
    def test_duplicate_spam_and_short_reactions(self):
        th = [T(str(i), "bu video harika bence hemen izleyin", ch="UCbot" + str(i)) for i in range(3)] + [T("h1", "helal"), T("h2", "helal")]
        r = engine.analyze(VID, th); c = {x["id"]: x for x in r["comments"]}
        self.assertTrue(all(c[str(i)]["dup"] for i in range(3))); self.assertFalse(c["h1"]["dup"])
    def test_owner_excluded_and_denominator(self):
        r = engine.analyze(VID, [T("c1", "güzel", replies=[R("r1", "c1", "teşekkürler", ch="UCowner")]), T("c2", "kötü")])
        self.assertEqual(r["stats"]["n_total"], 2); self.assertEqual(r["stats"]["creator_items"], 1); self.assertEqual(r["discussion"]["creator"]["replies"], 1)
        self.assertEqual(sum(v["n"] for v in r["stats"]["sentiment"].values()), 2)
    def test_likes_alone_not_quality(self):
        r = engine.analyze(VID, [T("a", "ilk", likes=500), T("b", "Ses seviyesi çok düşük, mikrofon sürekli patlıyor ve müzik sesi konuşmayı bastırıyor", likes=3)])
        c = {x["id"]: x for x in r["comments"]}; self.assertGreater(c["b"]["impact"], c["a"]["impact"]); self.assertTrue(c["a"]["shallow_viral"])

class Report(unittest.TestCase):
    def setUp(self):
        th = [T(str(i), t, likes=i, replies=[R("r" + str(i), str(i), "aynen")] if i % 4 == 0 else []) for i, t in enumerate(
            ["Anlatım çok güzel olmuş", "Anlatım harika", "Anlatım tarzına bayıldım", "Ses kötü mikrofon patlıyor", "Ses seviyesi berbat", "Ses sürekli bozuk", "Kurgu süper", "Video çok uzun olmuş sıkıldım",
             "Ne zaman yeni video gelecek?", "Nasıl yaptın bunu?", "Keşke valorant da yapsan", "Keşke bir de minecraft yapsan", "Keşke uzun video yapsan", "haha koptum 😂", "kanalıma abone ol https://a.com"] * 3)]
        for k, x in enumerate(th):      # test verisinde aynı cümle 3 kez geçmesin (aksi halde tekrar/spam sayılır)
            if "kanalıma" not in x["text"]: x["text"] += ["", " bence", " valla"][k // 15]
        self.res = engine.analyze(VID, th, collection={"threads": 45, "replies_fetched": 12, "reported_comment_count": 60, "complete": False, "notes": ["Üst sınır nedeniyle eksik."]})
    def test_all_formats_pass_qc_and_vary(self):
        for f in report.FORMATS:
            rep = pipeline.make_report(self.res, f, seed=1); self.assertTrue(rep["quality"]["passed"], (f, rep["quality"]["issues"])); self.assertTrue(rep["blocks"])
        a, b = (report.blocks_text(pipeline.make_report(self.res, "detay", seed=s)) for s in (1, 2)); self.assertNotEqual(a, b)
    def test_quotes_are_verbatim(self):
        rep = pipeline.make_report(self.res, "olumlu_olumsuz", seed=3); texts = [c["text"] for c in self.res["comments"]]
        self.assertTrue(rep["quotes"]); self.assertTrue(all(any(q.rstrip("…") in t for t in texts) for q in rep["quotes"]))
    def test_qc_catches_invented_numbers_and_quotes(self):
        rep = pipeline.make_report(self.res, "kisa", seed=1); rep["blocks"].append({"p": "Yorumların 9999 tanesi çok mutlu."}); rep["quotes"].append("hiç yazılmamış bir yorum")
        issues, _ = pipeline.check_report(rep, self.res); self.assertTrue(any("kayıtsız sayı" in i for i in issues)); self.assertTrue(any("uydurma alıntı" in i for i in issues))
    def test_incomplete_data_is_disclosed(self):
        self.assertIn("alınamadı", report.blocks_text(pipeline.make_report(self.res, "detay", seed=1)))
    def test_no_comments(self):
        r = engine.analyze(VID, [], collection={"notes": ["Bu videoda yorumlar kapalı."]}); rep = report.build(r, "kisa"); self.assertIn("kapalı", rep["blocks"][0]["p"])

class Api(unittest.TestCase):
    def test_endpoints(self):
        import app as A
        d = tempfile.mkdtemp(); A.DATA = d
        res = engine.analyze({**VID, "id": "B" * 11}, [T("c1", "güzel video")], collection={"threads": 1, "replies_fetched": 0, "complete": True, "notes": []}); pipeline._save(os.path.join(d, "analysis", "B" * 11 + ".json"), res)
        c = A.app.test_client(); self.assertEqual(c.get("/analiz").status_code, 200)
        self.assertEqual(c.get("/api/ci/report/" + "B" * 11 + "?format=kisa").status_code, 200); self.assertEqual(c.get("/api/ci/report/" + "B" * 11 + "?format=xx").status_code, 404)
        self.assertIn("yorum", c.get("/api/ci/export/" + "B" * 11 + "/csv").data.decode("utf-8")); self.assertEqual(c.get("/api/ci/result/../x").status_code, 404)
        self.assertEqual(c.post("/api/ci/analyze", json={"url": "x"}).status_code, 400)

if __name__ == "__main__": unittest.main()
