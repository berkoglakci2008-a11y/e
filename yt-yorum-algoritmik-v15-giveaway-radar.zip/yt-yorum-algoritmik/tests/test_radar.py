"""Radar testleri. DİKKAT: kanal yayını ve YouTube cevapları YAPAY test verisidir (gerçek YouTube'a bağlanılmaz); motor gerçektir."""
import os, sys, tempfile, time, unittest
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from test_insight import FakeClient, thread
from yca.radar.db import DB
from yca.radar.service import Radar
from yca.radar import feed
from yca.insight import pipeline

XML = b"""<?xml version='1.0'?><feed xmlns:yt="http://www.youtube.com/xml/schemas/2015" xmlns="http://www.w3.org/2005/Atom"><entry><yt:videoId>AAAAAAAAAAA</yt:videoId><title>Eski video</title><published>2026-10-01T10:00:00+00:00</published></entry></feed>"""
class Yt(FakeClient):
    def connected(self): return False
    def has_key(self): return True
def mk(d, feeds):
    pages = {0: {"items": [thread("a", "Harika video, çok beğendim"), thread("b", "Ses kalitesi kötü olmuş", [("r1", "katılıyorum")]), thread("c", "Devamı gelsin lütfen")]}}
    yt = Yt(pages); db = DB(d); r = Radar(db, yt, d, {"channels": ["@x"]}, feed_fn=lambda cid: feeds[0],
        runner=lambda vid: pipeline.run(vid, d, yt, max_threads=100)); db.x("UPDATE channels SET channel_id='UC1', title='Kanal'"); return db, r, yt

class T(unittest.TestCase):
    def test_parse(self): self.assertEqual(feed.parse_feed(XML)[0]["video_id"], "AAAAAAAAAAA")
    def test_flow(self):
        d = tempfile.mkdtemp(); now = int(time.time()); f = [[{"video_id": "AAAAAAAAAAA", "title": "Eski", "published_at": now - 9999999}]]
        db, r, yt = mk(d, f)
        r.poll_all(); self.assertEqual(db.one("SELECT status FROM videos")["status"], "baseline"); self.assertEqual(r.due(), [])   # eski videolar analiz edilmez
        f[0].insert(0, {"video_id": "BBBBBBBBBBB", "title": "Yeni", "published_at": now - 60})
        r.poll_all(); r.poll_all()
        self.assertEqual(db.one("SELECT COUNT(*) c FROM videos WHERE status='pending'")["c"], 1)          # çift kayıt yok
        self.assertEqual(r.due(), [])                                                                      # yorumların birikmesi için bekler
        self.assertEqual(len(r.due(now + 3000)), 1)
        v, cp = r.due(now + 3000)[0]; r.analyze(v, cp)
        a = db.one("SELECT * FROM analyses WHERE video_id='BBBBBBBBBBB'"); self.assertEqual(a["n_comments"], 4); self.assertEqual(a["new_comments"], 4)
        self.assertTrue(a["reports"]["detay"]["blocks"]); self.assertTrue(any(n["kind"] == "analysis" for n in db.q("SELECT * FROM notifications")))
        self.assertEqual(r.due(now + 3000), [])                                                            # aynı kontrol noktası tekrar işlenmez
        # yeniden başlatma: yeni nesneler aynı veriden devam eder
        r2 = Radar(DB(d), yt, d, {"channels": ["@x"]}, feed_fn=lambda c: f[0]); self.assertEqual(r2.due(now + 3000), [])
        self.assertEqual(len(r2.due(now + 90000)), 1)                                                      # 24 sa takip kontrolü sırada
        v, cp = r2.due(now + 90000)[0]; self.assertEqual(cp, 1); r2.analyze(v, cp)                          # yorum sayısı artmadı -> atlanır
        self.assertIn("skipped", db.one("SELECT summary FROM analyses WHERE checkpoint=1")["summary"])
        self.assertEqual(r2.due(now + 90000), [])
    def test_quota_pause_and_retry(self):
        d = tempfile.mkdtemp(); db, r, yt = mk(d, [[]]); db.x("INSERT INTO videos(video_id,channel_id,title,published_at,detected_at,status) VALUES('CCCCCCCCCCC','UC1','t',1,1,'pending')")
        r.runner = lambda vid: (_ for _ in ()).throw(RuntimeError("boom")); v = db.one("SELECT * FROM videos"); r.analyze(v, 0)
        v = db.one("SELECT * FROM videos"); self.assertEqual((v["status"], v["attempts"]), ("error", 1)); self.assertGreater(v["next_try"], time.time())
        r.cfg["daily_quota_budget"] = 10; self.assertLess(r.quota_left(), 350)
if __name__ == "__main__": unittest.main()
